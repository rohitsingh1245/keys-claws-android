#!/usr/bin/env python3
"""Assemble the small native Android Wi-Fi/Bluetooth multiplayer bridge.

The project deliberately has no Android SDK dependency.  This module writes a
normal Dalvik 035 file containing one Activity which also implements Runnable.
Runtime-visible JavascriptInterface annotations expose the transport methods to
the packaged WebView; TCP sockets and paired Bluetooth RFCOMM sockets provide
the actual cross-device connections.
"""

from __future__ import annotations

import hashlib
import struct
import zlib
from dataclasses import dataclass


PORT = 49735
SERVICE_UUID = 'f7cbf6f5-24fa-4f6e-b6e8-31fbd96a4440'


def u16(value: int) -> bytes:
    return struct.pack('<H', value & 0xffff)


def u32(value: int) -> bytes:
    return struct.pack('<I', value & 0xffffffff)


def uleb(value: int) -> bytes:
    out = bytearray()
    while True:
        current = value & 0x7f
        value >>= 7
        out.append(current | (0x80 if value else 0))
        if not value:
            return bytes(out)


def align(data: bytearray) -> None:
    data.extend(bytes((-len(data)) % 4))


@dataclass(frozen=True)
class Method:
    owner: str
    name: str
    result: str
    parameters: tuple[str, ...] = ()


@dataclass(frozen=True)
class Field:
    owner: str
    name: str
    descriptor: str


class Assembly:
    def __init__(self, methods: dict[Method, int], fields: dict[Field, int],
                 strings: dict[str, int], types: dict[str, int]) -> None:
        self.code: list[int] = []
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str]] = []
        self.methods = methods
        self.fields = fields
        self.strings = strings
        self.types = types

    def mark(self, name: str) -> None:
        if name in self.labels:
            raise ValueError('Duplicate Dalvik label: ' + name)
        self.labels[name] = len(self.code)

    def emit(self, *words: int) -> None:
        self.code.extend(word & 0xffff for word in words)

    def invoke(self, opcode: int, method: Method, registers: list[int]) -> None:
        if len(registers) > 5 or any(value > 15 or value < 0 for value in registers):
            raise ValueError('Invalid Dalvik invoke register list')
        packed = sum(register << (index * 4)
                     for index, register in enumerate(registers[:4]))
        fifth = registers[4] if len(registers) == 5 else 0
        self.emit(opcode | fifth << 8 | len(registers) << 12,
                  self.methods[method], packed)

    def result(self, register: int, object_result: bool = False) -> None:
        self.emit((0x0c if object_result else 0x0a) | register << 8)

    def constant(self, register: int, value: int) -> None:
        if -8 <= value <= 7:
            self.emit(0x12 | register << 8 | (value & 0xf) << 12)
        elif -32768 <= value <= 32767:
            self.emit(0x13 | register << 8, value)
        else:
            self.emit(0x14 | register << 8, value & 0xffff,
                      (value >> 16) & 0xffff)

    def string(self, register: int, value: str) -> None:
        self.emit(0x1a | register << 8, self.strings[value])

    def instance(self, register: int, descriptor: str) -> None:
        self.emit(0x22 | register << 8, self.types[descriptor])

    def cast(self, register: int, descriptor: str) -> None:
        self.emit(0x1f | register << 8, self.types[descriptor])

    def field(self, opcode: int, first: int, second: int, field: Field) -> None:
        self.emit(opcode | first << 8 | second << 12, self.fields[field])

    def static(self, opcode: int, register: int, field: Field) -> None:
        self.emit(opcode | register << 8, self.fields[field])

    def branch(self, opcode: int, first: int, second: int | None,
               label: str) -> None:
        start = len(self.code)
        if second is None:
            self.emit(opcode | first << 8, 0)
        else:
            self.emit(opcode | first << 8 | second << 12, 0)
        self.fixups.append((start, label))

    def jump(self, label: str) -> None:
        start = len(self.code)
        self.emit(0x29, 0)  # goto/16
        self.fixups.append((start, label))

    def finish(self) -> list[int]:
        for start, label in self.fixups:
            if label not in self.labels:
                raise ValueError('Undefined Dalvik label: ' + label)
            distance = self.labels[label] - start
            if not -32768 <= distance <= 32767 or not distance:
                raise ValueError('Invalid Dalvik branch distance')
            self.code[start + 1] = distance & 0xffff
        return self.code


def build_network_dex(main: str) -> bytes:
    activity = 'Landroid/app/Activity;'
    context = 'Landroid/content/Context;'
    bundle = 'Landroid/os/Bundle;'
    version = 'Landroid/os/Build$VERSION;'
    view = 'Landroid/view/View;'
    window = 'Landroid/view/Window;'
    settings = 'Landroid/webkit/WebSettings;'
    webview = 'Landroid/webkit/WebView;'
    bridge_annotation = 'Landroid/webkit/JavascriptInterface;'
    wifi_manager = 'Landroid/net/wifi/WifiManager;'
    wifi_info = 'Landroid/net/wifi/WifiInfo;'
    formatter = 'Landroid/text/format/Formatter;'
    adapter = 'Landroid/bluetooth/BluetoothAdapter;'
    device = 'Landroid/bluetooth/BluetoothDevice;'
    bt_socket = 'Landroid/bluetooth/BluetoothSocket;'
    bt_server = 'Landroid/bluetooth/BluetoothServerSocket;'
    obj = 'Ljava/lang/Object;'
    string = 'Ljava/lang/String;'
    string_array = '[Ljava/lang/String;'
    throwable = 'Ljava/lang/Throwable;'
    builder = 'Ljava/lang/StringBuilder;'
    runnable = 'Ljava/lang/Runnable;'
    thread = 'Ljava/lang/Thread;'
    queue = 'Ljava/util/concurrent/ConcurrentLinkedQueue;'
    java_set = 'Ljava/util/Set;'
    uuid = 'Ljava/util/UUID;'
    socket = 'Ljava/net/Socket;'
    server_socket = 'Ljava/net/ServerSocket;'
    input_stream = 'Ljava/io/InputStream;'
    output_stream = 'Ljava/io/OutputStream;'
    data_input = 'Ljava/io/DataInputStream;'
    data_output = 'Ljava/io/DataOutputStream;'

    own_fields = [
        Field(main, 'mode', 'I'), Field(main, 'target', string),
        Field(main, 'wifiExpected', 'I'),
        Field(main, 'events', queue), Field(main, 'input', data_input),
        Field(main, 'input2', data_input), Field(main, 'input3', data_input),
        Field(main, 'output', data_output), Field(main, 'output2', data_output),
        Field(main, 'output3', data_output), Field(main, 'wifiSocket', socket),
        Field(main, 'wifiSocket2', socket), Field(main, 'wifiSocket3', socket),
        Field(main, 'wifiServer', server_socket),
        Field(main, 'bluetoothSocket', bt_socket),
        Field(main, 'bluetoothServer', bt_server),
    ]
    sdk_field = Field(version, 'SDK_INT', 'I')
    all_fields = own_fields + [sdk_field]
    own_methods = [
        Method(main, '<init>', 'V'), Method(main, 'onCreate', 'V', (bundle,)),
        Method(main, 'startNetwork', string, ('I', string)),
        Method(main, 'hostWifi', string),
        Method(main, 'hostWifiPlayers', string, ('I',)),
        Method(main, 'joinWifi', string, (string,)),
        Method(main, 'hostBluetooth', string),
        Method(main, 'joinBluetooth', string, (string,)),
        Method(main, 'bondedDevices', string), Method(main, 'localAddress', string),
        Method(main, 'poll', string), Method(main, 'send', 'Z', (string,)),
        Method(main, 'disconnect', 'V'), Method(main, 'enqueue', 'V', (string,)),
        Method(main, 'run', 'V'),
    ]
    bridge_names = {'hostWifi', 'hostWifiPlayers', 'joinWifi', 'hostBluetooth', 'joinBluetooth',
                    'bondedDevices', 'localAddress', 'poll', 'send', 'disconnect'}
    methods = own_methods + [
        Method(activity, '<init>', 'V'), Method(activity, 'onCreate', 'V', (bundle,)),
        Method(activity, 'requestWindowFeature', 'Z', ('I',)),
        Method(activity, 'getWindow', window),
        Method(activity, 'setContentView', 'V', (view,)),
        Method(activity, 'getSystemService', obj, (string,)),
        Method(activity, 'requestPermissions', 'V', (string_array, 'I')),
        Method(window, 'setFlags', 'V', ('I', 'I')),
        Method(settings, 'setJavaScriptEnabled', 'V', ('Z',)),
        Method(settings, 'setDomStorageEnabled', 'V', ('Z',)),
        Method(settings, 'setMediaPlaybackRequiresUserGesture', 'V', ('Z',)),
        Method(webview, '<init>', 'V', (context,)),
        Method(webview, 'getSettings', settings),
        Method(webview, 'addJavascriptInterface', 'V', (obj, string)),
        Method(webview, 'loadUrl', 'V', (string,)),
        Method(thread, '<init>', 'V', (runnable,)), Method(thread, 'start', 'V'),
        Method(thread, 'sleep', 'V', ('J',)),
        Method(queue, '<init>', 'V'), Method(queue, 'offer', 'Z', (obj,)),
        Method(queue, 'poll', obj), Method(obj, 'toString', string),
        Method(throwable, 'toString', string),
        Method(builder, '<init>', 'V'),
        Method(builder, 'append', builder, (string,)),
        Method(builder, 'toString', string),
        Method(server_socket, '<init>', 'V', ('I',)),
        Method(server_socket, 'accept', socket), Method(server_socket, 'close', 'V'),
        Method(socket, '<init>', 'V', (string, 'I')),
        Method(socket, 'getInputStream', input_stream),
        Method(socket, 'getOutputStream', output_stream), Method(socket, 'close', 'V'),
        Method(adapter, 'getDefaultAdapter', adapter),
        Method(adapter, 'getBondedDevices', java_set),
        Method(adapter, 'getRemoteDevice', device, (string,)),
        Method(adapter, 'listenUsingRfcommWithServiceRecord', bt_server,
               (string, uuid)),
        Method(device, 'createRfcommSocketToServiceRecord', bt_socket, (uuid,)),
        Method(bt_server, 'accept', bt_socket), Method(bt_server, 'close', 'V'),
        Method(bt_socket, 'connect', 'V'), Method(bt_socket, 'close', 'V'),
        Method(bt_socket, 'getInputStream', input_stream),
        Method(bt_socket, 'getOutputStream', output_stream),
        Method(uuid, 'fromString', uuid, (string,)),
        Method(data_input, '<init>', 'V', (input_stream,)),
        Method(data_input, 'readUTF', string), Method(data_input, 'available', 'I'),
        Method(data_output, '<init>', 'V', (output_stream,)),
        Method(data_output, 'writeUTF', 'V', (string,)),
        Method(data_output, 'flush', 'V'),
        Method(wifi_manager, 'getConnectionInfo', wifi_info),
        Method(wifi_info, 'getIpAddress', 'I'),
        Method(formatter, 'formatIpAddress', string, ('I',)),
    ]
    all_types = {'I', 'J', 'V', 'Z', main, activity, context, bundle, version, view,
                 window, settings, webview, bridge_annotation, wifi_manager,
                 wifi_info, formatter, adapter, device, bt_socket, bt_server,
                 obj, string, string_array, throwable, builder, runnable, thread,
                 queue, java_set, uuid, socket, server_socket, input_stream,
                 output_stream, data_input, data_output}
    prototypes = {(item.result, item.parameters) for item in methods}

    def short(descriptor: str) -> str:
        return 'L' if descriptor.startswith(('L', '[')) else descriptor

    shorties = {short(result) + ''.join(short(value) for value in params)
                for result, params in prototypes}
    literals = {
        '', 'MainActivity.java', 'file:///android_asset/index.html',
        'KeysClawsNative', 'android.permission.BLUETOOTH_CONNECT', 'wifi',
        'started', 'status|waiting', 'status|connected', 'data|', 'error|',
        'status|connected|1', 'status|connected|2', 'status|connected|3',
        'data|1|', 'data|2|', 'data|3|',
        'error|Unsupported connection mode', 'Keys & Claws Adventure', SERVICE_UUID,
    }
    strings = sorted(all_types | shorties | literals |
                     {item.name for item in methods} |
                     {item.name for item in all_fields})
    string_index = {value: index for index, value in enumerate(strings)}
    descriptors = sorted(all_types, key=string_index.__getitem__)
    type_index = {value: index for index, value in enumerate(descriptors)}
    protos = sorted(prototypes,
                    key=lambda item: (type_index[item[0]],
                                      tuple(type_index[p] for p in item[1])))
    proto_index = {value: index for index, value in enumerate(protos)}
    fields = sorted(set(all_fields),
                    key=lambda item: (type_index[item.owner],
                                      string_index[item.name],
                                      type_index[item.descriptor]))
    field_index = {value: index for index, value in enumerate(fields)}
    method_list = sorted(set(methods),
                         key=lambda item: (type_index[item.owner],
                                           string_index[item.name],
                                           proto_index[(item.result, item.parameters)]))
    method_index = {value: index for index, value in enumerate(method_list)}

    header_size = 112
    string_ids_off = header_size
    type_ids_off = string_ids_off + 4 * len(strings)
    proto_ids_off = type_ids_off + 4 * len(descriptors)
    field_ids_off = proto_ids_off + 12 * len(protos)
    method_ids_off = field_ids_off + 8 * len(fields)
    class_defs_off = method_ids_off + 8 * len(method_list)
    data_off = class_defs_off + 32
    data = bytearray(data_off)

    first_string = len(data)
    string_offsets: dict[str, int] = {}
    for item in strings:
        string_offsets[item] = len(data)
        data.extend(uleb(len(item.encode('utf-16-le')) // 2))
        data.extend(item.encode('utf-8'))
        data.append(0)

    type_lists: dict[tuple[str, ...], int] = {}
    for values in [params for _, params in protos if params] + [(runnable,)]:
        if values in type_lists:
            continue
        align(data)
        type_lists[values] = len(data)
        data.extend(u32(len(values)))
        for value in values:
            data.extend(u16(type_index[value]))

    def asm() -> Assembly:
        return Assembly(method_index, field_index, string_index, type_index)

    def own(name: str, result: str = 'V', params: tuple[str, ...] = ()) -> Method:
        return Method(main, name, result, params)

    def member(name: str) -> Field:
        return next(field for field in own_fields if field.name == name)

    code_offsets: dict[Method, int] = {}
    first_code = None

    def add(method: Method, registers: int, incoming: int, outgoing: int,
            code: Assembly, catch_label: str | None = None) -> None:
        nonlocal first_code
        words = code.finish()
        align(data)
        offset = len(data)
        if first_code is None:
            first_code = offset
        tries = 1 if catch_label else 0
        data.extend(struct.pack('<HHHHII', registers, incoming, outgoing, tries,
                                0, len(words)))
        data.extend(b''.join(u16(value) for value in words))
        if catch_label:
            if len(words) % 2:
                data.extend(u16(0))
            handler_address = code.labels[catch_label]
            data.extend(struct.pack('<IHH', 0, handler_address, 1))
            data.extend(uleb(1))  # one catch-handler list item
            data.extend(b'\x00')  # signed zero: catch-all only
            data.extend(uleb(handler_address))
        code_offsets[method] = offset

    a = asm()
    a.invoke(0x70, Method(activity, '<init>', 'V'), [2])
    a.instance(0, queue)
    a.invoke(0x70, Method(queue, '<init>', 'V'), [0])
    a.field(0x5b, 0, 2, member('events'))
    a.constant(1, 2)
    a.field(0x59, 1, 2, member('wifiExpected'))
    a.emit(0x000e)
    add(own('<init>'), 3, 1, 1, a)

    a = asm()
    a.invoke(0x6f, Method(activity, 'onCreate', 'V', (bundle,)), [5, 6])
    a.constant(0, 1)
    a.invoke(0x6e, Method(activity, 'requestWindowFeature', 'Z', ('I',)), [5, 0])
    a.invoke(0x6e, Method(activity, 'getWindow', window), [5])
    a.result(2, True)
    a.constant(0, 0x0400)
    a.invoke(0x6e, Method(window, 'setFlags', 'V', ('I', 'I')), [2, 0, 0])
    a.instance(1, webview)
    a.invoke(0x70, Method(webview, '<init>', 'V', (context,)), [1, 5])
    a.invoke(0x6e, Method(webview, 'getSettings', settings), [1])
    a.result(2, True)
    a.constant(0, 1)
    a.invoke(0x6e, Method(settings, 'setJavaScriptEnabled', 'V', ('Z',)), [2, 0])
    a.invoke(0x6e, Method(settings, 'setDomStorageEnabled', 'V', ('Z',)), [2, 0])
    a.constant(0, 0)
    a.invoke(0x6e, Method(settings, 'setMediaPlaybackRequiresUserGesture',
                          'V', ('Z',)), [2, 0])
    a.string(0, 'KeysClawsNative')
    a.invoke(0x6e, Method(webview, 'addJavascriptInterface', 'V', (obj, string)),
             [1, 5, 0])
    a.invoke(0x6e, Method(activity, 'setContentView', 'V', (view,)), [5, 1])
    a.string(0, 'file:///android_asset/index.html')
    a.invoke(0x6e, Method(webview, 'loadUrl', 'V', (string,)), [1, 0])
    a.static(0x60, 2, sdk_field)
    a.constant(0, 31)
    a.branch(0x34, 2, 0, 'permission_done')  # if-lt SDK_INT, 31
    a.constant(0, 1)
    a.emit(0x23 | 1 << 8 | 0 << 12, type_index[string_array])  # new-array v1,v0
    a.string(2, 'android.permission.BLUETOOTH_CONNECT')
    a.constant(3, 0)
    a.emit(0x4d | 2 << 8, 1 | 3 << 8)  # aput-object v2, v1, v3
    a.constant(0, 42)
    a.invoke(0x6e, Method(activity, 'requestPermissions', 'V', (string_array, 'I')),
             [5, 1, 0])
    a.mark('permission_done')
    a.emit(0x000e)
    add(own('onCreate', 'V', (bundle,)), 7, 2, 3, a)

    a = asm()
    a.field(0x59, 3, 2, member('mode'))
    a.field(0x5b, 4, 2, member('target'))
    a.instance(0, thread)
    a.invoke(0x70, Method(thread, '<init>', 'V', (runnable,)), [0, 2])
    a.invoke(0x6e, Method(thread, 'start', 'V'), [0])
    a.string(0, 'started')
    a.emit(0x11 | 0 << 8)
    add(own('startNetwork', string, ('I', string)), 5, 3, 3, a)

    for name, mode in [('hostWifi', 1), ('hostBluetooth', 3)]:
        a = asm()
        if name == 'hostWifi':
            a.constant(0, 2)
            a.field(0x59, 0, 2, member('wifiExpected'))
        a.constant(0, mode)
        a.string(1, '')
        a.invoke(0x6e, own('startNetwork', string, ('I', string)), [2, 0, 1])
        a.result(0, True)
        a.emit(0x11 | 0 << 8)
        add(own(name, string), 3, 1, 3, a)

    a = asm()
    a.field(0x59, 3, 2, member('wifiExpected'))
    a.constant(0, 1)
    a.string(1, '')
    a.invoke(0x6e, own('startNetwork', string, ('I', string)), [2, 0, 1])
    a.result(0, True)
    a.emit(0x11 | 0 << 8)
    add(own('hostWifiPlayers', string, ('I',)), 4, 2, 3, a)

    for name, mode in [('joinWifi', 2), ('joinBluetooth', 4)]:
        a = asm()
        a.constant(0, mode)
        a.invoke(0x6e, own('startNetwork', string, ('I', string)), [1, 0, 2])
        a.result(0, True)
        a.emit(0x11 | 0 << 8)
        add(own(name, string, (string,)), 3, 2, 3, a)

    a = asm()
    a.invoke(0x71, Method(adapter, 'getDefaultAdapter', adapter), [])
    a.result(0, True)
    a.invoke(0x6e, Method(adapter, 'getBondedDevices', java_set), [0])
    a.result(1, True)
    a.invoke(0x6e, Method(obj, 'toString', string), [1])
    a.result(0, True)
    a.emit(0x11 | 0 << 8)
    add(own('bondedDevices', string), 3, 1, 1, a)

    a = asm()
    a.string(0, 'wifi')
    a.invoke(0x6e, Method(activity, 'getSystemService', obj, (string,)), [3, 0])
    a.result(1, True)
    a.cast(1, wifi_manager)
    a.invoke(0x6e, Method(wifi_manager, 'getConnectionInfo', wifi_info), [1])
    a.result(2, True)
    a.invoke(0x6e, Method(wifi_info, 'getIpAddress', 'I'), [2])
    a.result(0)
    a.invoke(0x71, Method(formatter, 'formatIpAddress', string, ('I',)), [0])
    a.result(1, True)
    a.emit(0x11 | 1 << 8)
    add(own('localAddress', string), 4, 1, 2, a)

    a = asm()
    a.field(0x54, 0, 2, member('events'))
    a.invoke(0x6e, Method(queue, 'poll', obj), [0])
    a.result(1, True)
    a.branch(0x38, 1, None, 'empty')
    a.cast(1, string)
    a.emit(0x11 | 1 << 8)
    a.mark('empty')
    a.string(1, '')
    a.emit(0x11 | 1 << 8)
    add(own('poll', string), 3, 1, 1, a)

    a = asm()
    a.field(0x54, 0, 2, member('output'))
    a.branch(0x38, 0, None, 'not_connected')
    for suffix in ['', '2', '3']:
        if suffix:
            a.field(0x54, 0, 2, member('output' + suffix))
            a.branch(0x38, 0, None, 'skip_output' + suffix)
        a.invoke(0x6e, Method(data_output, 'writeUTF', 'V', (string,)), [0, 3])
        a.invoke(0x6e, Method(data_output, 'flush', 'V'), [0])
        if suffix:
            a.mark('skip_output' + suffix)
    a.constant(1, 1)
    a.emit(0x0f | 1 << 8)
    a.mark('not_connected')
    a.constant(1, 0)
    a.emit(0x0f | 1 << 8)
    add(own('send', 'Z', (string,)), 4, 2, 2, a)

    a = asm()
    for name, owner in [('wifiSocket', socket), ('wifiSocket2', socket),
                        ('wifiSocket3', socket), ('wifiServer', server_socket),
                        ('bluetoothSocket', bt_socket), ('bluetoothServer', bt_server)]:
        a.field(0x54, 0, 2, member(name))
        a.branch(0x38, 0, None, 'skip_' + name)
        a.invoke(0x6e, Method(owner, 'close', 'V'), [0])
        a.mark('skip_' + name)
    a.constant(0, 0)
    for name in ['output', 'output2', 'output3', 'input', 'input2', 'input3']:
        a.field(0x5b, 0, 2, member(name))
    a.emit(0x000e)
    add(own('disconnect'), 3, 1, 1, a)

    a = asm()
    a.field(0x54, 0, 1, member('events'))
    a.invoke(0x6e, Method(queue, 'offer', 'Z', (obj,)), [0, 2])
    a.emit(0x000e)
    add(own('enqueue', 'V', (string,)), 3, 2, 2, a)

    a = asm()

    def push_literal(value: str) -> None:
        a.string(0, value)
        a.invoke(0x6e, own('enqueue', 'V', (string,)), [9, 0])

    a.field(0x52, 0, 9, member('mode'))
    for mode, label in [(1, 'wifi_host'), (2, 'wifi_join'),
                        (3, 'bluetooth_host'), (4, 'bluetooth_join')]:
        a.constant(1, mode)
        a.branch(0x32, 0, 1, label)
    push_literal('error|Unsupported connection mode')
    a.emit(0x000e)

    a.mark('wifi_host')
    a.instance(2, server_socket)
    a.constant(1, PORT)
    a.invoke(0x70, Method(server_socket, '<init>', 'V', ('I',)), [2, 1])
    a.field(0x5b, 2, 9, member('wifiServer'))
    push_literal('status|waiting')
    for slot in [1, 2, 3]:
        suffix = '' if slot == 1 else str(slot)
        if slot > 1:
            a.field(0x52, 0, 9, member('wifiExpected'))
            a.constant(1, slot + 1)
            a.branch(0x34, 0, 1, 'wifi_host_ready')
        a.field(0x54, 2, 9, member('wifiServer'))
        a.invoke(0x6e, Method(server_socket, 'accept', socket), [2])
        a.result(2, True)
        a.field(0x5b, 2, 9, member('wifiSocket' + suffix))
        a.invoke(0x6e, Method(socket, 'getInputStream', input_stream), [2])
        a.result(4, True)
        a.invoke(0x6e, Method(socket, 'getOutputStream', output_stream), [2])
        a.result(5, True)
        a.instance(6, data_input)
        a.invoke(0x70, Method(data_input, '<init>', 'V', (input_stream,)), [6, 4])
        a.field(0x5b, 6, 9, member('input' + suffix))
        a.instance(7, data_output)
        a.invoke(0x70, Method(data_output, '<init>', 'V', (output_stream,)), [7, 5])
        a.field(0x5b, 7, 9, member('output' + suffix))
        push_literal('status|connected|' + str(slot))

    a.mark('wifi_host_ready')
    a.mark('wifi_host_read_loop')
    for slot in [1, 2, 3]:
        suffix = '' if slot == 1 else str(slot)
        a.field(0x54, 6, 9, member('input' + suffix))
        a.branch(0x38, 6, None, 'skip_wifi_input_' + str(slot))
        a.invoke(0x6e, Method(data_input, 'available', 'I'), [6])
        a.result(0)
        a.branch(0x38, 0, None, 'skip_wifi_input_' + str(slot))
        a.invoke(0x6e, Method(data_input, 'readUTF', string), [6])
        a.result(0, True)
        a.instance(1, builder)
        a.invoke(0x70, Method(builder, '<init>', 'V'), [1])
        a.string(2, 'data|' + str(slot) + '|')
        a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 2])
        a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 0])
        a.invoke(0x6e, Method(builder, 'toString', string), [1])
        a.result(2, True)
        a.invoke(0x6e, own('enqueue', 'V', (string,)), [9, 2])
        a.mark('skip_wifi_input_' + str(slot))
    a.emit(0x0016, 12)  # const-wide/16 v0, 12; v1 is its upper half
    a.invoke(0x71, Method(thread, 'sleep', 'V', ('J',)), [0, 1])
    a.jump('wifi_host_read_loop')

    a.mark('wifi_join')
    a.instance(2, socket)
    a.field(0x54, 3, 9, member('target'))
    a.constant(1, PORT)
    a.invoke(0x70, Method(socket, '<init>', 'V', (string, 'I')), [2, 3, 1])
    a.field(0x5b, 2, 9, member('wifiSocket'))

    a.mark('wifi_streams')
    a.invoke(0x6e, Method(socket, 'getInputStream', input_stream), [2])
    a.result(4, True)
    a.invoke(0x6e, Method(socket, 'getOutputStream', output_stream), [2])
    a.result(5, True)
    a.jump('connected')

    a.mark('bluetooth_host')
    a.invoke(0x71, Method(adapter, 'getDefaultAdapter', adapter), [])
    a.result(2, True)
    a.string(0, SERVICE_UUID)
    a.invoke(0x71, Method(uuid, 'fromString', uuid, (string,)), [0])
    a.result(3, True)
    a.string(1, 'Keys & Claws Adventure')
    a.invoke(0x6e, Method(adapter, 'listenUsingRfcommWithServiceRecord',
                          bt_server, (string, uuid)), [2, 1, 3])
    a.result(4, True)
    a.field(0x5b, 4, 9, member('bluetoothServer'))
    push_literal('status|waiting')
    a.invoke(0x6e, Method(bt_server, 'accept', bt_socket), [4])
    a.result(2, True)
    a.field(0x5b, 2, 9, member('bluetoothSocket'))
    a.jump('bluetooth_streams')

    a.mark('bluetooth_join')
    a.invoke(0x71, Method(adapter, 'getDefaultAdapter', adapter), [])
    a.result(2, True)
    a.field(0x54, 0, 9, member('target'))
    a.invoke(0x6e, Method(adapter, 'getRemoteDevice', device, (string,)), [2, 0])
    a.result(3, True)
    a.string(0, SERVICE_UUID)
    a.invoke(0x71, Method(uuid, 'fromString', uuid, (string,)), [0])
    a.result(1, True)
    a.invoke(0x6e, Method(device, 'createRfcommSocketToServiceRecord',
                          bt_socket, (uuid,)), [3, 1])
    a.result(2, True)
    a.invoke(0x6e, Method(bt_socket, 'connect', 'V'), [2])
    a.field(0x5b, 2, 9, member('bluetoothSocket'))

    a.mark('bluetooth_streams')
    a.invoke(0x6e, Method(bt_socket, 'getInputStream', input_stream), [2])
    a.result(4, True)
    a.invoke(0x6e, Method(bt_socket, 'getOutputStream', output_stream), [2])
    a.result(5, True)

    a.mark('connected')
    a.instance(6, data_input)
    a.invoke(0x70, Method(data_input, '<init>', 'V', (input_stream,)), [6, 4])
    a.field(0x5b, 6, 9, member('input'))
    a.instance(7, data_output)
    a.invoke(0x70, Method(data_output, '<init>', 'V', (output_stream,)), [7, 5])
    a.field(0x5b, 7, 9, member('output'))
    push_literal('status|connected')

    a.mark('read_loop')
    a.invoke(0x6e, Method(data_input, 'readUTF', string), [6])
    a.result(0, True)
    a.instance(1, builder)
    a.invoke(0x70, Method(builder, '<init>', 'V'), [1])
    a.string(2, 'data|')
    a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 2])
    a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 0])
    a.invoke(0x6e, Method(builder, 'toString', string), [1])
    a.result(2, True)
    a.invoke(0x6e, own('enqueue', 'V', (string,)), [9, 2])
    a.jump('read_loop')

    a.mark('network_error')
    a.emit(0x000d)  # move-exception v0
    a.instance(1, builder)
    a.invoke(0x70, Method(builder, '<init>', 'V'), [1])
    a.string(2, 'error|')
    a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 2])
    a.invoke(0x6e, Method(throwable, 'toString', string), [0])
    a.result(2, True)
    a.invoke(0x6e, Method(builder, 'append', builder, (string,)), [1, 2])
    a.invoke(0x6e, Method(builder, 'toString', string), [1])
    a.result(2, True)
    a.invoke(0x6e, own('enqueue', 'V', (string,)), [9, 2])
    a.emit(0x000e)
    add(own('run'), 10, 1, 3, a, 'network_error')

    annotation_item_off = len(data)
    data.append(0x01)  # runtime visibility
    data.extend(uleb(type_index[bridge_annotation]))
    data.extend(uleb(0))  # no annotation members
    align(data)
    annotation_set_off = len(data)
    data.extend(u32(1) + u32(annotation_item_off))

    annotated = sorted((method_index[item] for item in own_methods
                        if item.name in bridge_names))
    annotation_directory_off = len(data)
    data.extend(struct.pack('<IIII', 0, 0, len(annotated), 0))
    for index in annotated:
        data.extend(u32(index) + u32(annotation_set_off))

    class_data_off = len(data)
    sorted_own_fields = sorted(own_fields, key=field_index.__getitem__)
    direct = [own('<init>')]
    virtual = sorted((item for item in own_methods if item.name != '<init>'),
                     key=method_index.__getitem__)
    data.extend(uleb(0) + uleb(len(sorted_own_fields)) +
                uleb(len(direct)) + uleb(len(virtual)))
    previous = 0
    for field in sorted_own_fields:
        index = field_index[field]
        data.extend(uleb(index - previous) + uleb(0x0002))  # private
        previous = index
    previous = 0
    for item in direct:
        index = method_index[item]
        data.extend(uleb(index - previous) + uleb(0x10001) +
                    uleb(code_offsets[item]))
        previous = index
    previous = 0
    for item in virtual:
        index = method_index[item]
        data.extend(uleb(index - previous) + uleb(0x0001) +
                    uleb(code_offsets[item]))
        previous = index

    align(data)
    map_off = len(data)
    map_items = [
        (0x0000, 1, 0), (0x0001, len(strings), string_ids_off),
        (0x0002, len(descriptors), type_ids_off),
        (0x0003, len(protos), proto_ids_off),
        (0x0004, len(fields), field_ids_off),
        (0x0005, len(method_list), method_ids_off),
        (0x0006, 1, class_defs_off),
        (0x2002, len(strings), first_string),
        (0x1001, len(type_lists), min(type_lists.values())),
        (0x2001, len(code_offsets), first_code),
        (0x2004, 1, annotation_item_off),
        (0x1003, 1, annotation_set_off),
        (0x2006, 1, annotation_directory_off),
        (0x2000, 1, class_data_off), (0x1000, 1, map_off),
    ]
    map_items.sort(key=lambda item: item[2])
    data.extend(u32(len(map_items)))
    for kind, count, offset in map_items:
        data.extend(struct.pack('<HHII', kind, 0, count, offset))

    for index, value in enumerate(strings):
        struct.pack_into('<I', data, string_ids_off + index * 4,
                         string_offsets[value])
    for index, value in enumerate(descriptors):
        struct.pack_into('<I', data, type_ids_off + index * 4,
                         string_index[value])
    for index, (result, params) in enumerate(protos):
        shorty = short(result) + ''.join(short(value) for value in params)
        struct.pack_into('<III', data, proto_ids_off + index * 12,
                         string_index[shorty], type_index[result],
                         type_lists.get(params, 0))
    for index, value in enumerate(fields):
        struct.pack_into('<HHI', data, field_ids_off + index * 8,
                         type_index[value.owner], type_index[value.descriptor],
                         string_index[value.name])
    for index, value in enumerate(method_list):
        struct.pack_into('<HHI', data, method_ids_off + index * 8,
                         type_index[value.owner],
                         proto_index[(value.result, value.parameters)],
                         string_index[value.name])
    struct.pack_into('<IIIIIIII', data, class_defs_off,
                     type_index[main], 0x0001, type_index[activity],
                     type_lists[(runnable,)], string_index['MainActivity.java'],
                     annotation_directory_off, class_data_off, 0)

    data[0:8] = b'dex\n035\0'
    struct.pack_into('<20I', data, 32,
                     len(data), header_size, 0x12345678, 0, 0, map_off,
                     len(strings), string_ids_off, len(descriptors), type_ids_off,
                     len(protos), proto_ids_off, len(fields), field_ids_off,
                     len(method_list), method_ids_off, 1, class_defs_off,
                     len(data) - data_off, data_off)
    data[12:32] = hashlib.sha1(data[32:]).digest()
    struct.pack_into('<I', data, 8, zlib.adler32(data[12:]) & 0xffffffff)
    return bytes(data)
