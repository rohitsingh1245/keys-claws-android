#!/usr/bin/env python3
"""Build the game's bundled, spoken and animal-like offline audio clips.

The generated MP3 files are committed to the source bundle, so rebuilding the
APK does not require NumPy, SciPy, FFmpeg, or FFmpeg's optional flite filter.
Those tools are necessary only when regenerating the clips themselves.
"""

from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile


PROJECT = Path(__file__).resolve().parent
OUTPUT = PROJECT / 'sounds'
RATE = 22050
RNG = np.random.default_rng(782341)


def envelope(length: int, attack: float = .025, release: float = .14) -> np.ndarray:
    shape = np.ones(length, dtype=np.float64)
    first = min(length, int(attack * RATE))
    last = min(length, int(release * RATE))
    if first:
        shape[:first] *= np.linspace(0, 1, first)
    if last:
        shape[-last:] *= np.linspace(1, 0, last)
    return shape


def tone(duration: float, start: float, finish: float | None = None,
         harmonics: tuple[float, ...] = (1.0, .2, .06), vibrato: float = 0) -> np.ndarray:
    count = int(duration * RATE)
    timeline = np.arange(count) / RATE
    frequency = np.linspace(start, finish if finish is not None else start, count)
    if vibrato:
        frequency *= 1 + .037 * np.sin(2 * np.pi * vibrato * timeline)
    phase = 2 * np.pi * np.cumsum(frequency) / RATE
    sound = sum(weight * np.sin(phase * (index + 1))
                for index, weight in enumerate(harmonics))
    return sound * envelope(count)


def filtered_noise(duration: float, low: float, high: float) -> np.ndarray:
    count = int(duration * RATE)
    noise = RNG.normal(0, 1, count)
    sos = signal.butter(3, [low, min(high, RATE / 2 - 100)], btype='bandpass',
                        fs=RATE, output='sos')
    return signal.sosfilt(sos, noise) * envelope(count)


def mix(duration: float, layers: list[tuple[float, np.ndarray, float]]) -> np.ndarray:
    output = np.zeros(int(duration * RATE), dtype=np.float64)
    for offset, layer, gain in layers:
        start = int(offset * RATE)
        if start >= len(output):
            continue
        end = min(len(output), start + len(layer))
        output[start:end] += layer[:end - start] * gain
    return output


def voice(text: str, scratch: Path, name: str, speaker: str = 'slt',
          speed: float = 1.0, pitch: float = 1.0) -> np.ndarray:
    path = scratch / (name + '_voice.wav')
    sample_rate = int(RATE * pitch)
    graph = 'flite=text=' + text + ':voice=' + speaker
    filters = ('highpass=f=100,lowpass=f=6800,'
               'acompressor=threshold=0.12:ratio=2.5:attack=5:release=70,'
               'asetrate=' + str(sample_rate) + ',aresample=' + str(RATE) +
               ',atempo=' + str(speed) + ',volume=2.1')
    subprocess.run([
        'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi',
        '-i', graph, '-af', filters, '-ar', str(RATE), '-ac', '1', str(path),
    ], check=True)
    rate, samples = wavfile.read(path)
    if rate != RATE:
        raise ValueError('Unexpected synthesized speech sample rate')
    return samples.astype(np.float64) / 32768


def save(name: str, samples: np.ndarray, scratch: Path) -> dict[str, object]:
    clipped = np.tanh(samples * 1.35)
    peak = np.max(np.abs(clipped)) or 1
    clipped = clipped * (.92 / peak)
    wav = scratch / (name + '.wav')
    target = OUTPUT / (name + '.mp3')
    wavfile.write(wav, RATE, np.asarray(clipped * 32767, dtype=np.int16))
    subprocess.run([
        'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(wav),
        '-codec:a', 'libmp3lame', '-b:a', '96k', '-ar', str(RATE), '-ac', '1',
        '-write_xing', '0', str(target),
    ], check=True)
    return {'name': target.name, 'seconds': round(len(samples) / RATE, 2),
            'bytes': target.stat().st_size}


def main() -> None:
    OUTPUT.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='keys-claws-sounds-') as folder:
        scratch = Path(folder)
        clips: dict[str, np.ndarray] = {}

        roar_a = tone(.72, 138, 57, (1, .62, .36, .16), 18)
        roar_b = tone(.58, 108, 44, (1, .48, .24), 14)
        clips['lion'] = mix(1.14, [
            (.04, roar_a, .61), (.38, roar_b, .57),
            (.02, filtered_noise(.96, 90, 950), 1.35),
        ])

        howl_up = tone(.43, 320, 715, (1, .26, .08), 5)
        howl_down = tone(.92, 715, 350, (1, .2, .07), 5.5)
        clips['wolf'] = mix(1.48, [
            (.02, howl_up, .84), (.41, howl_down, .94),
            (.10, filtered_noise(1.12, 320, 2100), .15),
        ])

        fight_layers = []
        for offset, pitch in [(.03, 235), (.25, 175), (.47, 205)]:
            fight_layers.append((offset, tone(.19, pitch, 54, (1, .44, .16)), .76))
            fight_layers.append((offset, filtered_noise(.15, 250, 3900), 1.2))
        clips['fight'] = mix(.79, fight_layers)

        cry_voice = voice('Oh no. Boo hoo hoo.', scratch, 'cry', speed=1.13, pitch=1.08)
        cry_duration = len(cry_voice) / RATE + .08
        clips['cry'] = mix(cry_duration, [
            (.02, cry_voice, 1.0),
            (.43, tone(.39, 590, 350, (1, .14), 6), .12),
            (.87, tone(.42, 635, 290, (1, .14), 6), .10),
        ])

        relief_voice = voice('Ahhh. I feel better now.', scratch, 'relief',
                             speed=1.12, pitch=.98)
        relief_duration = len(relief_voice) / RATE + .12
        clips['relief'] = mix(relief_duration, [
            (.06, relief_voice, 1.0),
            (.10, filtered_noise(min(.62, relief_duration - .1), 800, 3400), .14),
        ])

        cheer_voice = voice('Hooray.', scratch, 'hurray', speed=1.0, pitch=1.22)
        cheer_duration = max(1.22, len(cheer_voice) / RATE + .32)
        cheer_layers = [(0.15, cheer_voice, 1.0)]
        for index, note in enumerate([392, 523, 659, 784]):
            cheer_layers.append((index * .10, tone(.27, note, note * 1.02), .22))
        clips['hurray'] = mix(cheer_duration, cheer_layers)

        clips['good'] = mix(.67, [
            (index * .11, tone(.26, note, note * 1.015), .75)
            for index, note in enumerate([659, 784, 988])
        ])
        clips['bad'] = mix(.57, [
            (.03, tone(.44, 300, 128, (1, .35, .14)), .83),
            (.04, filtered_noise(.31, 140, 690), .36),
        ])
        clips['step'] = mix(.34, [
            (.02, filtered_noise(.12, 650, 4400), .55),
            (.03, tone(.19, 680, 250), .58),
        ])
        clips['win'] = mix(1.38, [
            (index * .15, tone(.45, note, note * 1.008), .74)
            for index, note in enumerate([523, 659, 784, 1047, 1319])
        ])

        results = [save(name, samples, scratch) for name, samples in sorted(clips.items())]
    print(json.dumps({'clips': results, 'count': len(results)}, indent=2))


if __name__ == '__main__':
    main()
