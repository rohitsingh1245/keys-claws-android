# Keys & Claws: Quest for Home - Android Jungle Adventure

A separate landscape Android jungle adventure with one owner-approved natural
jungle background and all 35 subtly unnumbered stones, human explorers, lion, wolf, keys,
gates, weapons, and bridges placed directly on its winding paths. The approved
independent artwork, four distinct full-body animated child-explorer avatars,
one-device pass-and-play, genuine two-to-four-device local
Wi-Fi, two-device paired Bluetooth multiplayer, branded launcher icon, fair animated dice,
expressive offline sound effects, animated rivers and waterfalls, a soft
looping stereo jungle soundtrack, subtle image-native 2.5D depth, a separate
complete game-rules page, a seven-step illustrated guided tutorial, animated
knife/axe/hammer pickup and use, and an optional hammer-based final-lock rescue
are all bundled offline. Three- and four-explorer adventures continue after the
first finisher, award every finishing rank, and animate whichever side loses
each lion or wolf encounter falling down.

This edition has its own Android application identity,
`com.keysandclaws.questforhome3d`. It does not replace the original 2D game;
both editions can be installed together on the same device. The historical `3D`
suffix remains only in the Android package, application label, and archive
filenames to preserve installation compatibility. The in-game interface shows
**Keys & Claws: Quest for Home**, without any 3D badge or separate 3D board.

## Install

1. Copy Keys_Claws_Quest_for_Home_3D_Jungle_v2.0.apk to an Android phone or tablet.
2. Open the APK.
3. If Android asks, allow your browser or file manager to install this app.
4. Tap Install, then open Keys & Claws: Quest for Home 3D.

Requires Android 7.0 or later. No internet service or player account is needed.
Android's network permission is required for local Wi-Fi sockets, and Android
12 or later asks for Nearby devices permission so paired Bluetooth can connect.
The image-based jungle board does not require WebGL or a 3D-capable GPU.

## Explore the natural jungle board

The exact crisp, richly detailed jungle image uploaded by the owner
**is the board**, preserved byte-for-byte without any image-generation changes.
Its winding cobblestone paths, lush foliage,
rivers, waterfalls, and natural stone remain sharp. The image contains no baked
numbers, animals, keys, gates, controls, or other duplicate game objects.
Exactly 35 small, unnumbered stone markers sit directly on its five existing
paths. Every printed board number and special-space number badge is hidden;
spaces 1–35 remain available internally for movement, rules, and accessibility.
Approved transparent lion, wolf, golden-key, hammer, and jungle-gate artwork
appears once at the matching spaces. Four individual pre-rendered 3D-style
human explorer avatars move their visible arms, hands, and legs along the same
paths, and three slender wooden bridges connect spaces 3→11, 12→18, and 25→29.
The third bridge crosses the river deliberately and lets an explorer safely
bypass wolf 27. The markers for spaces 21 and 22 stay together on the dry
right-hand path instead of being placed over the river.

There is no separate tilted board, WebGL canvas, generated landscape, perspective
camera, floating projected labels, duplicated paths, LIVE 3D badge, zoom
buttons, camera toolbar, or full-screen-board overlay. The old renderer source
is preserved as an inactive historical file, but the application never loads
or initializes it.

The approved trail uses five continuous 7/7/7/6/8 lanes, turns only at 7→8,
14→15, 21→22, and 27→28, and retains the natural river between the last two
lanes. The ordinary trail crosses only at 27→28; the new elevated 25→29 bridge
is the sole approved shortcut across that river. The lion and wolf visibly
switch through walking, roaring or howling, peaceful sleeping, and idle
approved-artwork states during encounters. Keys glow, gates open and close using
their approved image frames, and the actual active explorer appears in
expressive crying and recovery story scenes when forced to return. Knives,
axes, and the hammer have individual pickup and action poses with distinct
matching offline sounds. Every
transparent artwork frame, sound, and gameplay asset is bundled locally;
no online engine, download, or external asset service is needed.

### Living water, jungle ambience, and 2.5D depth

The original background stays completely unchanged. Four narrow moving river
reflections and three softly animated waterfalls follow the water already
present in that image. Gentle waterfall foam, drifting mist, twelve fireflies,
subtle foreground foliage, grounded bridge/animal/gate/player shadows,
breathing approved lion and wolf artwork, and a glowing approved golden key
create a restrained 2.5D illusion directly on the same flat board. Moving a
pointer over the board shifts only the foreground by a few pixels. There is no
separate board, generated scenery, camera, WebGL, or printed space number.

During an active adventure, an original 22-second offline stereo soundtrack
loops softly with flowing river water, waterfalls, light leaf rustle, and
distant jungle birds. It begins only after the adventure starts, pauses when
the app is hidden, and obeys the master sound switch. In Adventure Settings,
**Jungle ambience** controls the soundtrack separately, and **Living jungle**
controls the water, waterfalls, fireflies, shadows, and depth effects. Turning
off obstacle animations or requesting reduced motion also suppresses decorative
movement. All gameplay rules and connected-device behavior remain unchanged.

## Play

Choose one to four explorers and enter a name for each player. Two-player
pass-and-play is selected by default. Tap any player name or pencil button
during the game to rename that explorer. After each multiplayer turn, the next
explorer becomes active immediately: pass the device and roll, with no popup
or confirmation button.

When more than two explorers are playing, the adventure does not stop after the
first person reaches HOME. That explorer earns **1st** and takes no more turns.
The remaining explorers continue normally, with finished players automatically
skipped. In a four-player game, the next finishers earn **2nd** and **3rd**;
the final remaining explorer automatically receives **4th**. A three-player
game similarly ends with **1st**, **2nd**, and automatic **3rd**; a two-player
game awards **1st** and automatic **2nd**. Current places appear beside each
explorer, and the final victory screen displays the complete ranked standings.
These rules are synchronized identically across all connected Wi-Fi devices.

Open the gear button at any time, or use GAME SETTINGS before starting, to
choose master sound effects, jungle ambience, living jungle scenery, obstacle
animations, and slow, normal, or fast piece movement. Settings are remembered
on the device. Pass & Play supports one to four explorers on one phone; Wi-Fi
connects two, three, or four separate devices, while Bluetooth connects two
paired devices. Every connected device controls exactly one explorer.

### Read the rules or take the guided tutorial

Before starting, tap **HOW TO PLAY** to open the complete game rules inside a
scrollable popup, or tap **GUIDED TUTORIAL** for a short, illustrated walkthrough.
After the game begins, the **?** button in the top toolbar, **READ FULL RULES** in
the sidebar field guide, and **RULES & GUIDED TUTORIAL** in settings all reopen
the same rules page without changing the active game.

The seven tutorial steps explain the quest, dice and turn order, golden keys and
gates, the three shortcut bridges, both animal defenses, local multiplayer, and
the exact final roll required to unlock HOME using the final key or the hammer.
Use **NEXT**, **BACK**, or the arrow
keys to navigate; close either popup with its close button or Escape. The guide
loads its content from a separate offline `rules.html` page and displays the
same approved lion, wolf, key, and gate artwork used by the game.

### Play across two, three, or four devices with Wi-Fi

1. Install the same APK on every Android phone or tablet.
2. Connect all devices to the same Wi-Fi network or hotspot.
3. Open GAME SETTINGS and select Wi-Fi Multiplayer on each device.
4. On the host device, choose **2 PLAYERS**, **3 PLAYERS**, or **4 PLAYERS**,
   enter your explorer name, and tap CREATE A GAME.
5. On every guest device, enter the host's displayed Wi-Fi address, choose a
   unique explorer name, and tap JOIN THE GAME.
6. The lobby shows how many explorers are connected. When the selected number
   joins, the shared adventure starts automatically on all devices.
7. Only the active explorer's own device can roll. Every device displays the
   same positions, inventories, encounters, explorer names, and turn order.

### Play across two phones with Bluetooth

1. Enable Bluetooth on both devices and pair the phones in Android Settings.
2. When Android asks, allow the Nearby devices permission.
3. Open GAME SETTINGS and select Bluetooth Multiplayer on both phones.
4. On the first phone, enter a name and tap CREATE A GAME.
5. On the second phone, select the paired host address, enter a name, and tap
   JOIN THE GAME.
6. Keep both phones nearby until the game finishes.

Wi-Fi uses local TCP port 49735. Bluetooth uses the paired Classic Bluetooth
RFCOMM service UUID `f7cbf6f5-24fa-4f6e-b6e8-31fbd96a4440`. The host controls
all dice results; each guest device requests only its own turn and receives the
validated roll. The host verifies the requesting guest socket and broadcasts
accepted rolls to every device. Revision numbers prevent duplicate or
out-of-order rolls. Bluetooth
requires devices that provide Classic Bluetooth; no Bluetooth discovery or
internet matchmaking is included.

Tap the large, animated six-sided die to roll. Where available, the app uses
cryptographically strong device randomness with rejection sampling. Each player
receives an independently shuffled set of all six faces, so every face appears
exactly once within six of that player's rolls and no face repeats immediately.
The game bundles loud, distinct offline audio clips: lion roars, wolf howls,
defensive struggles, an actual spoken crying voice, spoken relief after
treatment, spoken shortcut celebrations, an original 48-kHz stereo wooden-gate
opening recording, a separate original gate-closing recording, and a victory
fanfare. Seven additional original clips distinguish knife, axe, and hammer
pickup; knife and axe defense; hammer strikes; and the final lock breaking.
Toggle sound
using the music button in the top-right corner.

Important board events also trigger brief animated story scenes. Golden keys
glow, enlarge, and rotate clockwise as one clean image; both keyed gates show
one approved unlocking illustration with its embedded key,
doors opening, the explorer passing through a genuinely transparent doorway,
the approved halfway-closing gate frame, and the doors closing behind the child.
The opening and closing recordings begin exactly with their respective door
transitions. The lion and wolf change between their approved walking, roaring or
howling, sleeping, and idle states. If an equipped explorer defeats the lion or
wolf, the animal visibly topples over while the explorer celebrates. If the
animal wins, that same explorer visibly falls down before the existing crying,
fallback, and recovery sequences. Whenever a player falls back, that same
explorer becomes an animated crying child with visible tears until arriving at
the safe space, then switches to a relieved recovery pose. Four individual
human-shaped child avatars use eight transparent animation poses apiece;
visible legs alternate while walking, hands reach when collecting tools, and
arms perform knife or two-handed axe/hammer actions.

- Space 2: collect the first key.
- Space 3: cross the first elevated bridge to 11, bypassing lock 6.
- Space 6: passing the lock without the first key returns the player to space 1.
- Space 10: medical station.
- Space 12: cross the second elevated bridge directly to 18, bypassing lion 17.
- Space 13: collect a knife.
- Space 15: collect an axe.
- Space 17: either a knife or an axe defeats the lion, even when crossing
  without landing. Without either weapon, the player returns to space 10.
- Space 24: hospital.
- Space 25: cross the third elevated bridge directly to 29, bypassing wolf 27.
- Space 26: collect a knife.
- Space 27: a knife is required even when crossing without landing. The wolf
  sends a player without a knife back to space 24.
- Space 31: collect the final key.
- Space 33: land exactly here to collect that explorer's lock-breaking hammer.
  Passing 33 does not collect it. The hammer never opens lock 6 and never
  protects against the lion or wolf.
- Space 35: an exact roll is required. The final key unlocks HOME normally;
  without the key, a collected hammer strikes twice, visibly breaks the final
  lock, opens the gate, and wins. The final key takes priority if both are
  carried. Without either item, the player returns to space 30.

## Source files

- index.html: game interface.
- rules.html: separate complete offline game-rules page loaded inside the guide popup.
- style.css: responsive natural jungle-board interface, event scenes, settings, and dialogs.
- game.js: single image-native SVG board, directly positioned objects, animation,
  dice, inventory, rules, illustrated tutorial, and real multiplayer.
- world3d.js: preserved inactive historical renderer source; never loaded by the app.
- map.jpg: offline illustrated parchment-map artwork.
- art/jungle_board.jpg: owner-approved lush jungle board and river reference.
- art/jungle_terrain.jpg: softened reference terrain that prevents painted-number duplicates.
- art/jungle_natural.jpg: exact user-uploaded jungle image, preserved without
  modifications and verified by its original SHA-256 digest.
- art/*.png: fifteen preserved real-alpha lion, wolf, key, and gate states;
  32 normalized full-body explorer-avatar animation frames; and genuine-alpha
  hammer and broken-gate illustrations.
- art/manifest.json: approved artwork provenance, row topology, bridge rules, and sound map.
- logo.png: Keys & Claws: Quest for Home illustrated title artwork.
- ic_launcher.png: branded Android home-screen icon.
- sounds/*.mp3: standalone offline animal, spoken, and event audio clips.
- sounds/jungle_ambience.mp3: original 22-second looping stereo river,
  waterfall, leaf-rustle, and distant-bird ambience.
- sounds/gate_open.wav and sounds/gate_close.wav: original stereo 48-kHz wooden-gate effects.
- generate_sounds.py: optional reproducible sound-effect generator.
- generate_jungle_ambience.py: optional deterministic stereo ambience generator.
- generate_adventure_sounds.py: reproducibly creates the seven original tool
  pickup, defense, hammer-strike, and lock-breaking sound clips.
- build_apk.py: creates and signs the standalone Android APK.
- native_dex.py: assembles the native Android Wi-Fi/Bluetooth connection bridge.
- validate_apk.py: verifies the manifest, DEX, ZIP, and v1/v2 signatures.
- test_game.js: 112 automated gameplay, ranking, animal/explorer fall, avatar,
  tool, sound, and presentation tests.
- test_multiplayer.js: two independent game instances connected through a real
  TCP socket; verifies ten synchronized turns including hammer pickup and victory.
- test_wifi_four_players.js: four independent game instances connected through
  three real TCP sockets; verifies all four turns, guest renames, spoof rejection,
  synchronized encounters, seventeen turns, isolated hammer inventories,
  continued play after first place, skipped finished explorers, all four final
  ranks, automatic last place, hammer-based victories, and a shared restart.
- test_world3d.js: archived renderer-source preservation and proof that the active
  application has no 3D board, camera toolbar, or second gameplay layer.
- test_jungle_assets.py: independently verifies approved-art and avatar PNG
  alpha, normalized explorer frame sizes, hammer/broken-gate transparency,
  transparent gate passages, tool sounds, approved board topology, and the
  original stereo gate recordings.
- package_source.py: packages all rebuildable source files and the AI master specification.
- Keys_Claws_AI_Master_Specification_3D.md: complete approved rules, natural-board
  requirements, independent Android identity, and future-AI handoff document.

Run the automated game checks with:

    node test_game.js
    node test_multiplayer.js
    node test_wifi_four_players.js
    node test_world3d.js
    python3 test_jungle_assets.py

Build an APK with:

    python3 build_apk.py

Verify the finished APK with:

    python3 validate_apk.py

Create a complete source and documentation archive with:

    python3 package_source.py

The builder requires Python and the cryptography package. Each build creates
a fresh signing certificate; replacing an installed copy from an earlier build
of this same 3D edition requires either the same signing key or uninstalling
the earlier 3D copy. The original 2D edition is unaffected. During development,
the new project can read shared artwork and sounds from the existing 2D project;
the downloadable 3D source archive includes its own complete binary assets and
can rebuild independently. Android installation, phone layout, and paired
Bluetooth should also be verified on real devices before public release.
