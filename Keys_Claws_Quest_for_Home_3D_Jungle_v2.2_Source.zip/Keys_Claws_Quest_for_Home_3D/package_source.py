#!/usr/bin/env python3
"""Package every rebuildable game source and the canonical AI handoff document."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path


PROJECT = Path(__file__).resolve().parent
SHARED_ASSETS = PROJECT if (PROJECT / 'map.jpg').is_file() else PROJECT.parent / 'adventure_android'
OUTPUT = PROJECT.parent / 'Keys_Claws_Quest_for_Home_3D_Jungle_v2.2_Source.zip'
PREFIX = 'Keys_Claws_Quest_for_Home_3D/'


def package() -> Path:
    files = [
        'README.md', 'index.html', 'rules.html', 'style.css', 'game.js', 'world3d.js', 'map.jpg',
        'logo.png', 'ic_launcher.png', 'build_apk.py', 'native_dex.py',
        'validate_apk.py', 'test_game.js', 'test_multiplayer.js',
        'test_wifi_four_players.js', 'test_world3d.js',
        'generate_sounds.py', 'generate_jungle_ambience.py',
        'generate_adventure_sounds.py', 'package_source.py',
        'test_jungle_assets.py',
    ]
    files.extend(sorted(str(item.relative_to(SHARED_ASSETS))
                        for item in (SHARED_ASSETS / 'sounds').iterdir()
                        if item.is_file() and item.suffix.lower() in {'.mp3', '.wav'}))
    files.extend(sorted(str(item.relative_to(PROJECT))
                        for item in (PROJECT / 'art').iterdir()
                        if item.is_file() and item.suffix.lower() in {'.png', '.jpg', '.json'}))
    specification = PROJECT / 'Keys_Claws_AI_Master_Specification_3D.md'
    if not specification.exists():
        specification = PROJECT.parent / 'Keys_Claws_AI_Master_Specification_3D.md'
    if not specification.is_file():
        raise FileNotFoundError('The canonical AI master specification is missing')

    with zipfile.ZipFile(OUTPUT, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for relative in files:
            source = PROJECT / relative
            if not source.is_file():
                source = SHARED_ASSETS / relative
            if not source.is_file():
                raise FileNotFoundError(source)
            archive.write(source, PREFIX + relative)
        archive.write(specification, PREFIX + specification.name)

    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        assert PREFIX + 'native_dex.py' in names
        assert PREFIX + 'test_multiplayer.js' in names
        assert PREFIX + 'test_wifi_four_players.js' in names
        assert PREFIX + 'rules.html' in names
        assert PREFIX + 'world3d.js' in names
        assert PREFIX + 'test_world3d.js' in names
        assert PREFIX + 'test_jungle_assets.py' in names
        assert PREFIX + specification.name in names
        assert PREFIX + 'art/gate_half_closing.png' in names
        assert PREFIX + 'art/jungle_board.jpg' in names
        assert PREFIX + 'art/jungle_terrain.jpg' in names
        assert PREFIX + 'art/jungle_natural.jpg' in names
        assert PREFIX + 'sounds/gate_open.wav' in names
        assert PREFIX + 'sounds/gate_close.wav' in names
        assert PREFIX + 'sounds/jungle_ambience.mp3' in names
        assert PREFIX + 'generate_jungle_ambience.py' in names
        assert PREFIX + 'generate_adventure_sounds.py' in names
        assert PREFIX + 'art/hammer.png' in names
        assert PREFIX + 'art/gate_broken.png' in names
        for explorer in ['ruby', 'river', 'forest', 'violet']:
            for frame in range(1, 9):
                assert PREFIX + f'art/avatar_{explorer}_{frame:02d}.png' in names
        for effect in ['knife_pickup', 'axe_pickup', 'hammer_pickup',
                       'knife_use', 'axe_use', 'hammer_hit', 'lock_break']:
            assert PREFIX + f'sounds/{effect}.mp3' in names
        result = {'archive': str(OUTPUT), 'files': len(names),
                  'bytes': OUTPUT.stat().st_size,
                  'includes_ai_master_specification': True,
                  'includes_native_multiplayer_bridge': True,
                  'wifi_maximum_players': 4,
                  'bluetooth_maximum_players': 2,
                  'includes_separate_offline_rules_page': True,
                  'includes_guided_interactive_tutorial': True,
                  'includes_archived_historical_webgl_source': True,
                  'legacy_webgl_renderer_is_preserved_but_not_loaded': True,
                  'one_background_native_jungle_board': True,
                  'all_printed_board_numbers_hidden': True,
                  'playable_shortcut_bridges': [[3, 11], [12, 18], [25, 29]],
                  'includes_approved_independent_jungle_artwork': True,
                  'includes_detailed_neutral_natural_jungle_background': True,
                  'includes_original_gate_opening_and_closing_sounds': True}
        result.update({
            'includes_looping_offline_jungle_ambience': True,
            'includes_animated_rivers_and_waterfalls': True,
            'includes_image_native_2_5d_depth_effects': True,
            'includes_independent_ambience_and_living_jungle_settings': True,
            'full_body_3d_style_explorer_avatars': 4,
            'normalized_explorer_animation_frames': 32,
            'hammer_exact_landing_space': 33,
            'hammer_opens_only_final_gate': True,
            'dedicated_tool_pickup_and_use_sounds': 7,
            'wifi_synchronized_hammer_victory': True,
            'ranked_multiplayer_continues_after_first_winner': True,
            'finished_explorers_skip_future_turns': True,
            'automatic_last_place_and_final_standings': True,
            'wifi_synchronized_four_explorer_rankings': True,
            'animal_and_explorer_loser_fall_animations': True,
        })
    print(json.dumps(result, indent=2))
    return OUTPUT


if __name__ == '__main__':
    package()
