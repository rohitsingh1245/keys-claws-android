# Keys & Claws: Quest for Home 3D

## Master Game Specification and AI Development Context

**Document status:** Canonical implementation handoff  
**Current app version:** 2.0-ranked-jungle-showdown (version code 11)  
**Last updated:** 25 August 2026  
**Primary platform:** Android 7.0 or later  
**Current test baseline:** 112 passing gameplay, ranked multiplayer, animal/explorer fall, full-body explorer, hammer, living-jungle, audio, and onboarding tests, 36 archived-renderer preservation checks, a genuine two-instance TCP integration test covering ten synchronized turns, and a genuine four-instance/three-socket TCP integration test covering seventeen synchronized ranked turns

---

## 1. How an AI Should Use This Document

This file is the source of truth for implementing, reviewing, or modifying the
game **Keys & Claws: Quest for Home**. Its historical Android package still
contains `3d` so this edition remains independent; never overwrite, rename,
or change the existing original 2D game or its files. The latest explicit owner
decision removes the visible 3D concept and makes the natural jungle image
itself the only gameplay board.

When working on the project:

1. Preserve all rules marked **Required** unless the owner explicitly requests
   a rule change.
2. Treat the distinction between **landing on**, **reaching**, and **passing** a
   space as important. Several earlier bugs came from checking an obstacle only
   when the final destination was exactly that space.
3. Do not advertise planned features as functional.
4. Keep every player's state separate.
5. Update automated tests whenever behavior changes.
6. Rebuild and validate the APK after modifying game or Android packaging code.
7. Preserve the owner-approved distinction: either an axe or a knife defeats
   the lion, but only a knife defeats the wolf.
8. Place all gameplay objects directly on the one owner-approved natural jungle
   image; do not load a WebGL board, second landscape, perspective camera,
   floating labels, or camera controls.
9. Keep the historical Android package and deliverable filenames distinct from
   the original edition so the two games can coexist.

If the code conflicts with the Required Rules in this document, correct the
code or ask the owner whether the document itself should be changed.

---

## 2. Product Identity

| Field | Canonical value |
| --- | --- |
| Visible game title | **Keys & Claws: Quest for Home** |
| Historical Android app label | **Keys & Claws: Quest for Home 3D** |
| Theme | One detailed natural jungle-image board with directly placed keys, locks, animated wild animals, weapons, healing points, shortcuts, and a journey home |
| Audience | Family and casual players |
| Current orientation | Landscape |
| Current play modes | Pass-and-play on one Android device, local Wi-Fi, or paired Classic Bluetooth |
| Players | 1–4 on one device; 2–4 across separate Wi-Fi devices; exactly 2 across paired Bluetooth devices |
| Board | START, 35 internally numbered but visually unnumbered path spaces, then HOME |
| Win condition | Earn the next finishing rank by landing exactly on space 35 with the final key from space 31 or hammer from space 33; multiplayer continues until only one unranked explorer remains |
| Android package | `com.keysandclaws.questforhome3d` |
| Android activity | `com.keysandclaws.questforhome3d.MainActivity` |
| Minimum Android API | 24 (Android 7.0) |
| Target Android API | 36 |

The existing illustrated logo, launcher icon, green-and-gold colors, parchment
styling, and approved title remain recognizable. The `3D` suffix stays only in
the historical Android application label, app package, project, APK, source
archive, and this independent handoff filename to preserve installation
identity. Never add a 3D badge or 3D wording to the visible game interface.

Before commercial publication, perform an independent trademark search for the
name and legal review of all branding and store assets. This document is a
technical specification, not proof of trademark or copyright clearance.

---

## 3. Core Game Objective

Each explorer starts at **START**, moves along the internally numbered trail,
whose board markers intentionally show no printed numbers, collects the
required keys and defensive items, survives obstacles, reaches the final lock,
and tries to enter HOME.

Each player who:

1. lands on space 31 and collects the final key, or lands exactly on space 33
   and collects the lock-breaking hammer;
2. later lands **exactly** on space 35; and
3. unlocks the final door with the key or breaks its lock with the hammer

earns the next finishing rank. The first explorer to arrive is the overall
champion, but adventures with three or four explorers do **not** end at that
point. Finished explorers stop taking turns while the others continue racing.
When one of the final two active explorers reaches HOME, the remaining explorer
automatically receives last place and the complete final rankings are shown.

Reaching a number greater than 35 is not allowed. If a roll would overshoot
space 35, the player's position does not change and the turn ends.

---

## 4. Required Setup and Turn Rules

### 4.1 Players

- Single-device pass-and-play supports one to four explorers.
- Wi-Fi multiplayer supports two, three, or four explorers on separate devices.
- Paired Bluetooth multiplayer supports exactly two explorers on two phones.
- Two players are selected by default on the setup screen.
- Every explorer has a customizable name.
- A name can be changed before the game or during the game.
- Names are normalized, limited to 22 characters, and escaped before display.
- Each explorer has an individual color and one of four original full-body,
  pre-rendered 3D-style human child avatars with visible hands, moving limbs,
  expressive crying/recovery poses, and matching weapon actions.
- Each explorer owns a separate position, inventory, dice sequence, and roll
  count. Items collected by one player never apply to another player.

### 4.2 Pass-and-Play

- Pass-and-play gameplay occurs on one device; Wi-Fi and Bluetooth are separate
  optional cross-device modes.
- Players take turns in order: Player 1, Player 2, Player 3, Player 4, then back
  to Player 1.
- The next unfinished player's turn becomes active automatically when the
  previous turn finishes; already-ranked explorers are always skipped.
- There must be **no turn-confirmation popup** and no “I'M READY” button.
- The active player's name, position, and inventory must be visible.
- With three or four explorers, the game continues after first place until one
  of the final two remaining explorers reaches HOME.
- A three-player race awards first, second, and automatic third place. A
  four-player race awards first, second, third, and automatic fourth place.
- Two-player games finish after the first arrival and automatically award the
  other explorer second place; a solo explorer receives first place.
- The game stops accepting rolls only after every finishing rank is decided.
- Current earned ranks are visible in the explorer list; the final themed
  victory popup displays every explorer in finishing order.

### 4.3 Turn Sequence

For each turn:

1. The active player taps the die.
2. The die animates and produces one value from 1 to 6.
3. If the roll would exceed 35, the player stays in place.
4. Otherwise, the piece moves through every intermediate space in order.
5. Mandatory checkpoints are evaluated as soon as they are reached, even when
   the roll's final destination is farther ahead.
6. If no checkpoint stops the movement, apply the landing effect of the final
   destination.
7. If the explorer reaches HOME, assign the next rank and remove them from
   subsequent turns. When one unfinished explorer remains, assign automatic
   last place and show final standings.
8. Otherwise activate the next unfinished player automatically.

---

## 5. Dice Rules

### 5.1 Required Player Experience

- The die is an elegant six-sided die with correct pip layouts for 1–6.
- It must be easy to tap.
- The rolling animation must not influence the actual result.
- A fixed number must not appear as though it is favored at the start of every
  game.
- Different players must not share one mutable dice queue.

### 5.2 Current Fairness Algorithm

Each player has an independent shuffled “bag” containing:

`[1, 2, 3, 4, 5, 6]`

The rules are:

- Shuffle a fresh bag independently for each player.
- Draw one result from that player's bag on each turn.
- Refill and reshuffle when the bag is empty.
- Avoid repeating the same face across the boundary between two bags.
- Every face therefore occurs exactly once within each group of six rolls for
  that player.
- Use `crypto.getRandomValues` with rejection sampling where available.
- Use `Math.random` only as a compatibility fallback.
- Cosmetic animation frames must not consume values from a player's real bag.

If a future developer replaces this algorithm, the replacement must be
demonstrably fair and must not reintroduce repeated or player-specific bias.

---

## 6. Canonical Board Rules

### 6.1 Complete Space Map

| Location | Type | Required result |
| --- | --- | --- |
| START | Start area | All explorers begin here. START is separate from numbered space 1. |
| 1 | Normal | No item or special effect. It is the fallback destination for the first lock. |
| 2 | First key | Landing exactly here permanently gives that player the first key. Merely passing space 2 does not collect it. |
| 3 | First elevated bridge | Landing exactly here takes the player directly to space 11. This is a legitimate bypass of the lock on space 6. |
| 4–5 | Normal | No item or special effect. |
| 6 | First lock checkpoint | A player cannot reach or pass this space without the first key. Without the key, return immediately to space 1. With the key, animate the key and open the lock, then continue the remaining movement. |
| 7–9 | Normal | No item or special effect. The trail connects 7 directly to 8. |
| 10 | Medical point | Healing/safety presentation and relief sound. It is the lion fallback destination. There is currently no health-number system. |
| 11 | Normal | No item or special effect; destination of the first elevated bridge. |
| 12 | Second elevated bridge | Landing exactly here takes the player directly to space 18 and legitimately bypasses lion 17. |
| 13 | Knife | Landing exactly here permanently gives that player a knife. |
| 14 | Normal | No item or special effect. |
| 15 | Axe | Landing exactly here permanently gives that player an axe. An axe defeats lion 17 but never defeats wolf 27. |
| 16 | Normal | No item or special effect. |
| 17 | Lion checkpoint | A player cannot reach or pass this space without either a knife or an axe. Without either weapon, show the lion encounter and return the crying player to medical point 10. Either weapon lets the player defeat the lion and continue any unused movement. |
| 18–23 | Normal | No item or special effect; 18 is the destination of the second elevated bridge. |
| 24 | Hospital | Healing/safety presentation and relief sound. It is the wolf fallback destination. There is currently no health-number system. |
| 25 | Third elevated bridge | Landing exactly here takes the player directly to space 29, crosses the river on the approved bridge, and legitimately bypasses wolf 27. |
| 26 | Second knife | Landing exactly here permanently gives that player a knife. Passing it does not collect it. |
| 27 | Wolf checkpoint | A player cannot reach or pass this space without a knife. Without a knife, show the wolf encounter and return the crying player to hospital 24. A knife allows the player to defend, remain safe, and continue any unused movement. |
| 28–30 | Normal | No item or special effect. Space 30 is the fallback destination for the final lock. |
| 31 | Final key | Landing exactly here permanently gives that player the final key. Passing it does not collect it. |
| 32 | Normal | No item or special effect. |
| 33 | Lock-breaking hammer | Landing exactly here permanently gives that player a hammer. Passing this space does not collect it. The hammer works only against final lock 35; it never opens gate 6 and never protects against either animal. |
| 34 | Normal | No item or special effect. |
| 35 | Final lock | The player must land exactly here. With the final key, open the lock and earn the next finishing rank. Without that key but carrying the hammer, strike twice, visibly break the lock, and earn the next rank. With neither item, return to space 30—not space 31. When both items exist, the final key takes priority. The remaining explorers keep playing until only one remains. |
| HOME | Finish area | Entered only after successfully unlocking or breaking final lock 35; finished explorers earn the next place and never take another turn. |

### 6.2 Mandatory Checkpoints vs. Landing Effects

This distinction is critical.

**Mandatory checkpoints are evaluated while moving through the board:**

- Space 6: first lock requires first key.
- Space 17: lion requires a knife **or** an axe.
- Space 27: wolf requires knife.

For example, a player on space 14 who rolls 5 moves toward space 19. The player
reaches space 17 during that movement. Without either a knife or an axe,
movement stops and the player returns to space 10. The player cannot jump over
the lion just because 19 was the intended destination.

**Landing effects happen only when the roll ends exactly on the space:**

- Collecting keys on spaces 2 and 31.
- Collecting knives on spaces 13 and 26.
- Collecting the axe on space 15.
- Collecting the lock-breaking hammer on space 33.
- Taking elevated shortcut bridges on spaces 3, 12, and 25.
- Triggering standalone medical/hospital presentation on spaces 10 and 24.
- Evaluating the final lock on space 35.

### 6.3 Shortcut Exceptions

- Landing on space 3 transfers the player directly to space 11 and safely
  bypasses the first lock.
- Landing on space 12 transfers the player directly to space 18 and safely
  bypasses the lion.
- Landing on space 25 transfers the player directly to space 29 and safely
  bypasses the wolf, even without a knife.
- A player who merely passes space 3, 12, or 25 does not receive its shortcut.
- A shortcut route is a direct special route. Do not evaluate skipped spaces as
  ordinary intermediate movement.

### 6.4 Items

Current inventory fields:

| Item | Source | Current effect | Consumed? |
| --- | --- | --- | --- |
| First key | Space 2 | Opens checkpoint 6 | No |
| Knife | Space 13 or 26 | Defeats lion 17 and wolf 27 | No |
| Axe | Space 15 | Defeats lion 17 only; never defeats wolf 27 | No |
| Final key | Space 31 | Opens final lock 35 | No |
| Hammer | Space 33 | Breaks final lock 35 if the final key is missing; never opens gate 6 and never protects against lion 17 or wolf 27 | No |

The owner explicitly restored the axe's ability to defeat the lion. Never
silently remove that behavior, and never extend it to the wolf. The owner also
approved the hammer exclusively as an easier alternative for the final lock;
never extend it to the first lock or animal-defense checkpoints.

---

## 7. Movement and Resolution Pseudocode

```text
takeTurn(player, dieValue):
    if game is busy, not started, completely ranked, or current explorer already finished:
        ignore input

    if player.position + dieValue > 35:
        show exact-roll message
        finish turn

    destination = player.position + dieValue
    landingAlreadyHandled = false

    for space from player.position + 1 through destination:
        animate player to space

        if space == 6:
            if player does not have firstKey:
                cry and return player to 1
                finish movement
            else:
                animate first lock opening

        if space == 17 or space == 27:
            show the relevant animal encounter
            protected = player has knife OR (space == 17 AND player has axe)
            if not protected:
                cry and return to 10 for lion or 24 for wolf
                show treatment relief
                finish movement
            else:
                show successful defense
                if space is the intended destination:
                    landingAlreadyHandled = true

    if movement was not stopped and landing was not already handled:
        process final landing effect

    if player reached HOME:
        assign the next finishing rank
        if exactly one explorer has no rank:
            automatically assign that explorer last place
            show the champion and every final standing
            finish the adventure
        else if other unranked explorers remain:
            continue the adventure

    if the adventure is not completely ranked:
        advance automatically to the next unfinished player
```

The exact animal landing must be processed once, not once in the movement loop
and again in the landing handler.

---

## 8. Required Visual Behavior

### 8.1 Board and Pieces

- Use the owner-approved lush, premium, family-friendly jungle-board artwork.
- Use the exact owner's uploaded jungle image `1000254601.png` as the crisp,
  natural board background, preserving its bytes, foliage, winding cobblestone
  route, stone banks, rivers, and waterfalls without replacing or editing it.
- Remove all baked numbers, animal figures, keys, gates, player pieces, logos,
  controls, signs, bridges, and buildings from the neutral background so the
  separately rendered gameplay objects never appear twice.
- Make the exact uploaded natural background the only visible board; position
  all subtle unnumbered stones and approved object images directly on its paths.
- Track exactly 35 unique spaces internally at image-aligned row centers `548`,
  `421`, `311`, `208`, and `106`, but never print a number or number badge on
  the board. Preserve hidden `data-space` and accessibility metadata.
- Position both spaces 21 and 22 at horizontal coordinate `740`, safely on the
  existing dry right-hand turn, and curve explorer movement around the dry bend.
- Keep five continuous lanes: 1–7, 8–14, 15–21, 22–27, and 28–35.
- Permit only the row turns 7→8, 14→15, 21→22, and 27→28.
- Keep the background's visibly impassable river between 22–27 and 28–35;
  its only ordinary path crossing is the 27→28 turn, with the explicitly
  approved elevated 25→29 shortcut bridge as the sole separate river crossing.
- Render 3→11, 12→18, and 25→29 as distinct elevated wooden shortcut bridges.
- Never duplicate an internal space, omit 15, or connect 8 to 21.
- Display START and HOME separately.
- Use four original full-body, pre-rendered 3D-style child-explorer avatars
  with distinct Ruby, River, Forest, and Violet color identities. Keep the
  background flat and unchanged; only the separately composited character
  artwork has a sculpted 3D illusion.
- Give each explorer eight normalized 256×256 genuine-alpha poses: idle,
  left-leg walking, right-leg walking, pickup/reaching, knife defense,
  two-handed axe or hammer action, expressive crying, and recovery/victory.
  Alternate the leg poses while walking and visibly animate hands and arms.
- Use the approved real-alpha standalone lion, wolf, key, and gate artwork as
  individually composited board and story-scene layers; never bake them into
  the jungle background.
- Display exactly one approved image for each lion, wolf, key, or gate. Never
  draw an old procedural animal, key, padlock, or shackle underneath or on top
  of its approved replacement. Never initialize old 3D meshes as a fallback.
- Key collection must show one rotating approved golden key. The approved gate
  unlocking image already contains its own key; never place a second key over it.
- Render exactly one transparent golden hammer directly on hidden space 33.
  Its pickup scene must feature the active explorer, a reaching hand, and the
  dedicated hammer-pickup sound; passing the space must not collect it.
- Show all three wooden shortcut bridges clearly. Keep fallback movement guides
  invisible so they do not cover the natural jungle paths.
- Move a piece smoothly between each numbered space. Do not teleport it during
  ordinary die movement.
- Add image-native 2.5D atmosphere without replacing the exact background:
  four subtle moving river-reflection lanes, three falling-water/foam/mist
  groups aligned to the existing waterfalls, twelve gentle fireflies, small
  foreground foliage, bridge/animal/gate/player ground shadows, breathing
  approved lion and wolf images, glowing approved keys, and at most four pixels
  of foreground pointer parallax.
- Keep the **Living jungle** setting independent from gameplay. Pause all
  decorative motion when obstacle animations are disabled and respect the
  operating system's reduced-motion preference. Never add another background,
  canvas, camera, projected labels, or visible numbered spaces.

### 8.2 Current Animated Event Scenes

| Event | Required presentation |
| --- | --- |
| Key collected | Highlight the board key, enlarge it, sparkle, and rotate it clockwise. |
| Knife or axe collected | Show the actual active full-body explorer reaching for the correct tool, highlight its board icon, and play that tool's own pickup clip. |
| Hammer collected | Only on an exact landing at space 33, show the active explorer reaching for the glowing transparent hammer and play the dedicated hammer-pickup clip. |
| Lock opened | Show the approved unlocking gate with its embedded golden key, open the jungle gate with its opening sound, let the child pass through the genuinely transparent doorway, display the approved halfway-closing frame, and close the doors with the separate closing sound. Never overlay a second key, old padlock, or old shackle. |
| Lion | Transition the existing approved lion artwork through walking → roaring → peaceful sleeping → idle; synchronize its roar and the active explorer's correct knife or two-handed axe defense. If the human wins, visibly topple the lion; if the lion wins, visibly topple that same explorer. |
| Wolf | Transition the existing approved wolf artwork through walking → howling → peaceful sleeping → idle; synchronize its howl and the active explorer's knife-defense pose. If the human wins, visibly topple the wolf; if the wolf wins, visibly topple that same explorer. |
| Fallback | Replace the ordinary piece temporarily with that same player's enlarged full-body crying avatar, visibly animate tears, and keep its matching crying-child token on the fallback route. |
| Medical treatment | Show the same active explorer's happy full-body recovery pose and play the relieved “ahh” sound. |
| Final hammer use | If the final key is missing but the active explorer owns the hammer, animate two synchronized two-handed strikes, play two hammer-hit sounds, switch to a genuine-alpha broken-lock gate illustration, burst lock fragments with the lock-break sound, then open the final gate and enter HOME. |
| Shortcut | Show a happy message and play “hooray.” |
| Ranked finish | Unlock or break the final lock according to the explorer's inventory, show their victory avatar, award the next place, and keep the other unfinished explorers playing. |
| Final standings | Once only one unfinished explorer remains, assign automatic last place and display the first-place champion plus every ranked explorer in a compact themed popup. |

### 8.3 Movement Speeds

Settings expose three speeds:

- Slow: default; full movement timing.
- Normal: approximately 69% of slow timing.
- Fast: approximately 42% of slow timing.

Ordinary slow movement currently uses eight eased animation frames per space.
If animations are disabled, the rules and final positions must remain exactly
the same.

---

## 9. Required Audio Behavior

The app works offline and includes separate audio clips for different events.

| Audio ID | Scenario |
| --- | --- |
| `step` | Die/movement feedback |
| `good` | Item or successful positive event |
| `bad` | Locked or unsuccessful event feedback |
| `lion` | Lion roar |
| `wolf` | Wolf howl |
| `fight` | Animal defense/struggle |
| `knife_pickup` | Exact knife pickup at space 13 or 26 |
| `axe_pickup` | Exact axe pickup at space 15 |
| `hammer_pickup` | Exact hammer pickup at space 33 |
| `knife_use` | Animated knife defense against lion or wolf |
| `axe_use` | Animated two-handed axe defense against lion only |
| `hammer_hit` | Each of the two animated final-lock hammer strikes |
| `lock_break` | Final-lock shackle and padlock break after the second strike |
| `cry` | Any forced fallback or failed lock/animal encounter |
| `relief` | Medical point or hospital treatment |
| `hurray` | Shortcut or successful defense celebration |
| `win` | Final victory fanfare |
| `gate_open` | Original stereo 48-kHz jungle-gate opening WAV; starts as doors begin to open |
| `gate_close` | Original stereo 48-kHz jungle-gate closing WAV; starts at the halfway-closing transition |
| `jungle_ambience` | Original 22-second offline stereo loop with flowing river, waterfall, rustling foliage, and distant jungle birds |

Important sequence examples:

- Unprotected lion: `step → lion → fight → cry → relief`
- Protected lion: `step → lion → fight → hurray`
- Unprotected wolf: `step → wolf → fight → cry → relief`
- Shortcut: `step → hurray`
- Key: `step → good`
- Successful gate: `step → good → gate_open → gate_close`
- Knife pickup: `step → knife_pickup`
- Axe pickup: `step → axe_pickup`
- Hammer pickup: `step → hammer_pickup`
- Hammer-only final gate: `hammer_hit → hammer_hit → lock_break → gate_open → gate_close`

Sound can be disabled in Settings. Disabling sound must not alter game logic.
The app uses seventeen event MP3 files, one independent looping stereo
jungle-ambience MP3, and two original stereo 48-kHz gate WAV files, with
synthesized Web Audio
fallbacks for event sounds. The 22-second ambience plays softly only during an
active adventure, starts after a real user gesture, loops locally, stops under
the global sound switch or its separate **Jungle ambience** switch, and pauses
whenever the app becomes hidden. It never requires internet access.

---

## 10. Settings

The settings page is available from the setup screen and the top toolbar.

Current functional options:

- Sound effects: on/off.
- Jungle ambience: independent river/waterfall/birds soundtrack on/off;
  the master sound switch still mutes it.
- Living jungle: flowing water, waterfalls, fireflies, scenery depth, and
  subtle parallax on/off.
- Obstacle animations: on/off.
- Player movement speed: slow/normal/fast.
- Pass & Play: active play mode.
- Wi-Fi Multiplayer: two, three, or four devices on the same local network or hotspot.
- Bluetooth Multiplayer: two previously paired nearby Android devices.
- Rules & Guided Tutorial: open the separate offline rules page and illustrated onboarding.

Settings are persisted locally on the device.

Both cross-device buttons are enabled because the APK includes a real native
TCP/RFCOMM transport, host/join lobby, authoritative turn protocol, connection
status, runtime Bluetooth permission handling, and automated integration tests.

### 10.1 Separate Game Rules and Guided Tutorial

The full game rules live in their own offline `rules.html` page, not in a second
game board or a permanently visible gameplay panel. The main application loads
that document on demand inside a scrollable popup with a close control, a return
button, and an optional guided-tutorial action.

Navigation entry points:

- Setup screen: **HOW TO PLAY** and **GUIDED TUTORIAL**.
- In-game toolbar: compact **?** help button.
- Sidebar field guide: **READ FULL RULES**.
- Settings: **RULES & GUIDED TUTORIAL**.

The rules page documents the 35 hidden board positions, fair six-sided movement,
independent explorer turns and gear, first key and first gate, all three exact-
landing bridges, knife and axe locations, the separate lion and wolf defenses,
medical and hospital fallbacks, encounter winner/loser outcomes,
pass-and-play/Wi-Fi/Bluetooth player limits,
the final key, the exact-landing hammer at 33 and its final-gate-only
restriction, the exact winning roll, overshoot behavior, and final-lock fallback
when neither item is held, continued three-/four-player races after first place,
skipped finished explorers, and automatically assigned last place. It reuses
the approved transparent lion, wolf, key, hammer, and gate artwork.

The separate illustrated popup tutorial has seven ordered steps:

1. The quest from START to HOME.
2. Dice, movement, independent explorer turns, and equipment.
3. First key, locked gate, final key, and the final-lock-only hammer.
4. Shortcut bridges `3→11`, `12→18`, and `25→29`.
5. Lion, wolf, knives, axe, medical, and hospital rules.
6. One-device, two-to-four-device Wi-Fi, and paired Bluetooth play.
7. Exact final roll, final key or hammer, HOME, continued ranked play, and
   final victory standings.

The tutorial supports Back, Next, close, full-rule navigation, Escape, left and
right arrow keys, and restores the rules popup if launched from it. Opening or
closing either surface must not change explorer positions, active turns,
inventories, connection state, artwork, or existing board rules.

---

## 11. Multiplayer Modes and Networking Architecture

### 11.1 Currently Implemented

- Single-device pass-and-play/hotseat.
- One to four players.
- Automatic turn rotation.
- Separate state for every player.
- No turn-confirmation popup.
- Wi-Fi multiplayer between two, three, or four devices on the same local network.
- Paired Classic Bluetooth multiplayer between exactly two nearby phones.
- Configurable player names on every connected device.
- Host-authoritative dice and synchronized board/obstacle animations.
- Identical finishing ranks, skipped completed turns, automatic last place,
  and final standings on every connected device.

### 11.2 Connection Setup

**Wi-Fi:** connect all two, three, or four devices to the same Wi-Fi router or
hotspot. Select Wi-Fi Multiplayer on each device. The host chooses **2 PLAYERS**,
**3 PLAYERS**, or **4 PLAYERS**, taps CREATE A GAME, and shares the displayed
local IPv4 address. Each guest enters that address and taps JOIN THE GAME. The
adventure begins automatically after all selected explorers join. Android uses
one TCP `ServerSocket` and up to three independent guest `Socket` connections
on port `49735`.

**Bluetooth:** pair both phones in Android system settings first and allow the
Nearby devices permission. Select Bluetooth Multiplayer on both phones. The
host taps CREATE A GAME. The guest chooses the host's already-paired Bluetooth
MAC address and taps JOIN THE GAME. Android uses Classic Bluetooth RFCOMM with
UUID `f7cbf6f5-24fa-4f6e-b6e8-31fbd96a4440`.

No internet service, online account, cloud matchmaking, Bluetooth scanning, or
device discoverability request is required. Bluetooth-capable hardware and
successful system-level pairing are required.

### 11.3 Authoritative Host Protocol

One authoritative host controls:

- Player order and active turn.
- Valid dice result.
- Movement and checkpoint evaluation.
- Inventory updates.
- Each finishing-rank decision, completed-player turn skipping, and final winner.
- Increasing turn revision numbers.

Each guest submits `ROLL_REQUEST`; it never submits an unverified board position
or chooses its own die result. The host checks the guest's originating socket
against its assigned player slot, draws from its authoritative per-player fair
dice bag, and broadcasts `ROLL` to all connected devices. Every device executes
the same checkpoint, movement, animation, inventory, audio, and victory code.

Transport messages are JSON strings framed with Java `DataOutputStream.writeUTF`
and `DataInputStream.readUTF`:

```json
{"type":"HELLO","name":"Guest Explorer","clientId":"unique-device-id"}
{"type":"LOBBY","joined":3,"expected":4}
{"type":"START","names":["Host","River","Forest","Violet"],"clientIds":["host","river-id","forest-id","violet-id"],"revision":0}
{"type":"ROLL_REQUEST","player":1,"revision":0}
{"type":"ROLL","player":0,"value":3,"revision":1}
{"type":"NAME","player":1,"name":"New Guest Name"}
```

The receiver rejects unexpected players, invalid die values, duplicate
revisions, stale revisions, and rolls that do not match the active turn. Only
the device associated with the active explorer can press its die.

Minimum synchronized state:

```json
{
  "gameId": "string",
  "revision": 0,
  "currentPlayerIndex": 0,
  "turns": 0,
  "won": false,
  "rankings": [],
  "players": [
    {
      "id": "string",
      "name": "string",
      "color": "#RRGGBB",
      "avatar": "ruby | river | forest | violet",
      "position": 0,
      "firstKey": false,
      "knife": false,
      "axe": false,
      "finalKey": false,
      "hammer": false,
      "finished": false,
      "rank": 0,
      "lastPlace": false,
      "rolls": 0
    }
  ]
}
```

Additional acceptance requirements:

- Prevent multiple devices from rolling for the same turn.
- Ignore duplicate or stale messages using a revision or turn identifier.
- Display connection failures and stop remote turns after disconnection.
- Do not claim automatic reconnection: reconnect/resume is not implemented.
- Handle a host leaving the game with a visible connection error.
- Show connection status and meaningful recovery instructions.
- Request only the Android permissions required by the chosen transport.
- Retain offline single-device pass-and-play.

### 11.4 Features Not Implemented

- Wi-Fi games spanning more than four devices.
- Bluetooth games spanning more than two devices.
- Online matchmaking across different networks.
- Automatic discovery of unpaired Bluetooth devices.
- Automatic reconnect/resume after a dropped connection.
- Player accounts, cloud saves, or internet-hosted sessions.

---

## 12. Current Data Model

The JavaScript state conceptually contains:

```text
GameState
  selectedCount: 1..4
  players: Player[]
  current: active player index
  busy: blocks duplicate rolls during animation
  started: whether a game is active
  turns: total completed/started turns
  won: whether all final ranks are decided
  rankings: ordered player indexes by earned finishing rank
  finishEvents: actual finishers and the automatically assigned last place
  lastFinishNotice: short non-blocking announcement while others keep racing
  sound: sound setting
  ambience: independent environmental soundtrack setting
  livingJungle: image-native 2.5D scenery setting
  ambientPlaying: whether the local stereo ambience loop is currently active
  animations: animation setting
  movementSpeed: slow | normal | fast
  playMode: hotseat | wifi | bluetooth
  customNames: remembered player names
  lastRoll: latest die value
  soundEvents: recent sound event IDs
  visualEvents: recent visual event records
  network:
    transport: wifi | bluetooth
    role: host | guest
    connected: boolean
    localPlayer: 0 | 1 | 2 | 3
    expectedPlayers: 2 | 3 | 4 for Wi-Fi, always 2 for Bluetooth
    connectedGuests: 0..3
    clientIds: ordered host/guest device identifiers
    revision: monotonically increasing turn number
    waitingForRoll: prevents duplicate guest requests
    localName: chosen player name

Player
  name
  color
  avatar: ruby | river | forest | violet
  position: 0 for START, otherwise 1..35
  firstKey
  knife
  axe
  finalKey
  hammer
  finished: whether the explorer already has a final rank
  rank: 0 before finishing; otherwise 1..number of explorers
  lastPlace: whether the final remaining position was assigned automatically
  rolls
  diceBag
  lastDie
```

Temporary animation fields such as `animatedPoint` and `expression` must be
removed when their animations finish.

---

## 13. Current Technical Architecture

The current project is a self-contained Android WebView application with one
SVG gameplay board drawn directly onto the owner-approved natural jungle image
and a native Android Wi-Fi/Bluetooth transport exposed through a
runtime-annotated `KeysClawsNative` JavaScript interface. All graphics, sounds,
game rules, and network bridge code are bundled offline. The former WebGL
renderer remains as inactive archival source and is never loaded or initialized.

### 13.1 Main Files

| File | Responsibility |
| --- | --- |
| `index.html` | App layout, setup, game board shell, settings, Wi-Fi/Bluetooth lobby, rename dialog, rules popup, guided tutorial popup, compact live rank display, and final standings interface |
| `rules.html` | Separate complete offline game-rules page with approved keys, gates, animals, bridges, exact hammer/final-lock restrictions, continued ranked multiplayer, automatic last place, and victory conditions |
| `style.css` | Responsive single-image jungle board, full-body walking/crying/recovery avatars, visibly toppling defeated animals/explorers, tool pickup/defense/hammer-strike animations, compact final standings, flowing water, reduced-motion behavior, event scenes, and tutorial slides |
| `game.js` | One image-native SVG board, four eight-pose explorer avatars, exact-33 hammer rules, living-animal loser-fall scenes, multi-finisher rankings, completed-turn skipping, automatic last place, final standings, tool audio, living-water layers, tutorial/navigation, and host-authoritative networking |
| `world3d.js` | Inactive historical WebGL renderer source preserved for project history; never referenced by the active HTML, JavaScript, or CSS |
| `map.jpg` | Offline parchment-map background |
| `art/jungle_board.jpg` | Approved lush jungle-board and river-barrier reference |
| `art/jungle_terrain.jpg` | Softened approved terrain derivative; avoids showing numbers baked into the reference twice |
| `art/jungle_natural.jpg` | Exact 1536×864 user-uploaded natural jungle background, copied without changing its original JPEG bytes |
| `art/*.png` | Fifteen preserved approved transparent lion, wolf, key, and gate states; 32 genuine-alpha 256×256 full-body explorer animation frames; transparent golden hammer; transparent 620×413 broken-lock gate |
| `art/manifest.json` | Approved artwork provenance, four avatar identities/eight poses, exact-landing hammer restrictions, ranked-multiplayer contract, human/animal loser-fall outcomes, 7/7/7/6/8 row topology, bridges, and gate/tool-sound mapping |
| `logo.png` | Full illustrated title logo |
| `ic_launcher.png` | Android launcher icon |
| `sounds/*.mp3` | Seventeen distinct offline event clips, including seven dedicated knife/axe/hammer pickup/use/lock-break effects, plus the original 22-second stereo `jungle_ambience.mp3` loop |
| `sounds/gate_open.wav`, `sounds/gate_close.wav` | Original independent 48-kHz stereo wooden-gate opening and closing recordings |
| `generate_sounds.py` | Optional reproducible sound generator |
| `generate_jungle_ambience.py` | Optional deterministic original stereo river, waterfall, foliage, and bird soundtrack generator |
| `generate_adventure_sounds.py` | Reproducible original knife/axe/hammer pickup, knife/axe defense, hammer strike, and lock-break MP3 generator |
| `build_apk.py` | Builds the standalone signed APK without a conventional Android SDK project |
| `native_dex.py` | Assembles the native Activity, real TCP/RFCOMM sockets, runtime JavaScript bridge annotations, Bluetooth permission request, and background networking worker |
| `validate_apk.py` | Verifies permissions, manifest, resources, DEX checksums, JavaScript bridge annotations, native transport APIs, ZIP structure, and APK signatures |
| `test_game.js` | 112 automated gameplay, ranked multiplayer, skipped completed turns, automatic last place, animal/explorer loser falls, avatar, exact hammer, living jungle, rules/tutorial, audio, settings, and fairness tests |
| `test_multiplayer.js` | Runs two separate game instances over an actual TCP socket and verifies ten synchronized turns, isolated inventories, shortcuts, lion defense, exact hammer collection, first-place victory, and automatic second place |
| `test_wifi_four_players.js` | Runs four separate game instances over three actual TCP sockets and verifies four-device turn ownership, host authority, spoof rejection, seventeen synchronized turns, continued play after first/second place, skipped finished explorers, all four ranks, automatic last place, and shared restart |
| `test_world3d.js` | Checks the historical renderer remains archived while proving the active application never loads its board, camera controls, or duplicate layers |
| `test_jungle_assets.py` | Decodes all approved, avatar, hammer, and broken-gate PNGs without third-party packages to verify real alpha, normalized avatar sizes, gate passages, hammer restrictions, seven tool sounds, approved board topology, and original stereo gate recordings |
| `package_source.py` | Builds the complete source archive, including this canonical master specification |
| `README.md` | Installation, gameplay, and source instructions |

### 13.2 Android Packaging

- App label: `Keys & Claws: Quest for Home 3D`
- Package: `com.keysandclaws.questforhome3d`
- Current version name: `2.0-ranked-jungle-showdown`
- Current version code: `11`
- Minimum API: `24`
- Target API: `36`
- Orientation: landscape
- `android.permission.INTERNET`: local-network TCP sockets; internet service is
  not required.
- `android.permission.ACCESS_WIFI_STATE`: display the host's local IP address.
- `android.permission.BLUETOOTH`: legacy paired-device access through Android 11;
  declared with `maxSdkVersion=30`.
- `android.permission.BLUETOOTH_CONNECT`: paired-device communication on Android
  12 and newer; requested at runtime.
- Bluetooth scanning, Bluetooth advertising, and location permissions are not
  requested.
- Assets: fully offline
- APK signatures: v1 and v2
- Launcher icon: compiled Android drawable resource
- Separate Android application identity: the original 2D and independent editions
  can be installed side by side without sharing installation state.

### 13.3 Required Single Natural-Image Board Contract

The owner's latest explicit decision removes the visible 3D board. The natural
jungle background itself is the only board, with every playable object placed
directly on its existing winding paths. Required behavior:

- `index.html` loads `game.js` only. It contains no WebGL canvas, artwork
  overlay, projected-label layer, perspective camera, zoom controls, camera
  badge, full-screen-board toolbar, or `world3d.js` script.
- Exactly one opaque `art/jungle_natural.jpg` image fills the SVG viewBox
  `0 0 1070 658`. Do not add a separate tilted board, drawn replacement
  landscape, duplicated path ribbons, floating route labels, or baked objects.
- Preserve the exact owner-uploaded image bytes, verified by SHA-256
  `c4809e65fa0bbb6146ea4fa8b62cd14f94392edee5f288c3bf67faadbbac3867`.
- All 35 unique but visually unnumbered stone spaces align to the background's
  five existing path-center coordinates: `548`, `421`, `311`, `208`, and `106`.
  Never show printed digits or small numeric badges anywhere on the board.
- Spaces 21 and 22 share horizontal coordinate `740` on the dry right-hand
  turn, and the walking animation follows that existing curved land path.
- The canonical lane lengths remain `7/7/7/6/8`; the only turns are `7→8`,
  `14→15`, `21→22`, and `27→28`.
- One approved transparent golden-key image appears at each of spaces 2 and 31;
  one approved lion appears at space 17; one approved wolf appears at space 27;
  one approved jungle-gate image appears at each of spaces 6 and 35; and one
  transparent golden hammer appears at space 33.
- Do not draw old animals, keys, padlocks, projected labels, or procedural
  models underneath or on top of approved artwork.
- Keys swap directly to their glowing approved image during collection. Animals
  swap directly to their approved roaring or howling artwork during encounters.
  When the explorer wins, the existing approved lion/wolf sprite visibly falls
  over into its peaceful sleep state; when the animal wins, the active full-body
  explorer visibly falls before the existing crying/fallback/recovery sequence.
- Gates swap their actual board image through
  `unlocking → opening → open → passing → half_closing → closed`; the open and
  halfway-closing PNGs retain genuinely transparent doorways. The independent
  original opening and closing recordings stay synchronized with those frames.
  If only the hammer is available at the final gate, first switch through the
  genuine-alpha `broken` state after two synchronized hammer strikes and a
  distinct lock-breaking sound, then perform the existing gate passage.
- Three slender wooden bridge overlays connect `3→11`, `12→18`, and `25→29`
  directly across the background. Landing exactly on 25 crosses to 29 and
  bypasses wolf 27. Fallback paths remain invisible while animating movement.
- The river visible in the background remains the visual barrier. An invisible
  semantic route barrier preserves the ordinary `27→28` crossing and the
  owner's approved elevated `25→29` bridge exception.
- Four original, color-specific, full-body human child explorer avatars move
  smoothly on the image's unnumbered paths, alternate visible walking legs,
  reach with visible hands, animate the correct knife/axe/hammer actions, and
  show that same player's expressive crying and recovery poses in popups.
- Finished explorers remain identified with their earned placement in the
  existing compact sidebar. Never place numeric rank markers on the approved
  unnumbered jungle board. Show the complete ranked list only in the existing
  final victory popup after one remaining explorer receives last place.
- The only approved 2.5D effects are thin animated highlights on the existing
  rivers, three falling-water/foam/mist clusters, twelve fireflies, restrained
  edge foliage, grounded soft shadows, approved-art animal breathing/key glow,
  and a foreground-only pointer shift of no more than four horizontal pixels.
- The approved background stays byte-for-byte unchanged. All atmosphere layers
  remain inside the same SVG; no second gameplay layer, camera, WebGL canvas,
  generated landscape, duplicate animal/key/gate, or printed number may appear.
- The separately bundled 22-second stereo jungle soundtrack loops softly during
  active play, starts on user interaction, pauses when hidden, honors master
  mute, and has its own persisted **Jungle ambience** control. The persisted
  **Living jungle** control independently disables decorative scenery.
- Reduced-motion preferences and the existing obstacle-animation switch stop
  nonessential atmosphere movement without changing any game result.
- `world3d.js` remains in the APK and source archive solely as preserved
  project history. The active interface, gameplay script, and CSS never load,
  initialize, call, or style it.
- The image-native board works without WebGL, GPU shaders, network downloads,
  or an external game engine. The source archive includes all local artwork and
  audio assets and rebuilds independently from the original 2D project.

The current builder creates a fresh signing certificate for each build. This
means a newly rebuilt APK usually cannot update an already installed build with
a different certificate. During development, uninstall the old APK before
installing a newly signed one. Before Play Store release, replace this behavior
with a securely stored, persistent production signing key or use Play App
Signing.

---

## 14. Important Functions in the Current Code

The exact implementation may change, but these responsibilities must remain:

| Function | Responsibility |
| --- | --- |
| `beginGame` | Reset game-specific state while retaining chosen settings and names |
| `makePlayers` | Create isolated per-player inventories and dice bags |
| `randomIndex` | Produce unbiased random shuffle indexes |
| `nextDie` | Draw from one player's independent shuffled six-face bag |
| `takeRoll` | Animate die, move through intermediate spaces, enforce checkpoints, process landing, and rotate turn |
| `encounterAnimal` | Let a knife or axe defeat the lion; let only a knife defeat the wolf |
| `setAnimalFrame` | Transition each approved lion or wolf board image through walking, encounter, sleeping, and idle artwork without creating duplicates |
| `animateEncounterDefeat` | Make the losing approved animal or the losing active explorer visibly fall while preserving weapon rules, existing sound order, crying fallback, and recovery |
| `processLanding` | Apply effects that require exact landing |
| `collectTool` | Award only the active explorer an exactly landed knife, axe, or hammer while animating its matching pose and dedicated pickup sound |
| `animateHammerBreak` | Strike final gate 35 twice, switch to the approved transparent broken-lock gate, burst lock fragments, open the gate, and award the hammer-only victory |
| `travelRoute` | Animate shortcut or fallback paths |
| `cryingFallback` | Show crying presentation and move to the route's fallback destination |
| `showVisual` | Display key, lock, animal, matching-player crying/recovery, tool pickup/defense, and hammer-lock-break cinematic scenes |
| `avatarArtwork` | Resolve one explorer's correct transparent full-body idle, walking, reaching, weapon, crying, or victory frame |
| `rankLabel` | Format finishing positions as 1st, 2nd, 3rd, and 4th |
| `renderRankings` | Display all final explorer standings in the existing themed victory popup |
| `drawBoard` | Render exactly one natural jungle image and anchor all 35 spaces, approved standalone artwork, bridges, signs, and explorer pieces directly on its paths |
| `drawLivingWater` | Add four moving river-highlight lanes and three waterfall/foam/mist groups directly to the one image-native SVG board |
| `drawJungleAtmosphere` | Add twelve fireflies and restrained edge foliage without creating a second board |
| `drawTokens` | Update independent human-shaped explorers directly on the visible jungle-image board |
| `setGateFrame` | Replace the actual visible board gate with the matching approved transparent image frame |
| `playSound` | Play the event-specific offline clip with fallback synthesis |
| `syncAmbientSound` | Start, loop, mute, pause, and resume the separate local stereo jungle soundtrack only when an active adventure is visible |
| `setAmbientSoundEnabled` | Independently toggle and persist the river/waterfall/bird soundtrack under the master sound switch |
| `setLivingJungleEnabled` | Independently toggle and persist the image-native animated-water and 2.5D scenery |
| `updateJungleParallax` | Move foreground leaves by only a few pixels while respecting reduced-motion preferences |
| `renderSettings` | Keep settings controls and toolbar state synchronized |
| `openGuide` / `closeGuide` | Load the separate offline rules page on demand inside the game popup |
| `openTutorial` / `closeTutorial` | Present or dismiss the illustrated seven-step explorer tutorial |
| `advanceTutorial` | Navigate safely through the tutorial without changing game state |
| `openNetwork` | Present the correct Wi-Fi or paired-Bluetooth host/join lobby |
| `setWifiPlayerCount` | Choose a two-, three-, or four-device Wi-Fi adventure before hosting |
| `hostNetwork` / `joinNetwork` | Start the real native TCP or RFCOMM transport |
| `pollNetwork` | Consume background connection events and framed transport messages |
| `handleNetworkMessage` | Validate handshake, names, turn ownership, and revisions |
| `requestRoll` | Keep dice authority on the host and block duplicate guest requests |

---

## 15. Required Test Coverage

At minimum, automated tests must prove:

### Board and Rules

- There are 35 unique internal spaces and zero visible printed board numbers.
- Route destinations are 3→11, 6→1, 12→18, 17→10, 25→29, 27→24, and 35→30.
- Row counts are exactly 7/7/7/6/8 with only the four approved turns.
- The river blocks all fourth-to-fifth-lane movement except the ordinary 27→28
  path turn and the explicitly approved 25→29 elevated bridge.
- Landing on 2 gives only that player the first key.
- Space 3 bypasses the first lock.
- Reaching or crossing 6 without the first key returns to 1.
- The first key permits passage through 6.
- Landing on 13 or 26 gives a knife.
- Landing on 15 gives an axe.
- Landing on 12 goes directly to 18.
- Reaching, landing on, or crossing 17 without either weapon returns to 10.
- A knife alone protects against the lion.
- An axe alone protects against the lion.
- Either a knife or an axe permits continued movement beyond 17.
- The 12→18 bridge still bypasses 17 without a knife or axe.
- Landing exactly on 25 crosses the third bridge to 29 and bypasses wolf 27
  without requiring a knife; merely passing 25 does not activate the bridge.
- Reaching, landing on, or crossing 27 without a knife returns to 24.
- A knife permits continued movement beyond 27.
- An axe alone does not protect against the wolf.
- An exact animal landing triggers one encounter, not two.
- Landing on 31 gives the final key.
- Landing exactly on 33 gives only that explorer the hammer; merely passing 33
  never collects it.
- A hammer never opens first gate 6 and never protects against lion 17 or wolf 27.
- Reaching 35 without either the final key or the hammer returns to 30.
- After returning to 30, landing on 31 can collect the key.
- Exact landing on 35 with the final key wins.
- Exact landing on 35 with a hammer but no final key visibly breaks the lock
  and wins; the hammer remains unconsumed.
- If both final key and hammer are held, normal final-key unlocking takes priority.
- In a three-player adventure, the first finisher receives rank 1, the game
  continues, the next finisher receives rank 2, and the remaining explorer
  automatically receives rank 3.
- In a four-player adventure, the first three actual finishers receive ranks
  1, 2, and 3, while the last remaining explorer automatically receives rank 4.
- Finished explorers can never roll again and are skipped in every later turn.
- The first-place explorer remains the overall champion even when a later
  finisher completes the ranked adventure.
- Solo adventures award rank 1; two-player adventures award rank 1 and
  automatic rank 2 without requiring the last explorer to reach HOME.
- Overshooting 35 leaves the player in the original position.

### Dice

- Every die face displays the correct number of pips.
- Biased raw random values are rejected.
- All six results are reachable.
- Every player's six-roll bag contains 1–6 exactly once.
- Consecutive bags do not repeat their boundary face.
- Players' dice bags are independent.
- Visual roll frames do not consume real results.

### Multiplayer and Identity

- Two-player pass-and-play is the default.
- Up to four players rotate correctly.
- Player inventories are isolated.
- All four explorers have separate normalized full-body avatar identities and
  each player's hammer remains private across connected devices.
- Turns switch without confirmation.
- Custom setup names work.
- In-game renaming works.
- Displayed names are escaped and length-limited.
- Wi-Fi host and join use the real native socket bridge.
- Bluetooth host and join use paired-device RFCOMM bridge methods.
- All guest and host names synchronize automatically across every device.
- Only the active device can roll.
- The host authorizes every connected device's die results.
- The host rejects guest requests impersonating another player's socket.
- Duplicate or stale turn revisions are rejected.
- Two independent game instances stay synchronized over a real TCP connection.
- Four independent game instances stay synchronized over three real TCP connections.
- Two- and four-device Wi-Fi adventures synchronize exact hammer pickup,
  passing space 33 without collection, final hammer strikes, and shared victory.
- Four independent Wi-Fi devices continue after first and second place,
  synchronize skipped finished turns, agree on all four final ranks, and assign
  last place automatically without any extra network message.

### Settings and Presentation

- Settings open from setup and toolbar.
- The complete approved rules are packaged as a separate offline `rules.html` page.
- The rules popup opens from setup, toolbar, sidebar field guide, and settings.
- The seven-step illustrated tutorial opens from setup or the rules popup.
- Tutorial Back, Next, full-rule link, close, Escape, and arrow navigation work.
- Rule and tutorial popups never modify active explorer or connected-game state.
- Wi-Fi and Bluetooth are enabled, open usable host/join lobbies, and show
  connection errors accurately.
- Sound controls stay synchronized.
- Four flowing river lanes and three waterfall/foam/mist groups are aligned to
  the same exact approved background without adding another board.
- Twelve fireflies, foreground edge foliage, three bridge shadows, animal/gate
  ground shadows, approved-art breathing, and key glow remain unobtrusive.
- Foreground pointer parallax stays within four horizontal pixels and honors
  the operating system's reduced-motion preference.
- The original 22-second bundled stereo jungle soundtrack loops softly only
  after play begins, pauses when hidden, resumes when visible, and honors both
  the independent ambience switch and master sound switch.
- Living-jungle and ambience settings persist independently, and disabling the
  existing obstacle-animation switch suppresses nonessential scenery motion.
- Animations can be disabled without changing outcomes.
- Speed choices change movement timing.
- Settings persist and reload.
- Required key, lock, animal, crying, and movement animations exist.
- Each explorer has eight 256×256 genuine-alpha frames with visible hands,
  alternating walking legs, matching knife/axe/hammer actions, crying, and
  recovery/victory.
- The lion and wolf each transition through their existing approved walking,
  roaring/howling, peaceful sleeping, and idle artwork.
- A protected human victory visibly topples the lion or wolf; an unprotected
  animal victory visibly topples that same explorer before crying and recovery.
- Toppling effects honor disabled animations and reduced-motion preferences.
- Knife, axe, and hammer pickups use the correct explorer pose and sound;
  defense uses the matching knife/axe sound; final hammer victory plays two
  hammer-strike sounds and one distinct lock-breaking sound.
- Every sound ID has a nonempty bundled clip.
- Required sound sequences occur for animal success and failure.
- Both dedicated original gate sounds play once in the correct opening/closing order.
- Every independent PNG has genuine alpha; open and halfway-closing gates have
  a transparent central passage.
- Exactly one natural-background image forms the visible board.
- All 35 hidden internal positions and every approved animal, key, and gate
  align directly to the exact uploaded background's five existing paths.
- No visible board digit or numeric badge is rendered, and spaces 21 and 22
  remain completely on the existing dry path.
- No second 3D board, WebGL initialization, camera control, floating label,
  duplicate route, or old procedural animal/key/gate drawing can appear.
- Visible gate artwork changes directly on the natural board for every approved
  opening, passage, halfway-closing, and closed frame.

The current baseline is **112 passing gameplay, ranking, encounter loser-fall,
explorer, hammer, living-jungle, audio, and onboarding tests**,
**36 archived-renderer preservation checks**,
an actual two-game TCP integration test covering ten synchronized turns, and
an actual four-game/three-socket TCP integration test covering seventeen
synchronized turns. A future change should
not reduce coverage without a documented reason. Real Bluetooth hardware and
physical Android installation should still be checked on actual phones before
public release.

---

## 16. Definition of Done for Any Future Modification

A game change is complete only when:

1. The requested behavior is implemented in the source.
2. Existing Required Rules still work unless the request explicitly changes
   them.
3. New or updated automated tests cover the change.
4. All tests pass.
5. The app version is incremented when producing a new APK.
6. `README.md` and this master specification are updated if behavior or status
   changed.
7. The APK is rebuilt.
8. The APK manifest, resources, DEX, ZIP, and both signature schemes validate.
9. The packaged source archive can rebuild and validate the APK independently.
10. A feature is not labeled available until it genuinely works in the APK.

---

## 17. Decision History That Must Not Be Lost

- The final-lock fallback was changed from space 31 to **space 30**.
- Player names became customizable.
- Pass-and-play became the default multiplayer experience.
- Repeated per-turn confirmation was removed.
- Dice behavior was changed to independent per-player shuffled six-face bags.
- Distinct offline sounds were added for lion, wolf, fighting, crying, relief,
  shortcuts, positive events, setbacks, movement, and victory.
- Keys, locks, animals, movement, and crying fallbacks gained animations.
- A settings page was added with persistent sound, animation, and speed options.
- Real same-network Wi-Fi and paired Classic Bluetooth multiplayer were added
  with a native Android connection bridge and authoritative two-device turns.
- Lion and wolf checks were changed from exact-landing-only to mandatory
  pass-through checkpoints.
- The owner explicitly restored the rule that either a **knife or axe** defeats
  the lion; the wolf still requires a **knife**.
- The original 2D edition retained its historical 15→20 shortcut; the approved
  independent 3D jungle redesign replaced it with a 12→18 bridge bypassing lion 17.
- The owner requested a distinct new edition with the `3D` postfix while the
  original 2D game remains untouched and independently installable.
- The first independent edition historically used genuine offline WebGL
  geometry, perspective camera controls, and an illustrated fallback.
- Version 1.1 enlarged the default board, added bounded button, pinch, and wheel
  camera zoom, added a usable
  full-screen board mode, enlarged both animals, and replaced the lion with a
  friendly seated animated model.
- Version 1.2 integrated the approved 7/7/7/6/8 jungle redesign, continuous
  22–35 river barrier, 3→11 and 12→18 raised bridges, knife 13, axe 15, lion 17,
  fifteen independent approved transparent artwork states, animated fireflies
  and water highlights, a genuinely transparent halfway-closing gate, and both
  original 48-kHz stereo opening/closing recordings.
- Version 1.3 removes every overlapping old lion, wolf, key, padlock, and
  shackle from both the live 3D board and illustrated compatibility board;
  removes duplicate keys from the animated event scenes; and retains safe
  per-image compatibility models if an approved artwork image fails to load.
  It also adds the owner's requested crisp neutral natural jungle background,
  derived from the uploaded winding-path reference without baked gameplay
  objects, labels, numbers, or interface controls.
- Version 1.4 follows the owner's newer explicit correction: **remove the
  separate 3D board entirely and place every object directly on the background
  image**. Its single natural jungle board has 35 image-aligned numbered stones,
  directly positioned approved animals, keys, gates, and human player pieces,
  plus the two original bridges. The WebGL canvas, generated terrain,
  perspective route, duplicate labels, camera buttons, zoom controls,
  full-screen-board overlay, and visible 3D badges are removed. The historical
  renderer source remains archived but is never loaded. This latest decision
  supersedes all earlier requests for a visible WebGL/perspective board.
- Version 1.5 uses the owner's newly uploaded exact jungle image without editing
  or regenerating it. Every printed board number and special-space numeric badge
  is removed while all 35 positions remain internally addressable. Spaces 21 and
  22 move onto the existing dry right-hand bend. A third elevated bridge now
  connects 25→29 and safely bypasses wolf 27; this intentional bridge supersedes
  the earlier requirement that 27→28 be the only crossing of the upper river.
- Version 1.6 extends local Wi-Fi multiplayer from exactly two devices to a
  selectable two, three, or four separate devices. One authoritative host
  accepts up to three genuine guest sockets, assigns unique explorer ownership,
  synchronizes names and turns to every device, rejects impersonated turns, and
  preserves the existing two-device Bluetooth mode, exact uploaded background,
  three approved bridges, hidden board numbers, and all established game rules.
- Version 1.7 adds a separate complete offline game-rules page loaded on demand
  inside a themed popup, a seven-step illustrated guided tutorial, and clear
  navigation from the setup screen, toolbar, sidebar field guide, and settings.
  The guide accurately explains every approved bridge, weapon, animal, key,
  gate, multiplayer limit, and winning rule while preserving the existing board,
  approved artwork, four-device Wi-Fi, Bluetooth, and live game state.
- Version 1.8 adds a restrained image-native 2.5D illusion without touching the
  exact approved background: four flowing river-reflection lanes, three live
  waterfalls with foam and mist, twelve fireflies, edge foliage, grounded
  bridge/animal/gate/player shadows, gently breathing approved animal artwork,
  glowing approved keys, and reduced-motion-aware foreground parallax. It also
  bundles an original 22-second looping stereo river/waterfall/leaf/bird
  soundtrack that starts only after play begins, pauses when hidden, and
  respects master mute. Separate persisted **Jungle ambience** and **Living
  jungle** controls preserve accessibility, all approved rules, hidden board
  numbers, three bridges, four-device Wi-Fi, Bluetooth, rules, and tutorial.
- Version 1.9 adds four original full-body pre-rendered 3D-style Ruby, River,
  Forest, and Violet child explorer avatars, each with eight normalized
  transparent poses for idle, visibly moving legs and arms, pickup, knife
  defense, two-handed axe/hammer action, matching-player crying, and recovery.
  Existing approved lion and wolf artwork now visibly transitions through walk,
  roar/howl, peaceful sleep, and idle. Knives, axes, and hammers have separate
  pickup/action animations and seven original corresponding offline sounds.
  The owner approved an easier alternate final win: land exactly on space 33
  to collect a personal hammer; when reaching final gate 35 without the final
  key, strike twice, display the transparent broken-lock gate and fragments,
  open the gate, and win. The final key retains priority; the hammer never
  opens gate 6 or protects against animals. Without either item, the final
  fallback remains space 30. All existing flat-board artwork, hidden numbers,
  three bridges, four-device Wi-Fi, two-device Bluetooth, rules popup,
  seven-step tutorial, living water, and soundtrack are preserved.
- Version 2.0 implements the owner's ranked-race decision: adventures with
  three or four explorers no longer stop when the first explorer reaches HOME.
  Each actual finisher earns the next place, finished players are skipped on
  every subsequent hotseat or Wi-Fi turn, and the final remaining explorer
  automatically receives last place after one of the last two wins. The
  existing sidebar shows live ranks, and the existing victory popup displays
  the complete final standings without covering the board during normal play.
  Two-player games still finish after the first arrival and now show first and
  second place. The first finisher remains the overall champion even when the
  adventure ends later. In every lion/wolf encounter, the losing side now
  visibly falls: a protected explorer topples the animal, while an unprotected
  explorer falls before crying, retreating, and recovering. Approved artwork,
  weapon rules, hammer behavior, audio order, hidden board numbers, living
  jungle, Bluetooth, and all previous multiplayer protections remain intact.

---

## 18. Compact Rules Configuration

This block can be used as a starting point for another implementation:

```json
{
  "title": "Keys & Claws: Quest for Home",
  "androidPackage": "com.keysandclaws.questforhome3d",
  "renderer": "single owner-approved natural jungle image with directly positioned SVG gameplay objects",
  "depthIllusion": "image-native 2.5D only; no separate board, WebGL, or perspective camera",
  "livingJungleEffects": ["flowing river", "waterfalls", "foam", "mist", "fireflies", "ground shadows", "foreground foliage", "subtle parallax"],
  "ambientSound": "sounds/jungle_ambience.mp3",
  "minimumPlayers": 1,
  "maximumPlayers": 4,
  "startPosition": 0,
  "lastNumberedSpace": 35,
  "boardNumbersVisible": false,
  "exactFinishRequired": true,
  "rankedMultiplayer": true,
  "continueAfterFirstWinner": true,
  "skipFinishedExplorers": true,
  "automaticallyRankLastExplorer": true,
  "animalEncounterLoserFalls": true,
  "landingEffects": {
    "2": { "type": "collect", "item": "firstKey" },
    "3": { "type": "shortcut", "to": 11 },
    "10": { "type": "medical" },
    "12": { "type": "shortcut", "to": 18 },
    "13": { "type": "collect", "item": "knife" },
    "15": { "type": "collect", "item": "axe" },
    "24": { "type": "hospital" },
    "25": { "type": "shortcut", "to": 29 },
    "26": { "type": "collect", "item": "knife" },
    "31": { "type": "collect", "item": "finalKey" },
    "33": { "type": "collect", "item": "hammer", "requiresExactLanding": true },
    "35": { "type": "finishLock", "requiresAny": ["finalKey", "hammer"], "preferred": "finalKey", "fallback": 30 }
  },
  "passThroughCheckpoints": {
    "6": { "type": "lock", "requires": "firstKey", "fallback": 1 },
    "17": { "type": "lion", "requiresAny": ["knife", "axe"], "fallback": 10 },
    "27": { "type": "wolf", "requires": "knife", "fallback": 24 }
  },
  "rowSpaceCounts": [7, 7, 7, 6, 8],
  "legalRowTurns": [[7, 8], [14, 15], [21, 22], [27, 28]],
  "riverBarrier": { "betweenRows": [4, 5], "trailCrossing": [27, 28], "bridgeCrossing": [25, 29] },
  "hammerFinalGateOnly": true,
  "gateStates": ["unlocking", "broken", "opening", "open", "passing", "half_closing", "closed"],
  "gateSounds": ["gate_open", "gate_close"],
  "toolSounds": ["knife_pickup", "axe_pickup", "hammer_pickup", "knife_use", "axe_use", "hammer_hit", "lock_break"],
  "explorerAvatarIdentities": ["ruby", "river", "forest", "violet"],
  "availablePlayModes": ["hotseat", "wifi", "bluetooth"],
  "crossDeviceMaximumPlayers": 4,
  "wifiMaximumPlayers": 4,
  "bluetoothMaximumPlayers": 2,
  "wifiPort": 49735,
  "bluetoothServiceUuid": "f7cbf6f5-24fa-4f6e-b6e8-31fbd96a4440",
  "plannedPlayModes": []
}
```

---

## 19. Suggested Prompt When Giving This File to Another AI

> Read the attached Keys & Claws 3D master specification before changing any code.
> Treat Required Rules, the board table, checkpoint semantics, and Definition of
> Done as binding. First summarize the requested change and identify which rules,
> files, and tests it affects. Do not claim Wi-Fi or Bluetooth works unless you
> implement and test real multi-device networking. After editing, run the full
> gameplay, archived-source, artwork, and multiplayer test suites; rebuild and
> validate the separate APK; preserve the original 2D project unchanged; and update
> this specification if the approved behavior changed.
