#!/usr/bin/env python3
"""Regenerate the bundled, seamless stereo river/waterfall/jungle ambience.

The generated MP3 is committed to the project and bundled in the APK, so
installing or rebuilding the game never requires NumPy, SciPy, or FFmpeg.
Those optional tools are needed only when recreating this original soundtrack.
"""

from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from scipy.io import wavfile


PROJECT = Path(__file__).resolve().parent
OUTPUT = PROJECT / 'sounds' / 'jungle_ambience.mp3'
RATE = 22050
DURATION = 22
SAMPLES = RATE * DURATION
RNG = np.random.default_rng(25082026)


def circular_noise(low: float, high: float, softness: float) -> np.ndarray:
    """Shape periodic noise in frequency space so the loop joins smoothly."""
    frequency = np.fft.rfftfreq(SAMPLES, 1 / RATE)
    phase = RNG.uniform(0, 2 * np.pi, frequency.size)
    slope = 1 / np.maximum(frequency, 60) ** softness
    lower = 1 - np.exp(-((frequency / max(low, 1)) ** 3))
    upper = np.exp(-((frequency / high) ** 3))
    spectrum = np.exp(1j * phase) * slope * lower * upper
    spectrum[0] = 0
    samples = np.fft.irfft(spectrum, SAMPLES)
    return samples / max(float(np.std(samples)), .0001)


def bird_call(start: float, center: float, channel: np.ndarray,
              strength: float, answer: bool = False) -> None:
    """Add a short, soft, two-note distant jungle bird call."""
    for note, offset in enumerate((0, .19, .35) if answer else (0, .16)):
        duration = .115 if note else .145
        count = int(duration * RATE)
        first = int((start + offset) * RATE)
        if first + count >= SAMPLES:
            continue
        timeline = np.arange(count) / RATE
        frequency = center + (410 if note % 2 == 0 else -290) * timeline / duration
        frequency += 45 * np.sin(2 * np.pi * 11 * timeline)
        phase = 2 * np.pi * np.cumsum(frequency) / RATE
        envelope = np.sin(np.pi * timeline / duration) ** 2
        call = (np.sin(phase) + .15 * np.sin(phase * 2)) * envelope
        channel[first:first + count] += call * strength


def create_ambience() -> np.ndarray:
    timeline = np.arange(SAMPLES) / RATE
    river = circular_noise(145, 4600, .47)
    waterfall = circular_noise(80, 1800, .79)
    leaves = circular_noise(300, 3500, .64)

    river_motion = .77 + .13 * np.sin(2 * np.pi * 3 * timeline / DURATION)
    river_motion += .07 * np.sin(2 * np.pi * 7 * timeline / DURATION)
    waterfall_motion = .72 + .13 * np.sin(2 * np.pi * 2 * timeline / DURATION + .8)
    leaves_motion = (.5 + .5 * np.sin(2 * np.pi * timeline / DURATION - .6)) ** 2

    left = river * river_motion * .105 + waterfall * waterfall_motion * .091
    left += leaves * leaves_motion * .028
    right = np.roll(river, int(.043 * RATE)) * river_motion * .101
    right += np.roll(waterfall, int(.071 * RATE)) * waterfall_motion * .096
    right += np.roll(leaves, int(.13 * RATE)) * leaves_motion * .033

    for start, pitch, left_strength, right_strength, answer in [
        (2.65, 2310, .072, .041, False),
        (7.90, 1890, .036, .066, True),
        (13.35, 2620, .065, .033, False),
        (18.40, 2110, .033, .060, True),
    ]:
        bird_call(start, pitch, left, left_strength, answer)
        bird_call(start + .028, pitch * 1.008, right, right_strength, answer)

    stereo = np.column_stack((left, right))
    peak = max(float(np.max(np.abs(stereo))), .001)
    if peak > .77:
        stereo *= .77 / peak
    return np.asarray(np.clip(stereo, -.95, .95) * 32767, dtype=np.int16)


def main() -> None:
    OUTPUT.parent.mkdir(exist_ok=True)
    ambience = create_ambience()
    with tempfile.TemporaryDirectory(prefix='keys-claws-jungle-') as folder:
        temporary = Path(folder) / 'jungle_ambience.wav'
        wavfile.write(temporary, RATE, ambience)
        subprocess.run([
            'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-i', str(temporary), '-codec:a', 'libmp3lame', '-b:a', '80k',
            '-ar', str(RATE), '-ac', '2', '-write_xing', '0', str(OUTPUT),
        ], check=True)
    print(json.dumps({
        'file': str(OUTPUT), 'seconds': DURATION, 'sample_rate': RATE,
        'channels': 2, 'bytes': OUTPUT.stat().st_size,
        'layers': ['flowing river', 'waterfall', 'rustling leaves', 'distant jungle birds'],
        'offline': True, 'looping': True, 'deterministic_seed': 25082026,
    }, indent=2))


if __name__ == '__main__':
    main()
