#!/usr/bin/env node
'use strict';

// Exercise two independent game instances through an actual TCP connection.
// The JavaScript bridge uses the same two-byte UTF frame shape as Android's
// DataInputStream/DataOutputStream transport.

const assert = require('assert');
const fs = require('fs');
const net = require('net');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, 'game.js'), 'utf8');
const channel = { server: null, port: 0, bridges: [] };

class ClassList {
  constructor() { this.values = new Set(); }
  add(value) { this.values.add(value); }
  remove(value) { this.values.delete(value); }
  contains(value) { return this.values.has(value); }
  toggle(value, force) {
    const present = force === undefined ? !this.values.has(value) : force;
    if (present) this.values.add(value); else this.values.delete(value);
    return present;
  }
}

function bridge() {
  const events = [];
  let socket = null;
  let buffer = Buffer.alloc(0);

  function attach(connection) {
    socket = connection;
    connection.on('data', function (piece) {
      buffer = Buffer.concat([buffer, piece]);
      while (buffer.length >= 2 && buffer.length >= buffer.readUInt16BE(0) + 2) {
        const size = buffer.readUInt16BE(0);
        events.push('data|' + buffer.subarray(2, size + 2).toString('utf8'));
        buffer = buffer.subarray(size + 2);
      }
    });
    connection.on('error', function (error) { events.push('error|' + error.message); });
    connection.on('close', function () { events.push('error|connection closed'); });
    events.push('status|connected');
  }

  const result = {
    poll: function () { return events.shift() || ''; },
    send: function (message) {
      if (!socket || socket.destroyed) return false;
      const text = Buffer.from(message, 'utf8');
      const packet = Buffer.alloc(text.length + 2);
      packet.writeUInt16BE(text.length, 0);
      text.copy(packet, 2);
      socket.write(packet);
      return true;
    },
    localAddress: function () { return '127.0.0.1'; },
    hostWifi: function () {
      channel.server = net.createServer(attach);
      channel.server.listen(0, '127.0.0.1', function () {
        channel.port = channel.server.address().port;
        events.push('status|waiting');
      });
      return 'started';
    },
    joinWifi: function (address) {
      const connection = net.createConnection({ host: address, port: channel.port });
      connection.once('connect', function () { attach(connection); });
      connection.on('error', function (error) { events.push('error|' + error.message); });
      return 'started';
    },
    disconnect: function () {
      if (socket) socket.destroy();
      if (channel.server) channel.server.close();
    }
  };
  channel.bridges.push(result);
  return result;
}

function createGame(nativeBridge) {
  const ids = Object.create(null);
  const listeners = Object.create(null);

  class Element {
    constructor(tag, id) {
      this.tagName = tag;
      this.id = id || '';
      this.attrs = Object.create(null);
      this.children = [];
      this.handlers = Object.create(null);
      this.classList = new ClassList();
      this.style = {};
      this.textContent = '';
      this.innerHTML = '';
      this.disabled = false;
      this.value = '';
      if (id) ids[id] = this;
    }
    setAttribute(key, value) {
      this.attrs[key] = String(value);
      if (key === 'id') ids[String(value)] = this;
    }
    getAttribute(key) { return this.attrs[key] || null; }
    addEventListener(key, callback) { this.handlers[key] = callback; }
    appendChild(element) { this.children.push(element); return element; }
    focus() {}
    select() {}
    getTotalLength() { return 100; }
    getPointAtLength(distance) {
      const points = (this.attrs.d || '').match(/-?\d+(?:\.\d+)?/g).map(Number);
      const ratio = distance / 100;
      return {
        x: points[0] + (points[points.length - 2] - points[0]) * ratio,
        y: points[1] + (points[points.length - 1] - points[1]) * ratio
      };
    }
  }

  [
    'board', 'active-player', 'position-line', 'inventory', 'roll-btn', 'die-face',
    'turn-hint', 'players-list', 'top-message', 'event-banner', 'setup-overlay',
    'victory-overlay', 'winner-line', 'victory-stats', 'victory-rankings',
    'player-preview', 'start-btn',
    'restart-btn', 'sound-btn', 'play-again-btn', 'new-game-btn', 'rename-overlay',
    'rename-input', 'rename-label', 'rename-save-btn', 'rename-cancel-btn',
    'scene-overlay', 'scene-title', 'scene-stage', 'scene-caption', 'settings-btn',
    'setup-settings-btn', 'settings-overlay', 'settings-close-btn',
    'settings-sound-btn', 'settings-animation-btn', 'mode-hotseat-btn',
    'mode-wifi-btn', 'mode-bluetooth-btn', 'speed-slow-btn', 'speed-normal-btn',
    'speed-fast-btn', 'network-overlay', 'network-title', 'network-symbol',
    'network-instructions', 'network-name', 'network-address',
    'network-address-label', 'network-devices', 'network-refresh-btn',
    'network-status', 'network-host-btn', 'network-join-btn', 'network-back-btn',
    'wifi-player-picker', 'wifi-count-2', 'wifi-count-3', 'wifi-count-4',
    'help-btn', 'field-guide-btn', 'setup-guide-btn', 'setup-tutorial-btn',
    'settings-guide-btn', 'guide-overlay', 'rules-frame', 'guide-dismiss-btn',
    'guide-close-btn', 'guide-tutorial-btn', 'tutorial-overlay', 'tutorial-progress',
    'tutorial-art', 'tutorial-badge', 'tutorial-title', 'tutorial-description',
    'tutorial-tip', 'tutorial-back-btn', 'tutorial-next-btn', 'tutorial-close-btn',
    'tutorial-rules-btn'
  ].forEach(function (id) { new Element('div', id); });

  const choices = [1, 2, 3, 4].map(function (count) {
    const element = new Element('button');
    element.setAttribute('data-count', count);
    return element;
  });

  const browser = {
    readyState: 'loading',
    createElementNS: function (_, tag) { return new Element(tag); },
    getElementById: function (id) { return ids[id] || null; },
    addEventListener: function (event, callback) { listeners[event] = callback; },
    querySelectorAll: function (selector) {
      return selector === '.count-choice' ? choices : [];
    }
  };

  const activeIntervals = new Set();
  const sandbox = {
    document: browser,
    window: { KeysClawsNative: nativeBridge },
    setTimeout: function (callback) { queueMicrotask(callback); return 1; },
    setInterval: function (callback) {
      const timer = setInterval(callback, 2);
      activeIntervals.add(timer);
      return timer;
    },
    clearInterval: function (timer) {
      clearInterval(timer);
      activeIntervals.delete(timer);
    },
    Uint32Array: Uint32Array
  };
  vm.runInNewContext(source, sandbox, { filename: 'game.js' });
  listeners.DOMContentLoaded();
  const game = sandbox.window.KeysAndClaws;
  game.state.sound = false;
  return { game: game, ids: ids, timers: activeIntervals };
}

async function waitUntil(description, predicate) {
  const end = Date.now() + 3500;
  while (Date.now() < end) {
    if (predicate()) return;
    await new Promise(function (resolve) { setTimeout(resolve, 5); });
  }
  throw new Error('Timed out waiting for ' + description);
}

(async function main() {
  const host = createGame(bridge());
  const guest = createGame(bridge());

  try {
    host.game.openNetwork('wifi');
    host.ids['network-name'].value = 'Host Explorer';
    assert.strictEqual(host.game.hostNetwork(), true);
    await waitUntil('TCP listener', function () { return channel.port > 0; });

    guest.game.openNetwork('wifi');
    guest.ids['network-name'].value = 'Guest Explorer';
    guest.ids['network-address'].value = '127.0.0.1';
    assert.strictEqual(guest.game.joinNetwork(), true);

    await waitUntil('two synchronized game instances', function () {
      return host.game.state.started && guest.game.state.started &&
        host.game.state.network.connected && guest.game.state.network.connected;
    });
    assert.deepStrictEqual(Array.from(host.game.state.players, function (player) {
      return player.name;
    }), ['Host Explorer', 'Guest Explorer']);
    assert.deepStrictEqual(Array.from(guest.game.state.players, function (player) {
      return player.name;
    }), ['Host Explorer', 'Guest Explorer']);
    assert.strictEqual(guest.ids['roll-btn'].disabled, true);

    host.game.state.players[0].diceBag = [2];
    assert.strictEqual(host.game.requestRoll(), true);
    await waitUntil('the first shared dice roll', function () {
      return host.game.state.turns === 1 && guest.game.state.turns === 1 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[0].position, 2);
    assert.strictEqual(guest.game.state.players[0].position, 2);
    assert.strictEqual(host.game.state.players[0].firstKey, true);
    assert.strictEqual(guest.game.state.players[0].firstKey, true);

    host.game.state.players[1].diceBag = [3];
    assert.strictEqual(guest.game.requestRoll(), true);
    await waitUntil('the guest-controlled shared dice roll', function () {
      return host.game.state.turns === 2 && guest.game.state.turns === 2 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[1].position, 11);
    assert.strictEqual(guest.game.state.players[1].position, 11);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[0].position = 14;
      game.state.players[0].knife = false;
      game.state.players[0].axe = true;
    });
    host.game.state.players[0].diceBag = [5];
    assert.strictEqual(host.game.requestRoll(), true);
    await waitUntil('the synchronized axe-versus-lion encounter', function () {
      return host.game.state.turns === 3 && guest.game.state.turns === 3 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[0].position, 19);
    assert.strictEqual(guest.game.state.players[0].position, 19);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[1].position = 11;
      game.state.players[1].knife = false;
      game.state.players[1].axe = false;
    });
    host.game.state.players[1].diceBag = [1];
    assert.strictEqual(guest.game.requestRoll(), true);
    await waitUntil('the synchronized bridge bypassing lion 17', function () {
      return host.game.state.turns === 4 && guest.game.state.turns === 4 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[1].position, 18);
    assert.strictEqual(guest.game.state.players[1].position, 18);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[0].position = 34;
      game.state.players[0].finalKey = false;
    });
    host.game.state.players[0].diceBag = [1];
    assert.strictEqual(host.game.requestRoll(), true);
    await waitUntil('the synchronized final-lock fallback', function () {
      return host.game.state.turns === 5 && guest.game.state.turns === 5 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[0].position, 30);
    assert.strictEqual(guest.game.state.players[0].position, 30);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[1].position = 26;
      game.state.players[1].knife = false;
      game.state.players[1].axe = true;
    });
    host.game.state.players[1].diceBag = [1];
    assert.strictEqual(guest.game.requestRoll(), true);
    await waitUntil('the synchronized wolf knife-only fallback', function () {
      return host.game.state.turns === 6 && guest.game.state.turns === 6 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[1].position, 24);
    assert.strictEqual(guest.game.state.players[1].position, 24);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[0].position = 24;
      game.state.players[0].knife = false;
      game.state.players[0].axe = false;
    });
    host.game.state.players[0].diceBag = [1];
    assert.strictEqual(host.game.requestRoll(), true);
    await waitUntil('the synchronized third bridge bypassing wolf 27', function () {
      return host.game.state.turns === 7 && guest.game.state.turns === 7 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[0].position, 29);
    assert.strictEqual(guest.game.state.players[0].position, 29);
    assert.strictEqual(host.game.state.players[0].knife, false);
    assert.strictEqual(guest.game.state.players[0].knife, false);
    [host.game, guest.game].forEach(function (game) {
      game.state.players[1].position = 32;
      game.state.players[1].hammer = false;
    });
    host.game.state.players[1].diceBag = [1];
    assert.strictEqual(guest.game.requestRoll(), true);
    await waitUntil('the guest collects the synchronized space-33 hammer', function () {
      return host.game.state.turns === 8 && guest.game.state.turns === 8 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[1].position, 33);
    assert.strictEqual(guest.game.state.players[1].position, 33);
    assert.strictEqual(host.game.state.players[1].hammer, true);
    assert.strictEqual(guest.game.state.players[1].hammer, true);
    assert.strictEqual(host.game.state.players[0].hammer, false);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[0].position = 31;
      game.state.players[0].hammer = false;
    });
    host.game.state.players[0].diceBag = [3];
    assert.strictEqual(host.game.requestRoll(), true);
    await waitUntil('passing space 33 leaves the host without a hammer', function () {
      return host.game.state.turns === 9 && guest.game.state.turns === 9 &&
        !host.game.state.busy && !guest.game.state.busy;
    });
    assert.strictEqual(host.game.state.players[0].position, 34);
    assert.strictEqual(guest.game.state.players[0].hammer, false);

    [host.game, guest.game].forEach(function (game) {
      game.state.players[1].position = 34;
      game.state.players[1].finalKey = false;
    });
    host.game.state.players[1].diceBag = [1];
    assert.strictEqual(guest.game.requestRoll(), true);
    await waitUntil('the synchronized hammer breaks the final lock and wins', function () {
      return host.game.state.turns === 10 && guest.game.state.turns === 10 &&
        host.game.state.won && guest.game.state.won;
    });
    assert.strictEqual(host.game.state.players[1].position, 35);
    assert.strictEqual(guest.game.state.players[1].position, 35);
    assert.strictEqual(host.game.state.players[1].finishMethod, 'hammer');
    assert.strictEqual(guest.game.state.players[1].finishMethod, 'hammer');
    assert.deepStrictEqual(Array.from(host.game.state.rankings), [1, 0]);
    assert.deepStrictEqual(Array.from(guest.game.state.rankings), [1, 0]);
    assert.strictEqual(host.game.state.players[1].rank, 1);
    assert.strictEqual(host.game.state.players[0].rank, 2);
    assert.strictEqual(host.game.state.players[0].lastPlace, true);
    assert.ok(host.ids['victory-rankings'].innerHTML.includes('2nd'));
    assert.ok(guest.ids['victory-rankings'].innerHTML.includes('2nd'));
    assert.strictEqual(host.game.state.network.revision, 10);
    assert.strictEqual(guest.game.state.network.revision, 10);

    process.stdout.write(JSON.stringify({
      passed: true,
      transport: 'actual loopback TCP socket',
      independently_running_game_instances: 2,
      synchronized_turns: 10,
      synchronized_rules: ['first key', '3-to-11 bridge', 'axe defeats lion at 17',
        '12-to-18 bridge bypasses lion', 'final lock returns to 30',
        'axe does not defeat wolf', '25-to-29 bridge bypasses wolf',
        'space-33 hammer stays isolated to its explorer',
        'passing space 33 never collects the hammer',
        'hammer breaks the final lock at 35 and synchronizes victory'],
      host_controls_dice: true,
      player_names_synchronized: true,
      first_and_second_place_synchronized: true,
      automatic_last_place: true
    }, null, 2) + '\n');
  } finally {
    host.game.disconnectNetwork();
    guest.game.disconnectNetwork();
    host.timers.forEach(clearInterval);
    guest.timers.forEach(clearInterval);
    if (channel.server && channel.server.listening) channel.server.close();
  }
}()).catch(function (error) {
  console.error(error.stack || error);
  process.exitCode = 1;
});
