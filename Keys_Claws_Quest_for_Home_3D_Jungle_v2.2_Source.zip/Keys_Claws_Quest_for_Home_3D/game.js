(function () {
  'use strict';

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var COLORS = ['#bf5141', '#347b8a', '#4c8653', '#795980'];
  var NAMES = ['Ruby Explorer', 'River Explorer', 'Forest Explorer', 'Violet Explorer'];
  var AVATARS = ['ruby', 'river', 'forest', 'violet'];
  var AVATAR_POSES = { idle: '01', walkA: '02', walkB: '03', pickup: '04',
    knife: '05', tool: '06', cry: '07', victory: '08', recovery: '08' };
  var SETTINGS_KEY = 'keys-claws-adventure-settings-v1';
  var ONLINE_SERVER = 'https://keys-claws-online.rohitgames.workers.dev';
  var SPEED_FACTORS = { slow: 1, normal: .69, fast: .42 };
  var PIPS = [[4], [0, 8], [0, 4, 8], [0, 2, 6, 8], [0, 2, 4, 6, 8], [0, 2, 3, 5, 6, 8]];
  var TUTORIAL_STEPS = [
    {
      badge: 'YOUR JUNGLE QUEST', title: 'Find Your Way Home', symbol: '⌂',
      description: 'Begin at START and follow the winding jungle trail. Collect the right gear and race every explorer HOME to earn your finishing rank.',
      tip: 'There are 35 hidden spaces. The stones have no printed numbers.'
    },
    {
      badge: 'ROLL AND TAKE TURNS', title: 'Move Your Explorer', symbol: '⚄',
      description: 'Roll the fair six-sided die and move exactly 1–6 spaces. Each explorer takes a turn and keeps their own position and equipment.',
      tip: 'The next turn begins automatically. No confirmation popup is needed.'
    },
    {
      badge: 'KEYS AND LOCKED GATES', title: 'Collect Golden Keys',
      images: ['art/key_normal.png', 'art/gate_closed.png'],
      description: 'Land on space 2 to collect the first key. Without it, the gate at space 6 sends you back to 1. Collect the final key at space 31.',
      tip: 'The final key opens HOME. A hammer collected at 33 can break only the final lock.'
    },
    {
      badge: 'THREE HIDDEN SHORTCUTS', title: 'Cross the Bridges', symbol: '♧',
      description: 'Land directly on space 3 to jump to 11, on space 12 to jump to 18, or on space 25 to cross the river and jump to 29.',
      tip: 'Bridges work only when your roll finishes on their entrance.'
    },
    {
      badge: 'LION, WOLF, AND WEAPONS', title: 'Outsmart the Animals',
      images: ['art/lion_idle.png', 'art/wolf_idle.png'],
      description: 'Collect knives at 13 or 26 and an axe at 15. A knife or axe defeats the lion at 17, but only a knife defeats the wolf at 27.',
      tip: 'Collect the hammer at 33 for the final lock. It never protects against animals.'
    },
    {
      badge: 'PLAY WITH YOUR FRIENDS', title: 'Choose Your Adventure', symbol: '♟',
      description: 'Pass & Play supports 1–4 explorers on one device. Wi-Fi connects 2–4 separate devices. Paired Bluetooth connects two devices.',
      tip: 'Finished explorers stop rolling while everyone else keeps racing for the next rank.'
    },
    {
      badge: 'THE FINAL JUNGLE GATE', title: 'Unlock HOME and Win',
      images: ['art/key_glow.png', 'art/hammer.png'],
      description: 'Roll the exact number to land on space 35. Use the final key from 31, or smash the padlock with the hammer collected at 33, to reach HOME!',
      tip: 'An overshoot does not move you. Without the final key or hammer, return to space 30. Race until only one explorer remains.'
    }
  ];
  var X = [154, 274, 394, 514, 634, 754, 874];
  // These lane centers are sampled from the owner's clean natural jungle image.
  var Y = [548, 421, 311, 208, 106];
  // The fourth lane intentionally has six spaces and the home lane has eight.
  // Keep both middle-row endpoints on the uploaded image's dry right-hand turn.
  var ROWS = [
    X.slice(), X.slice().reverse(), [154, 252, 349, 447, 545, 643, 740],
    [740, 623, 506, 388, 271, 154],
    [154, 257, 360, 463, 566, 669, 772, 875]
  ];
  var POS = {};
  var SPECIAL = {
    2: { label: 'KEY', icon: 'key', color: '#ce9429', fill: '#f4d376' },
    3: { label: 'BRIDGE', icon: 'shortcut', color: '#347b4e', fill: '#dbe8bb' },
    6: { label: 'LOCK', icon: 'lock', color: '#a95130', fill: '#e9b082' },
    10: { label: 'MEDICAL', icon: 'medical', color: '#347783', fill: '#c8ddd1' },
    12: { label: 'BRIDGE', icon: 'shortcut', color: '#347b4e', fill: '#dbe8bb' },
    13: { label: 'KNIFE', icon: 'knife', color: '#755777', fill: '#dac7d4' },
    15: { label: 'AXE', icon: 'axe', color: '#755777', fill: '#dac7d4' },
    17: { label: 'LION', icon: 'lion', color: '#a95130', fill: '#e9b082' },
    24: { label: 'HOSPITAL', icon: 'hospital', color: '#347783', fill: '#c8ddd1' },
    25: { label: 'BRIDGE', icon: 'shortcut', color: '#347b4e', fill: '#dbe8bb' },
    26: { label: 'KNIFE', icon: 'knife', color: '#755777', fill: '#dac7d4' },
    27: { label: 'WOLF', icon: 'wolf', color: '#b64a3b', fill: '#eeb9a8' },
    31: { label: 'FINAL KEY', icon: 'key', color: '#ce9429', fill: '#f4d376' },
    33: { label: 'HAMMER', icon: 'hammer', color: '#94722d', fill: '#e5d09c' },
    35: { label: 'FINAL LOCK', icon: 'lock', color: '#a95130', fill: '#e9b082' }
  };
  var ROUTES = {
    bypass: { from: 3, to: 11, d: 'M 394 548 C 414 508 452 478 514 421', color: '#347b4e', text: 'BRIDGE  3 → 11', tx: 452, ty: 478, bridge: true },
    lock: { from: 6, to: 1, d: 'M 754 548 C 717 596 664 601 573 601 L 251 601 C 203 601 167 582 154 548', color: '#b64a3b', text: 'NO KEY: RETURN TO 1', tx: 459, ty: 601, dashed: true },
    shortcut: { from: 12, to: 18, d: 'M 394 421 C 414 378 432 350 447 311', color: '#347b4e', text: 'BRIDGE  12 → 18', tx: 419, ty: 366, bridge: true },
    lion: { from: 17, to: 10, d: 'M 349 311 C 418 360 500 373 575 384 C 607 392 628 405 634 421', color: '#b64a3b', text: 'NO WEAPON: BACK TO 10', tx: 512, ty: 373, dashed: true },
    river: { from: 25, to: 29, d: 'M 388 208 C 360 174 302 140 257 106', color: '#347b4e', text: 'BRIDGE  25 → 29', tx: 320, ty: 157, bridge: true },
    wolf: { from: 27, to: 24, d: 'M 154 208 C 197 258 263 264 352 264 L 433 264 C 464 264 493 240 506 208', color: '#b64a3b', text: 'NO KNIFE: BACK TO 24', tx: 335, ty: 264, dashed: true },
    final: { from: 35, to: 30, d: 'M 875 106 C 834 54 763 45 697 45 L 425 45 C 386 45 365 77 360 106', color: '#b64a3b', text: 'NO KEY OR HAMMER: BACK TO 30', tx: 610, ty: 45, dashed: true }
  };

  var state = {
    selectedCount: 2, players: [], current: 0, busy: false, started: false, turns: 0,
    sound: true, ambience: true, livingJungle: true, animations: true,
    movementSpeed: 'slow', playMode: 'hotseat', ambientClip: null, ambientPlaying: false,
    audio: null, won: false, rankings: [], finishEvents: [], lastFinishNotice: '',
    customNames: NAMES.slice(), renameIndex: -1,
    clips: {}, lastRoll: 0, lastSound: '', soundEvents: [], visualEvents: [], motionFrames: 0,
    gateFrames: { 6: 'closed', 35: 'closed' }, gateEvents: [],
    animalFrames: { 17: 'idle', 27: 'idle' }, animalEvents: [], defeatEvents: [],
    tutorial: { index: 0, visible: false, returnToGuide: false },
    network: {
      transport: '', role: '', connected: false, localPlayer: 0, revision: 0,
      timer: null, waitingForRoll: false, localName: '', hostAddress: '', lastError: '',
      expectedPlayers: 2, connectedGuests: 0, peerNames: [], clientIds: [], clientId: '',
      roomCode: '', playerId: '', reconnectToken: '', onlineSocket: null
      ,logs: []
    },
    voice: { active: false, muted: false, peers: {}, stream: null }
  };
  var els = {};

  for (var row = 0, spaceNumber = 1; row < ROWS.length; row++) {
    for (var col = 0; col < ROWS[row].length; col++, spaceNumber++) {
      POS[spaceNumber] = { x: ROWS[row][col], y: Y[row], row: row };
    }
  }

  function artwork(name) { return 'art/' + name + '.png'; }

  function avatarArtwork(player, pose) {
    var identity = player && AVATARS.indexOf(player.avatar) >= 0
      ? player.avatar : AVATARS[Math.max(0, state.players.indexOf(player))] || AVATARS[0];
    return artwork('avatar_' + identity + '_' + (AVATAR_POSES[pose] || AVATAR_POSES.idle));
  }

  function drawAvatar(parent, player, x, y, width, height, pose, className) {
    return svg('image', { href: avatarArtwork(player, pose), x: x, y: y,
      width: width, height: height, preserveAspectRatio: 'xMidYMax meet',
      class: className || 'explorer-avatar', 'data-avatar': player.avatar,
      'data-avatar-pose': pose, 'aria-label': player.name + ' explorer avatar' }, parent);
  }

  function svg(tag, attrs, parent) {
    var node = document.createElementNS(SVG_NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, String(attrs[key])); });
    if (parent) parent.appendChild(node);
    return node;
  }

  function text(parent, x, y, value, attrs) {
    var options = { x: x, y: y, 'text-anchor': 'middle', 'font-family': 'Georgia,serif', fill: '#382518' };
    Object.keys(attrs || {}).forEach(function (key) { options[key] = attrs[key]; });
    var node = svg('text', options, parent);
    node.textContent = value;
    return node;
  }

  function rounded(parent, x, y, width, height, fill, stroke, radius) {
    return svg('rect', { x: x, y: y, width: width, height: height, rx: radius || 6, fill: fill, stroke: stroke || '#382518', 'stroke-width': 2 }, parent);
  }

  function drawIcon(parent, kind, x, y, color) {
    var g = svg('g', { transform: 'translate(' + x + ',' + y + ')',
      class: 'jungle-object jungle-' + kind + '-depth' }, parent);
    if (kind === 'key') {
      g.approvedImage = svg('image', { href: artwork('key_normal'), x: -36, y: -38, width: 72, height: 59,
        preserveAspectRatio: 'xMidYMid meet' }, g);
    } else if (kind === 'lock') {
      g.approvedImage = svg('image', { href: artwork('gate_closed'), x: -53, y: -74, width: 106, height: 88,
        preserveAspectRatio: 'xMidYMid meet' }, g);
      // Keep the existing animation anchor addressable without drawing the old
      // padlock on top of the owner-approved standalone jungle gate.
      g.lockShackle = svg('path', {
        d: 'M -10 -2 L -10 -10 C -10 -24 10 -24 10 -10 L 10 -2',
        fill: 'none', opacity: '0', 'aria-hidden': 'true'
      }, g);
    } else if (kind === 'medical') {
      svg('rect', { x: -5, y: -17, width: 10, height: 34, rx: 2, fill: color }, g);
      svg('rect', { x: -17, y: -5, width: 34, height: 10, rx: 2, fill: color }, g);
    } else if (kind === 'hospital') {
      svg('path', { d: 'M -19 -5 L 0 -19 L 19 -5 L 16 -5 L 16 17 L -16 17 L -16 -5 Z', fill: '#f3e9d0', stroke: '#382518', 'stroke-width': 2 }, g);
      svg('rect', { x: -4, y: 5, width: 8, height: 12, fill: '#69523a' }, g);
      svg('path', { d: 'M 0 -11 L 0 0 M -5 -6 L 5 -6', stroke: '#b4473b', 'stroke-width': 3 }, g);
    } else if (kind === 'knife') {
      svg('path', { d: 'M -3 1 L 20 -20 Q 17 -3 4 9 Z', fill: color, stroke: '#382518', 'stroke-width': 1 }, g);
      svg('path', { d: 'M -3 5 L -16 17 M -9 -1 L 1 10', fill: 'none', stroke: color, 'stroke-width': 5, 'stroke-linecap': 'round' }, g);
    } else if (kind === 'axe') {
      svg('path', { d: 'M -16 18 L 15 -20', fill: 'none', stroke: color, 'stroke-width': 6, 'stroke-linecap': 'round' }, g);
      svg('path', { d: 'M 3 -15 Q -7 5 -19 -7 L -5 -23 Q 4 -23 3 -15 Z', fill: color, stroke: '#382518', 'stroke-width': 1 }, g);
    } else if (kind === 'hammer') {
      g.approvedImage = svg('image', { href: artwork('hammer'), x: -29, y: -40,
        width: 58, height: 57, preserveAspectRatio: 'xMidYMid meet',
        class: 'board-hammer-artwork' }, g);
    } else if (kind === 'shortcut') {
      svg('path', { d: 'M -19 13 C -2 13 -8 -15 13 -11', fill: 'none', stroke: color, 'stroke-width': 6, 'stroke-linecap': 'round' }, g);
      svg('path', { d: 'M 12 -19 L 23 -11 L 12 -4 Z', fill: color }, g);
    } else if (kind === 'lion') {
      g.approvedImage = svg('image', { href: artwork('lion_idle'), x: -52, y: -86, width: 104, height: 99,
        preserveAspectRatio: 'xMidYMid meet' }, g);
    } else if (kind === 'wolf') {
      g.approvedImage = svg('image', { href: artwork('wolf_idle'), x: -49, y: -85, width: 98, height: 97,
        preserveAspectRatio: 'xMidYMid meet' }, g);
    }
    return g;
  }

  function drawLivingWater(board) {
    var water = svg('g', { id: 'jungle-water-layer', class: 'jungle-water-layer',
      'aria-hidden': 'true', 'pointer-events': 'none' }, board);
    [
      'M 139 480 C 309 467 557 471 864 481',
      'M 150 369 C 329 355 576 360 763 354',
      'M 159 267 C 356 254 607 261 775 265',
      'M 189 161 C 373 154 602 154 765 162'
    ].forEach(function (route, index) {
      svg('path', { d: route, fill: 'none', stroke: '#c7eef0',
        'stroke-width': index === 0 ? 2.2 : 1.8, 'stroke-linecap': 'round',
        opacity: '.33', class: 'jungle-river-flow',
        style: 'animation-delay:-' + (index * .62) + 's' }, water);
      svg('path', { d: route, fill: 'none', stroke: '#f3fff4',
        'stroke-width': 1.2, 'stroke-linecap': 'round', opacity: '.46',
        class: 'jungle-river-glint',
        style: 'animation-delay:-' + (index * .87) + 's' }, water);
    });

    [
      { d: 'M 71 75 C 74 93 70 108 73 126', x: 73, y: 130, rx: 14 },
      { d: 'M 796 171 C 794 185 799 195 806 205', x: 809, y: 207, rx: 13 },
      { d: 'M 857 244 C 860 257 870 271 876 283', x: 878, y: 286, rx: 15 }
    ].forEach(function (fall, index) {
      svg('path', { d: fall.d, fill: 'none', stroke: '#d8f8f5',
        'stroke-width': index ? 3 : 4, 'stroke-linecap': 'round', opacity: '.56',
        class: 'jungle-waterfall-drop',
        style: 'animation-delay:-' + (index * .24) + 's' }, water);
      svg('ellipse', { cx: fall.x, cy: fall.y, rx: fall.rx, ry: 4,
        fill: '#d3f5ef', opacity: '.46', class: 'jungle-waterfall-foam' }, water);
      svg('ellipse', { cx: fall.x + 5, cy: fall.y - 3, rx: fall.rx + 7, ry: 9,
        fill: '#e8fbef', opacity: '.19', class: 'jungle-mist' }, water);
    });
    return water;
  }

  function drawJungleAtmosphere(board) {
    var atmosphere = svg('g', { id: 'jungle-atmosphere', class: 'jungle-atmosphere-layer',
      'aria-hidden': 'true', 'pointer-events': 'none' }, board);
    [
      [58, 52], [180, 42], [346, 77], [524, 36], [688, 87], [956, 66],
      [43, 313], [938, 327], [74, 506], [936, 521], [240, 624], [729, 612]
    ].forEach(function (point, index) {
      svg('circle', { cx: point[0], cy: point[1], r: index % 3 ? 1.8 : 2.4,
        fill: '#ffe995', opacity: '.75', class: 'jungle-firefly',
        style: '--firefly-delay:-' + (index * .37) + 's' }, atmosphere);
    });

    var foreground = svg('g', { id: 'jungle-foreground',
      class: 'jungle-foreground-layer', 'aria-hidden': 'true',
      'pointer-events': 'none' }, board);
    [
      'M 0 658 L 0 590 C 24 602 45 636 66 646 C 50 615 61 601 91 590 C 85 620 91 641 114 658 Z',
      'M 1070 658 L 1070 574 C 1048 589 1035 618 1009 639 C 1021 611 1010 593 986 579 C 988 615 974 641 954 658 Z',
      'M 0 0 L 106 0 C 90 15 71 22 54 17 C 60 34 47 46 30 55 C 31 31 18 20 0 24 Z'
    ].forEach(function (shape) {
      svg('path', { d: shape, fill: '#153d23', opacity: '.66' }, foreground);
    });
  }

  function drawBoard() {
    var board = els.board;
    board.textContent = '';
    var defs = svg('defs', {}, board);
    els.boardArtwork = {};

    var stone = svg('radialGradient', { id: 'jungle-stone', cx: '38%', cy: '29%',
      r: '79%' }, defs);
    svg('stop', { offset: '0%', 'stop-color': '#f6e1b7' }, stone);
    svg('stop', { offset: '72%', 'stop-color': '#d3b17e' }, stone);
    svg('stop', { offset: '100%', 'stop-color': '#a57d50' }, stone);

    // One background is the board. Objects are anchored directly on its real
    // jungle paths; there is no second tilted board, ribbon, or camera layer.
    svg('image', { href: 'art/jungle_natural.jpg', x: 0, y: 0, width: 1070, height: 658,
      preserveAspectRatio: 'none', opacity: '1' }, board);
    drawLivingWater(board);

    // The actual visible river already belongs to the background. Keep an
    // invisible semantic barrier for the 27 → 28 trail turn and the owner's
    // newly approved elevated 25 → 29 bridge across the river.
    svg('path', {
      id: 'river-barrier', d: 'M 205 155 C 356 153 538 151 757 155 L 940 155',
      fill: 'none', stroke: 'none', opacity: '0', 'data-crossing': '27-28',
      'data-bridge-crossing': '25-29'
    }, board);

    Object.keys(ROUTES).forEach(function (id) {
      var route = ROUTES[id];
      if (route.bridge) {
        svg('path', { d: route.d, fill: 'none', stroke: '#182b19',
          'stroke-width': 25, 'stroke-linecap': 'round',
          transform: 'translate(0,5)', class: 'wooden-bridge-depth-shadow' }, board);
        svg('path', { d: route.d, fill: 'none', stroke: '#513521', 'stroke-width': 20,
          'stroke-linecap': 'round', class: 'wooden-bridge-rail' }, board);
        svg('path', { d: route.d, fill: 'none', stroke: '#bb8752', 'stroke-width': 14,
          'stroke-dasharray': '5 3', 'stroke-linecap': 'round',
          class: 'wooden-bridge-planks' }, board);
      }
      // Hidden setback paths still drive smooth player movement without
      // cluttering the owner's jungle with floating route labels and arrows.
      svg('path', {
        id: 'route-' + id, d: route.d, fill: 'none',
        stroke: route.bridge ? '#e3bc75' : 'none',
        'stroke-width': route.bridge ? 2 : 1,
        opacity: route.bridge ? '.79' : '0', 'stroke-linecap': 'round'
      }, board);
    });

    for (var number = 1; number <= 35; number++) {
      var point = POS[number];
      var special = SPECIAL[number];
      if (special) {
        var tile = svg('ellipse', {
          id: 'tile-' + number, cx: point.x, cy: point.y + 3,
          rx: special.icon === 'lock' ? 40 : 32, ry: 20,
          fill: 'url(#jungle-stone)', opacity: '.66',
          stroke: '#755733', 'stroke-width': 1.5,
          'data-space': number, 'aria-label': 'Path space ' + number
        }, board);
        if (special.icon === 'lion' || special.icon === 'wolf' || special.icon === 'lock') {
          svg('ellipse', { cx: point.x, cy: point.y + 11,
            rx: special.icon === 'lock' ? 42 : 34, ry: 9,
            fill: '#14251b', class: 'jungle-ground-shadow' }, board);
        }
        var obstacleIcon = drawIcon(board, special.icon, point.x, point.y + 1, special.color);
        obstacleIcon.setAttribute('id', 'space-icon-' + number);
        if (obstacleIcon.approvedImage) els.boardArtwork[number] = obstacleIcon.approvedImage;
        if (obstacleIcon.lockShackle) obstacleIcon.lockShackle.setAttribute('id', 'lock-shackle-' + number);
      } else {
        svg('ellipse', { cx: point.x, cy: point.y, rx: 20, ry: 14,
          fill: 'url(#jungle-stone)', opacity: '.59', stroke: '#765937',
          'stroke-width': 1.25, 'data-space': number,
          'aria-label': 'Path space ' + number }, board);
        svg('ellipse', { cx: point.x, cy: point.y, rx: 16, ry: 10,
          fill: 'none', stroke: '#eed39f', 'stroke-width': .8, opacity: '.58' }, board);
      }
    }

    rounded(board, 33, 574, 82, 32, '#624526', '#d6ac66', 6);
    text(board, 74, 596, 'START', { fill: '#fff0cb', 'font-size': 14,
      'font-weight': 'bold' });
    rounded(board, 946, 83, 78, 32, '#624526', '#d6ac66', 6);
    text(board, 985, 105, 'HOME', { fill: '#fff0cb', 'font-size': 14,
      'font-weight': 'bold' });

    els.tokenLayer = svg('g', { id: 'token-layer' }, board);
    drawTokens();
    drawJungleAtmosphere(board);
    syncLivingJungle();
  }

  function tokenPoint(playerIndex, position) {
    if (!position) return { x: 61 + playerIndex * 15, y: 555 };
    var p = POS[position];
    var offsets = [{ x: 22, y: -18 }, { x: 22, y: 8 }, { x: -17, y: 8 }, { x: -17, y: -10 }];
    return { x: p.x + offsets[playerIndex].x, y: p.y + offsets[playerIndex].y };
  }

  function drawTokens() {
    if (!els.tokenLayer) return;
    els.tokenLayer.textContent = '';
    state.players.forEach(function (player, index) {
      var point = player.animatedPoint || tokenPoint(index, player.position);
      var g = svg('g', { id: 'token-' + index, transform: 'translate(' + point.x + ',' + point.y + ')' }, els.tokenLayer);
      svg('ellipse', { cx: 0, cy: 16, rx: 10, ry: 4,
        fill: '#19241b', class: 'jungle-token-shadow' }, g);
      if (index === state.current && state.started && !state.won && !player.finished) {
        svg('ellipse', { cx: 0, cy: 14, rx: 16, ry: 6, fill: 'none',
          stroke: '#fff6da', 'stroke-width': 2 }, g);
      }
      var pose = player.expression === 'cry' || player.expression === 'fallen' ? 'cry' :
        player.finished && !player.lastPlace ? 'victory' : player.avatarPose ||
        (player.animatedPoint ? (state.motionFrames % 2 ? 'walkA' : 'walkB') : 'idle');
      g.setAttribute('class', player.expression === 'fallen' ? 'falling-board-token' :
        player.expression === 'cry' ? 'crying-board-token' :
        player.finished && !player.lastPlace ? 'finished-board-token' : 'explorer-avatar-token');
      drawAvatar(g, player, -23, -39, 46, 57, pose,
        'board-explorer-avatar board-avatar-' + pose);
    });
  }

  function makePlayers(count) {
    var players = [];
    for (var i = 0; i < count; i++) players.push({
      name: cleanName(state.customNames[i], i), color: COLORS[i], avatar: AVATARS[i],
      position: 0, firstKey: false, finalKey: false, knife: false, axe: false,
      hammer: false, finished: false, rank: 0, lastPlace: false,
      rolls: 0, diceBag: [], lastDie: 0
    });
    return players;
  }

  function cleanName(value, index) {
    var normalized = String(value || '').trim().replace(/\s+/g, ' ').slice(0, 22);
    return normalized || NAMES[index];
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (character) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character];
    });
  }

  function setPlayerName(index, value) {
    if (index < 0 || index >= COLORS.length) return '';
    var name = cleanName(value, index);
    state.customNames[index] = name;
    if (state.players[index]) state.players[index].name = name;
    if (els.active) renderHud();
    return name;
  }

  function gear(icon, label, active) {
    return '<div class="gear' + (active ? ' active' : '') + '"><span class="gear-icon">' + icon + '</span>' + label + '</div>';
  }

  function rankLabel(rank) {
    return rank + (rank === 1 ? 'st' : rank === 2 ? 'nd' : rank === 3 ? 'rd' : 'th');
  }

  function renderRankings() {
    if (!els.rankings) return;
    els.rankings.innerHTML = state.rankings.map(function (index) {
      var player = state.players[index];
      return '<div class="ranking-row ranking-place-' + player.rank + '" role="listitem">' +
        '<span class="ranking-medal" aria-label="' + rankLabel(player.rank) + ' place">' +
        (player.rank === 1 ? '♛' : rankLabel(player.rank)) + '</span>' +
        '<span class="token-chip" style="background:' + player.color + '">' +
        (index + 1) + '</span><span class="ranking-name">' +
        escapeHtml(player.name) + '</span><span class="ranking-result">' +
        (player.lastPlace ? 'LAST' : player.finishMethod === 'hammer' ? 'HAMMER' : 'HOME') +
        '</span></div>';
    }).join('');
  }

  function renderHud() {
    if (!state.players.length) return;
    var p = state.players[state.current];
    els.active.innerHTML = '<span class="token-chip" style="background:' + p.color + '">' + (state.current + 1) + '</span>' + escapeHtml(p.name) + '<span class="current-edit">✎</span>';
    els.position.textContent = p.position ? 'Standing on space ' + p.position + ' of 35' : 'Waiting at START';
    els.inventory.innerHTML = gear('⚿', 'First key', p.firstKey) +
      gear('⚔', 'Knife', p.knife) + gear('⚒', 'Axe', p.axe) +
      gear('🔨', 'Hammer', p.hammer) + gear('⚿', 'Final key', p.finalKey);
    els.playersList.innerHTML = state.players.map(function (item, index) {
      return '<div class="player-row' + (index === state.current && !item.finished ? ' current' : '') +
        (item.finished ? ' finished' : '') + '">' +
        '<span class="token-chip" style="background:' + item.color + '">' + (index + 1) + '</span>' +
        '<span class="player-name">' + escapeHtml(item.name) + '</span>' +
        (item.rank ? '<span class="player-rank rank-' + item.rank + '">' +
          rankLabel(item.rank) + '</span>' : '') +
        '<span class="player-pos">' + (item.lastPlace ? 'LAST' :
          item.finished ? 'HOME' : item.position || 'START') + '</span>' +
        '<button class="name-edit" data-player-index="' + index + '" aria-label="Edit player name">✎</button></div>';
    }).join('');
    var remoteTurn = state.network.connected && state.current !== state.network.localPlayer;
    var disconnectedGame = state.playMode !== 'hotseat' && state.network.role &&
      !state.network.connected;
    els.roll.disabled = state.busy || state.won || !state.started || p.finished || remoteTurn ||
      state.network.waitingForRoll || disconnectedGame;
    if (state.started && !state.busy && state.network.connected && remoteTurn) {
      els.hint.textContent = 'Waiting for ' + p.name + ' on another device.';
    }
    drawTokens();
  }

  function previewPlayers() {
    els.preview.classList.toggle('single', state.selectedCount === 1);
    els.preview.innerHTML = COLORS.slice(0, state.selectedCount).map(function (color, index) {
      return '<label class="name-entry"><span class="token-chip" style="background:' + color + '">' +
        (index + 1) + '</span><input class="player-name-input" data-player-index="' + index +
        '" type="text" maxlength="22" autocomplete="off" value="' +
        escapeHtml(state.customNames[index] || NAMES[index]) +
        '" aria-label="Explorer ' + (index + 1) + ' name"></label>';
    }).join('');
  }

  function beginGame(count) {
    state.selectedCount = count || state.selectedCount;
    state.players = makePlayers(state.selectedCount);
    state.current = 0;
    state.turns = 0;
    state.busy = false;
    state.started = true;
    state.won = false;
    state.rankings = [];
    state.finishEvents = [];
    state.lastFinishNotice = '';
    state.lastRoll = 0;
    state.soundEvents = [];
    state.visualEvents = [];
    state.gateFrames = { 6: 'closed', 35: 'closed' };
    state.gateEvents = [];
    state.animalFrames = { 17: 'idle', 27: 'idle' };
    state.animalEvents = [];
    state.defeatEvents = [];
    state.motionFrames = 0;
    els.setup.classList.remove('visible');
    els.victory.classList.remove('visible');
    renderRankings();
    els.scene.className = 'scene-overlay';
    els.scene.setAttribute('aria-hidden', 'true');
    setDieFace(randomDie());
    els.hint.textContent = state.players[0].name + ': tap the dice to begin.';
    els.message.textContent = state.players.length > 1
      ? (state.network.connected ? 'Connected adventure: ' : 'Pass-and-play adventure: ') +
        state.players[0].name + ' goes first.'
      : 'Find the keys, brave the wild, and unlock HOME.';
    renderHud();
    syncAmbientSound();
    scheduleAiTurn();
  }

  function isAiPlayer(index) {
    return state.playMode === 'ai' && index > 0;
  }

  function scheduleAiTurn() {
    if (!state.started || state.busy || state.won || !isAiPlayer(state.current)) return;
    window.setTimeout(function () {
      if (!state.busy && !state.won && isAiPlayer(state.current)) takeRoll();
    }, 650);
  }

  function setDieFace(value) {
    if (!Number.isInteger(value) || value < 1 || value > 6) {
      throw new RangeError('A six-sided die must show a value from 1 to 6.');
    }
    var visible = PIPS[value - 1];
    var dots = '';
    for (var index = 0; index < 9; index++) {
      dots += '<span class="die-pip' + (visible.indexOf(index) >= 0 ? ' active' : '') + '"></span>';
    }
    els.die.innerHTML = dots;
    els.die.setAttribute('data-value', value);
    els.die.setAttribute('aria-label', 'Dice showing ' + value);
  }

  function randomIndex(size) {
    var generator = window.crypto || window.msCrypto;
    if (generator && typeof generator.getRandomValues === 'function' && typeof Uint32Array !== 'undefined') {
      var sample = new Uint32Array(1);
      // Reject the uneven tail for every shuffle size, not only six-sided rolls.
      var unbiasedLimit = Math.floor(4294967296 / size) * size;
      do { generator.getRandomValues(sample); } while (sample[0] >= unbiasedLimit);
      return sample[0] % size;
    }
    return Math.floor(Math.random() * size);
  }

  function randomDie() {
    return randomIndex(6) + 1;
  }

  function nextDie(player) {
    if (!player.diceBag.length) {
      player.diceBag = [1, 2, 3, 4, 5, 6];
      for (var index = player.diceBag.length - 1; index > 0; index--) {
        var selected = randomIndex(index + 1);
        var value = player.diceBag[index];
        player.diceBag[index] = player.diceBag[selected];
        player.diceBag[selected] = value;
      }
      // Keep two consecutive bags from repeating their boundary face.
      if (player.lastDie && player.diceBag[player.diceBag.length - 1] === player.lastDie) {
        var replacement = player.diceBag[0];
        player.diceBag[0] = player.diceBag[player.diceBag.length - 1];
        player.diceBag[player.diceBag.length - 1] = replacement;
      }
    }
    player.lastDie = player.diceBag.pop();
    return player.lastDie;
  }

  function persistSettings() {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({
          sound: state.sound,
          ambience: state.ambience,
          livingJungle: state.livingJungle,
          animations: state.animations,
          movementSpeed: state.movementSpeed
        }));
      }
    } catch (error) {}
  }

  function loadSettings() {
    try {
      if (!window.localStorage) return false;
      var raw = window.localStorage.getItem(SETTINGS_KEY);
      if (!raw) return false;
      var settings = JSON.parse(raw);
      if (typeof settings.sound === 'boolean') state.sound = settings.sound;
      if (typeof settings.ambience === 'boolean') state.ambience = settings.ambience;
      if (typeof settings.livingJungle === 'boolean') state.livingJungle = settings.livingJungle;
      if (typeof settings.animations === 'boolean') state.animations = settings.animations;
      if (Object.prototype.hasOwnProperty.call(SPEED_FACTORS, settings.movementSpeed)) {
        state.movementSpeed = settings.movementSpeed;
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  function renderSettings() {
    if (!els.settingsSound) return;
    els.settingsSound.textContent = state.sound ? 'ON' : 'OFF';
    els.settingsSound.classList.toggle('enabled', state.sound);
    els.settingsSound.setAttribute('aria-pressed', String(state.sound));
    els.soundButton.textContent = state.sound ? '♪' : '♪̸';
    if (els.settingsAmbience) {
      els.settingsAmbience.textContent = state.ambience ? 'ON' : 'OFF';
      els.settingsAmbience.classList.toggle('enabled', state.ambience);
      els.settingsAmbience.setAttribute('aria-pressed', String(state.ambience));
    }
    if (els.settingsJungle) {
      els.settingsJungle.textContent = state.livingJungle ? 'ON' : 'OFF';
      els.settingsJungle.classList.toggle('enabled', state.livingJungle);
      els.settingsJungle.setAttribute('aria-pressed', String(state.livingJungle));
    }
    els.settingsAnimation.textContent = state.animations ? 'ON' : 'OFF';
    els.settingsAnimation.classList.toggle('enabled', state.animations);
    els.settingsAnimation.setAttribute('aria-pressed', String(state.animations));
    Object.keys(SPEED_FACTORS).forEach(function (speed) {
      els.speedButtons[speed].classList.toggle('selected', speed === state.movementSpeed);
      els.speedButtons[speed].setAttribute('aria-pressed', String(speed === state.movementSpeed));
    });
    if (els.modeButtons) {
      Object.keys(els.modeButtons).forEach(function (mode) {
        if (els.modeButtons[mode]) els.modeButtons[mode].classList.toggle('selected', mode === state.playMode);
      });
    }
  }

  function nativeTransport() {
    var bridge = window.KeysClawsNative;
    return bridge && typeof bridge.poll === 'function' && typeof bridge.send === 'function'
      ? bridge : null;
  }

  function networkStatus(message, failed) {
    logNetwork(failed ? 'error' : 'status', message);
    state.network.lastError = failed ? message : '';
    if (els.networkStatus) {
      els.networkStatus.textContent = message;
      els.networkStatus.classList.toggle('error', Boolean(failed));
    }
    if (failed && els.message) els.message.textContent = message;
    return !failed;
  }

  function logNetwork(kind, message, details) {
    var entry = { at: new Date().toISOString(), kind: kind, message: String(message || '') };
    if (details) entry.details = details;
    state.network.logs.push(entry);
    if (state.network.logs.length > 100) state.network.logs.shift();
    try { window.localStorage.setItem('keys-claws-network-log', JSON.stringify(state.network.logs)); } catch (error) {}
    if (window.console && console.info) console.info('[KeysClaws network]', entry);
  }

  function sendNetwork(message) {
    if (state.network.transport === 'online') {
      var onlineSocket = state.network.onlineSocket;
      if (!onlineSocket || onlineSocket.readyState !== 1) return false;
      try { onlineSocket.send(JSON.stringify(message)); return true; } catch (error) {
        return networkStatus('Online connection lost. Reconnect to continue.', true);
      }
    }
    var bridge = nativeTransport();
    if (!bridge || !state.network.connected) return false;
    try {
      if (!bridge.send(JSON.stringify(message))) {
        state.network.connected = false;
        state.network.waitingForRoll = false;
        renderHud();
        return networkStatus('A connected explorer is no longer available.', true);
      }
      return true;
    } catch (error) {
      state.network.connected = false;
      state.network.waitingForRoll = false;
      renderHud();
      return networkStatus('Connection lost: ' + String(error.message || error), true);
    }
  }

  function onlineState(serverState, events) {
    if (!serverState || !Array.isArray(serverState.players)) return false;
    state.players = serverState.players.map(function (item, index) {
      return Object.assign({ name: NAMES[index], color: COLORS[index], avatar: AVATARS[index],
        position: 0, firstKey: false, finalKey: false, knife: false, axe: false,
        hammer: false, finished: false, rank: 0, lastPlace: false, rolls: 0 }, item);
    });
    state.selectedCount = state.players.length;
    state.current = Number(serverState.currentPlayerIndex) || 0;
    state.turns = Number(serverState.turns) || 0;
    state.network.revision = Number(serverState.revision) || 0;
    state.started = Boolean(serverState.started);
    state.won = Boolean(serverState.completed);
    state.rankings = Array.isArray(serverState.rankings) ? serverState.rankings.slice() : [];
    state.players.forEach(function (player, index) {
      state.customNames[index] = player.name;
      player.avatar = player.avatar || AVATARS[index];
      player.color = player.color || COLORS[index];
    });
    if (Array.isArray(events)) events.forEach(function (event) {
      if (event.type === 'ROLL') { state.lastRoll = event.value; setDieFace(event.value); }
      if (event.type === 'FINISH') state.players[event.player].finishMethod = String(event.method || '').toLowerCase();
      if (event.type === 'FINAL_STANDINGS') state.won = true;
    });
    renderRankings(); renderHud();
    if (state.won) els.message.textContent = 'All explorers are HOME. Final rankings are shown.';
    else if (state.started) els.message.textContent = state.players[state.current].name + ': your online turn.';
    return true;
  }

  function voiceSignal(message) { return sendNetwork(message); }

  function makeVoicePeer(remoteIndex, initiator) {
    if (state.voice.peers[remoteIndex]) return state.voice.peers[remoteIndex];
    if (!window.RTCPeerConnection) throw new Error('Voice calling is not supported on this device.');
    var peer = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    state.voice.peers[remoteIndex] = peer;
    if (state.voice.stream) state.voice.stream.getTracks().forEach(function (track) { peer.addTrack(track, state.voice.stream); });
    peer.onicecandidate = function (event) { if (event.candidate) voiceSignal({ type: 'VOICE_ICE', to: remoteIndex, candidate: event.candidate }); };
    peer.ontrack = function (event) {
      var audio = document.getElementById('voice-audio-' + remoteIndex) || document.createElement('audio');
      audio.id = 'voice-audio-' + remoteIndex; audio.autoplay = true; audio.srcObject = event.streams[0];
      if (!audio.parentNode) document.body.appendChild(audio);
    };
    if (initiator) peer.createOffer().then(function (offer) {
      return peer.setLocalDescription(offer).then(function () {
        voiceSignal({ type: 'VOICE_OFFER', to: remoteIndex, description: peer.localDescription });
      });
    }).catch(function () {});
    return peer;
  }

  async function handleVoiceSignal(message) {
    if (!message || (message.to !== undefined && Number(message.to) !== state.network.localPlayer)) return;
    if (message.type === 'VOICE_HANGUP') return stopVoiceCall(false);
    try {
      var remote = Number(message.from);
      var peer = makeVoicePeer(remote, false);
      if (message.type === 'VOICE_OFFER') {
        await peer.setRemoteDescription(message.description);
        var answer = await peer.createAnswer(); await peer.setLocalDescription(answer);
        voiceSignal({ type: 'VOICE_ANSWER', to: remote, description: peer.localDescription });
      } else if (message.type === 'VOICE_ANSWER') await peer.setRemoteDescription(message.description);
      else if (message.type === 'VOICE_ICE' && message.candidate) await peer.addIceCandidate(message.candidate);
      state.voice.active = true; updateVoiceButton();
    } catch (error) { networkStatus('Voice call could not connect.', true); }
  }

  function updateVoiceButton() {
    var button = document.getElementById('voice-btn');
    if (!button) return;
    button.textContent = state.voice.active ? (state.voice.muted ? '☎̸' : '☎') : '☎';
    button.classList.toggle('active', state.voice.active);
    button.setAttribute('aria-label', state.voice.active ? 'Mute or end voice call' : 'Start voice call');
  }

  async function startVoiceCall() {
    if (state.network.transport !== 'online' || !state.network.connected) return networkStatus('Join an online room before starting a voice call.', true);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return networkStatus('Voice calling is not supported on this device.', true);
    try {
      state.voice.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      state.voice.active = true; state.voice.muted = false;
      state.players.forEach(function (player, index) { if (index !== state.network.localPlayer && player.connected !== false) makeVoicePeer(index, index > state.network.localPlayer); });
      updateVoiceButton(); networkStatus('Voice call active. Tap ☎ to mute, tap again to end.');
    } catch (error) { networkStatus('Microphone permission is required for voice calling.', true); }
  }

  function stopVoiceCall(notify) {
    Object.keys(state.voice.peers).forEach(function (key) { try { state.voice.peers[key].close(); } catch (error) {} });
    state.voice.peers = {};
    if (state.voice.stream) state.voice.stream.getTracks().forEach(function (track) { track.stop(); });
    state.voice.stream = null; state.voice.active = false; state.voice.muted = false; updateVoiceButton();
    if (notify !== false && state.network.connected) voiceSignal({ type: 'VOICE_HANGUP' });
  }

  function toggleVoiceCall() {
    if (!state.voice.active) return startVoiceCall();
    if (state.voice.stream) {
      state.voice.muted = !state.voice.muted;
      state.voice.stream.getAudioTracks().forEach(function (track) { track.enabled = !state.voice.muted; });
      updateVoiceButton();
    } else stopVoiceCall(true);
  }

  function connectOnline() {
    var code = state.network.roomCode;
    var socketUrl = ONLINE_SERVER.replace(/^https:/, 'wss:') +
      '/api/rooms/' + encodeURIComponent(code) + '/connect?playerId=' +
      encodeURIComponent(state.network.playerId) + '&token=' +
      encodeURIComponent(state.network.reconnectToken);
    logNetwork('connect-start', 'Opening online WebSocket', { room: code });
    var socket = new WebSocket(socketUrl);
    state.network.onlineSocket = socket;
    socket.onopen = function () {
      logNetwork('connect-open', 'Online WebSocket opened', { room: code });
      state.network.connected = true;
      networkStatus('Online room ' + code + ' connected. Waiting for explorers…');
      renderHud();
    };
    socket.onmessage = function (event) {
      var message;
      try { message = JSON.parse(event.data); } catch (error) { return; }
      if (message.type === 'STATE') return onlineState(message.state, message.events);
      if (message.type === 'VOICE') { logNetwork('voice-signal', message.message && message.message.type); return handleVoiceSignal(message.message); }
      if (message.type === 'ERROR') networkStatus('Online error: ' + message.error, true);
    };
    socket.onclose = function () {
      logNetwork('connect-close', 'Online WebSocket closed', { code: socket.code, reason: socket.reason || '' });
      state.network.connected = false; renderHud();
      networkStatus('Online room disconnected. Reconnect to resume.', true);
    };
    socket.onerror = function (error) { logNetwork('connect-error', 'WebSocket error', { message: String(error && error.message || 'browser reported an error') }); networkStatus('Could not connect to the online room.', true); };
  }

  async function createOnlineRoom() {
    var response = await fetch(ONLINE_SERVER + '/api/rooms', { method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ expectedPlayers: state.network.expectedPlayers,
        hostName: cleanName(els.networkName.value, 0) }) });
    var result = await response.json();
    if (!response.ok) throw new Error(result.error || 'ROOM_CREATE_FAILED');
    state.network.role = 'host'; state.network.localPlayer = result.playerIndex;
    state.network.localName = cleanName(els.networkName.value, 0);
    state.network.roomCode = result.roomCode; state.network.playerId = result.playerId;
    state.network.reconnectToken = result.reconnectToken;
    networkStatus('Room ' + result.roomCode + ' created. Share this code with friends.');
    connectOnline();
  }

  async function joinOnlineRoom() {
    var code = String(els.networkAddress.value || '').trim().toUpperCase();
    if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) throw new Error('Enter the 6-character room code.');
    var response = await fetch(ONLINE_SERVER + '/api/rooms/' + code + '/join', { method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerName: cleanName(els.networkName.value, 1) }) });
    var result = await response.json();
    if (!response.ok) throw new Error(result.error || 'ROOM_JOIN_FAILED');
    state.network.role = 'guest'; state.network.localPlayer = result.playerIndex;
    state.network.localName = cleanName(els.networkName.value, result.playerIndex);
    state.network.roomCode = result.roomCode; state.network.playerId = result.playerId;
    state.network.reconnectToken = result.reconnectToken; state.network.expectedPlayers = result.playerIndex + 1;
    networkStatus('Joined room ' + result.roomCode + '. Waiting for the host…');
    connectOnline();
  }

  function finishNetworkSetup() {
    els.network.classList.remove('visible');
    closeSettings();
    renderHud();
  }

  function startSharedGame(names, clientIds) {
    var maximum = state.network.transport === 'wifi' ? 4 : 2;
    if (!Array.isArray(names) || names.length < 2 || names.length > maximum) return false;
    if (state.network.role === 'guest' && Array.isArray(clientIds)) {
      var assigned = clientIds.indexOf(state.network.clientId);
      if (assigned < 1 || assigned >= names.length) return false;
      state.network.localPlayer = assigned;
    } else if (names.length > 2 && state.network.role === 'guest') return false;
    names.forEach(function (name, index) {
      state.customNames[index] = cleanName(name, index);
    });
    if (Array.isArray(clientIds)) state.network.clientIds = clientIds.slice();
    state.network.expectedPlayers = names.length;
    state.network.revision = 0;
    state.network.waitingForRoll = false;
    beginGame(names.length);
    finishNetworkSetup();
    return true;
  }

  function authoritativeRoll(index) {
    if (!state.network.connected || state.network.role !== 'host' || state.busy ||
        state.won || !state.started || index !== state.current ||
        state.players[index].finished) return false;
    var value = nextDie(state.players[index]);
    var revision = state.network.revision + 1;
    if (!sendNetwork({ type: 'ROLL', player: index, value: value, revision: revision })) {
      return false;
    }
    state.network.revision = revision;
    state.network.waitingForRoll = false;
    takeRoll(value);
    return true;
  }

  function handleNetworkMessage(message, peerSlot) {
    if (!message || typeof message !== 'object') return false;
    if (message.type === 'HELLO' && state.network.role === 'host') {
      var slot = Number.isInteger(peerSlot) && peerSlot > 0 ? peerSlot : 1;
      while (!peerSlot && state.network.peerNames[slot]) slot++;
      if (slot >= state.network.expectedPlayers || state.network.peerNames[slot] ||
          state.started && state.network.revision > 0) return false;
      state.network.peerNames[slot] = cleanName(message.name, slot);
      state.network.clientIds[slot] = typeof message.clientId === 'string' &&
        message.clientId ? message.clientId.slice(0, 64) : 'guest-' + slot;
      var names = [state.network.localName];
      for (var index = 1; index < state.network.expectedPlayers; index++) {
        if (state.network.peerNames[index]) names[index] = state.network.peerNames[index];
      }
      var joined = names.filter(function (name) { return Boolean(name); }).length;
      if (joined < state.network.expectedPlayers) {
        var lobby = { type: 'LOBBY', joined: joined, expected: state.network.expectedPlayers };
        networkStatus('Host Wi-Fi address: ' + state.network.hostAddress + ' — ' + joined +
          ' of ' + state.network.expectedPlayers + ' explorers connected.');
        return sendNetwork(lobby);
      }
      var start = { type: 'START', names: names, revision: 0 };
      if (state.network.expectedPlayers > 2) start.clientIds = state.network.clientIds.slice();
      if (!sendNetwork(start)) return false;
      return startSharedGame(names, start.clientIds);
    }
    if (message.type === 'LOBBY' && state.network.role === 'guest') {
      if (!Number.isInteger(message.expected) || message.expected < 2 ||
          message.expected > 4 || !Number.isInteger(message.joined) ||
          message.joined < 1 || message.joined >= message.expected) return false;
      state.network.expectedPlayers = message.expected;
      networkStatus('Connected: ' + message.joined + ' of ' + message.expected +
        ' explorers are ready. Waiting for the others…');
      return true;
    }
    if (message.type === 'START' && state.network.role === 'guest') {
      return startSharedGame(message.names, message.clientIds);
    }
    if (message.type === 'ROLL_REQUEST' && state.network.role === 'host') {
      if (!Number.isInteger(message.player) || message.player < 1 ||
          message.player >= state.players.length ||
          peerSlot && peerSlot !== message.player ||
          message.revision !== state.network.revision ||
          state.current !== message.player || state.busy) return false;
      return authoritativeRoll(message.player);
    }
    if (message.type === 'ROLL' && state.network.role === 'guest') {
      if (message.revision !== state.network.revision + 1 ||
          message.player !== state.current || state.busy ||
          !Number.isInteger(message.value) || message.value < 1 || message.value > 6) {
        return false;
      }
      state.network.revision = message.revision;
      state.network.waitingForRoll = false;
      takeRoll(message.value);
      return true;
    }
    if (message.type === 'NAME' && Number.isInteger(message.player) &&
        message.player >= 0 && message.player < state.players.length) {
      if (state.network.role === 'host' &&
          (message.player === 0 || peerSlot && peerSlot !== message.player)) return false;
      setPlayerName(message.player, message.name);
      if (state.network.role === 'host') {
        return sendNetwork({ type: 'NAME', player: message.player,
          name: state.players[message.player].name });
      }
      return true;
    }
    return false;
  }

  function pollNetwork() {
    var bridge = nativeTransport();
    if (!bridge || state.busy) return 0;
    var count = 0;
    try {
      while (count < 12 && !state.busy) {
        var event = bridge.poll();
        if (!event) break;
        count++;
        if (event === 'status|waiting') {
          networkStatus(state.network.transport === 'wifi'
            ? 'Host Wi-Fi address: ' + state.network.hostAddress + ' — waiting for ' +
              (state.network.expectedPlayers - 1) + ' guest explorer' +
              (state.network.expectedPlayers === 2 ? '' : 's') + '.'
            : 'Game created. Ask your paired friend to join this device.');
        } else if (event === 'status|connected' ||
                   event.indexOf('status|connected|') === 0) {
          state.network.connected = true;
          if (state.network.role === 'guest') {
            networkStatus('Connected! Preparing your shared adventure…');
            sendNetwork({ type: 'HELLO', name: state.network.localName,
              clientId: state.network.clientId });
          } else {
            var connectedSlot = Number(event.split('|')[2]) || 1;
            state.network.connectedGuests = Math.max(state.network.connectedGuests, connectedSlot);
            var ready = state.network.connectedGuests + 1;
            networkStatus(state.network.transport === 'wifi'
              ? 'Host Wi-Fi address: ' + state.network.hostAddress + ' — ' + ready +
                ' of ' + state.network.expectedPlayers + ' explorers connected.'
              : 'Connected! Preparing your shared Bluetooth adventure…');
          }
        } else if (event.indexOf('data|') === 0) {
          var payload = event.slice(5);
          var boundary = payload.indexOf('|');
          var sourceSlot = 0;
          if (boundary > 0 && /^\d+$/.test(payload.slice(0, boundary))) {
            sourceSlot = Number(payload.slice(0, boundary));
            payload = payload.slice(boundary + 1);
          }
          handleNetworkMessage(JSON.parse(payload), sourceSlot);
        } else if (event.indexOf('error|') === 0) {
          state.network.connected = false;
          state.network.waitingForRoll = false;
          networkStatus('Connection closed: ' + event.slice(6), true);
          renderHud();
        }
      }
    } catch (error) {
      networkStatus('Connection error: ' + String(error.message || error), true);
    }
    return count;
  }

  function beginPolling() {
    if (state.network.timer !== null) clearInterval(state.network.timer);
    state.network.timer = setInterval(pollNetwork, 140);
  }

  function refreshPairedDevices() {
    if (state.network.transport !== 'bluetooth') return [];
    var bridge = nativeTransport();
    if (!bridge || typeof bridge.bondedDevices !== 'function') {
      networkStatus('Bluetooth multiplayer is available in the installed Android game.', true);
      return [];
    }
    try {
      var found = String(bridge.bondedDevices() || '').match(
        /(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}/g) || [];
      els.networkDevices.innerHTML = found.map(function (address) {
        return '<button type="button" class="peer-choice" data-address="' +
          escapeHtml(address) + '">ᛒ ' + escapeHtml(address) + '</button>';
      }).join('');
      if (!found.length) {
        networkStatus('No paired devices found. Pair both phones in Android Bluetooth settings first.', true);
      }
      return found;
    } catch (error) {
      networkStatus('Allow the Nearby devices permission and enable Bluetooth.', true);
      return [];
    }
  }

  function openNetwork(mode) {
    if (mode !== 'wifi' && mode !== 'bluetooth' && mode !== 'online') return false;
    state.playMode = mode;
    state.network.transport = mode;
    state.network.role = '';
    state.network.connected = false;
    state.network.waitingForRoll = false;
    state.network.expectedPlayers = 2;
    state.network.connectedGuests = 0;
    state.network.peerNames = [];
    state.network.clientIds = [];
    state.network.clientId = '';
    els.networkName.value = state.customNames[0] || NAMES[0];
    els.networkAddress.value = '';
    els.networkDevices.innerHTML = '';
    els.networkTitle.textContent = mode === 'wifi' ? 'Wi-Fi Adventure' : mode === 'online' ? 'Online Adventure' : 'Bluetooth Adventure';
    els.networkSymbol.textContent = mode === 'wifi' ? '⌁' : mode === 'online' ? '☁' : 'ᛒ';
    els.networkInstructions.textContent = mode === 'wifi'
      ? 'Connect 2–4 devices to the same Wi-Fi network or hotspot.'
      : mode === 'online' ? 'Create a private room or join using a six-character room code.'
      : 'Enable Bluetooth and pair both phones in Android settings first.';
    els.networkAddressLabel.textContent = mode === 'wifi'
      ? 'HOST WI-FI ADDRESS' : mode === 'online' ? 'ROOM CODE' : 'PAIRED HOST DEVICE ADDRESS';
    els.networkAddress.setAttribute('placeholder', mode === 'wifi'
      ? '192.168.1.25' : mode === 'online' ? 'ABC234' : 'AA:BB:CC:DD:EE:FF');
    els.networkRefresh.classList.toggle('visible', mode === 'bluetooth');
    if (els.wifiPlayerPicker) els.wifiPlayerPicker.classList.toggle('visible', mode === 'wifi');
    setWifiPlayerCount(2);
    networkStatus(mode === 'wifi'
      ? 'Choose 2, 3, or 4 explorers, then create or join.'
      : mode === 'online' ? 'Choose 2, 3, or 4 explorers, then create or join online.'
      : 'Choose create or join to connect two paired devices.');
    els.network.classList.add('visible');
    renderSettings();
    if (mode === 'bluetooth') refreshPairedDevices();
    return true;
  }

  function setWifiPlayerCount(count) {
    if (!Number.isInteger(count) || count < 2 || count > 4 ||
        state.network.role) return false;
    state.network.expectedPlayers = count;
    if (els.wifiCountButtons) {
      [2, 3, 4].forEach(function (number) {
        var button = els.wifiCountButtons[number];
        if (!button) return;
        button.classList.toggle('selected', number === count);
        button.setAttribute('aria-pressed', String(number === count));
      });
    }
    return true;
  }

  function hostNetwork() {
    if (state.network.transport === 'online') {
      state.network.role = 'host';
      createOnlineRoom().catch(function (error) { networkStatus(String(error.message || error), true); });
      return true;
    }
    var bridge = nativeTransport();
    if (!bridge) return networkStatus('Install the Android APK on each device to use nearby multiplayer.', true);
    state.network.role = 'host';
    state.network.localPlayer = 0;
    state.network.localName = cleanName(els.networkName.value, 0);
    state.network.revision = 0;
    state.network.peerNames = [];
    state.network.clientIds = ['host'];
    state.network.connectedGuests = 0;
    try {
      if (state.network.transport === 'wifi') {
        var address = bridge.localAddress();
        state.network.hostAddress = address;
        if (typeof bridge.hostWifiPlayers === 'function') {
          bridge.hostWifiPlayers(state.network.expectedPlayers);
        } else if (state.network.expectedPlayers === 2) bridge.hostWifi();
        else return networkStatus('Update the Android game to host more than two Wi-Fi explorers.', true);
        networkStatus('Host Wi-Fi address: ' + address + ' — waiting for ' +
          (state.network.expectedPlayers - 1) + ' guest explorer' +
          (state.network.expectedPlayers === 2 ? '' : 's') + '.');
      } else {
        state.network.expectedPlayers = 2;
        bridge.hostBluetooth();
        networkStatus('Bluetooth game created. Your paired friend can now join.');
      }
      beginPolling();
      return true;
    } catch (error) {
      return networkStatus('Cannot create the game: ' + String(error.message || error), true);
    }
  }

  function joinNetwork() {
    if (state.network.transport === 'online') {
      state.network.role = 'guest';
      joinOnlineRoom().catch(function (error) { networkStatus(String(error.message || error), true); });
      return true;
    }
    var bridge = nativeTransport();
    if (!bridge) return networkStatus('Install the Android APK on each device to use nearby multiplayer.', true);
    var address = String(els.networkAddress.value || '').trim();
    if (!address) return networkStatus('Enter the host device address first.', true);
    if (state.network.transport === 'bluetooth' &&
        !/^(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/.test(address)) {
      return networkStatus('Choose a paired Bluetooth device from the list.', true);
    }
    state.network.role = 'guest';
    state.network.localPlayer = 1;
    state.network.localName = cleanName(els.networkName.value, 1);
    state.network.clientId = Date.now().toString(36) + '-' +
      Math.random().toString(36).slice(2, 12);
    state.network.revision = 0;
    try {
      if (state.network.transport === 'wifi') bridge.joinWifi(address);
      else bridge.joinBluetooth(address);
      networkStatus('Connecting to your friend at ' + address + '…');
      beginPolling();
      return true;
    } catch (error) {
      return networkStatus('Cannot join the game: ' + String(error.message || error), true);
    }
  }

  function disconnectNetwork() {
    if (state.network.timer !== null) {
      clearInterval(state.network.timer);
      state.network.timer = null;
    }
    var bridge = nativeTransport();
    if (state.network.onlineSocket) { try { state.network.onlineSocket.close(); } catch (error) {} }
    state.network.onlineSocket = null;
    stopVoiceCall(false);
    if (bridge && typeof bridge.disconnect === 'function') {
      try { bridge.disconnect(); } catch (error) {}
    }
    state.network.connected = false;
    state.network.role = '';
    state.network.waitingForRoll = false;
    state.network.revision = 0;
    state.network.expectedPlayers = 2;
    state.network.connectedGuests = 0;
    state.network.peerNames = [];
    state.network.clientIds = [];
    state.network.clientId = '';
    state.network.roomCode = '';
    state.network.playerId = '';
    state.network.reconnectToken = '';
    state.playMode = 'hotseat';
    renderSettings();
    renderHud();
    return true;
  }

  function requestRoll() {
    if (isAiPlayer(state.current)) return false;
    if (state.players[state.current] && state.players[state.current].finished) return false;
    if (!state.network.connected) {
      if (state.playMode !== 'hotseat' && state.network.role) return false;
      takeRoll();
      return true;
    }
    if (state.network.transport === 'online') {
      if (state.current !== state.network.localPlayer || state.busy || state.won || !state.started || state.network.waitingForRoll) return false;
      state.network.waitingForRoll = true; renderHud();
      if (!sendNetwork({ type: 'ROLL_REQUEST', revision: state.network.revision })) {
        state.network.waitingForRoll = false; renderHud(); return false;
      }
      return true;
    }
    if (state.current !== state.network.localPlayer || state.busy || state.won ||
        state.network.waitingForRoll || !state.started) return false;
    if (state.network.role === 'host') return authoritativeRoll(state.current);
    state.network.waitingForRoll = true;
    renderHud();
    if (!sendNetwork({ type: 'ROLL_REQUEST', player: state.network.localPlayer,
                       revision: state.network.revision })) {
      state.network.waitingForRoll = false;
      renderHud();
      return false;
    }
    return true;
  }

  function setSoundEnabled(enabled) {
    state.sound = Boolean(enabled);
    renderSettings();
    persistSettings();
    if (state.sound) unlockAudio();
    syncAmbientSound();
    return state.sound;
  }

  function setAmbientSoundEnabled(enabled) {
    state.ambience = Boolean(enabled);
    renderSettings();
    persistSettings();
    syncAmbientSound();
    return state.ambience;
  }

  function syncLivingJungle() {
    if (!els.board) return false;
    var enabled = state.livingJungle && state.animations;
    els.board.setAttribute('data-living-jungle', String(enabled));
    return enabled;
  }

  function setLivingJungleEnabled(enabled) {
    state.livingJungle = Boolean(enabled);
    syncLivingJungle();
    renderSettings();
    persistSettings();
    return state.livingJungle;
  }

  function setAnimationsEnabled(enabled) {
    state.animations = Boolean(enabled);
    syncLivingJungle();
    renderSettings();
    persistSettings();
    return state.animations;
  }

  function setMovementSpeed(speed) {
    if (!Object.prototype.hasOwnProperty.call(SPEED_FACTORS, speed)) {
      throw new RangeError('Movement speed must be slow, normal, or fast.');
    }
    state.movementSpeed = speed;
    renderSettings();
    persistSettings();
    return speed;
  }

  function openSettings() {
    if (state.busy) return false;
    renderSettings();
    els.settings.classList.add('visible');
    return true;
  }

  function closeSettings() {
    els.settings.classList.remove('visible');
    persistSettings();
    return true;
  }

  function openGuide() {
    if (state.busy) return false;
    if (state.tutorial.visible) {
      els.tutorial.classList.remove('visible');
      state.tutorial.visible = false;
      state.tutorial.returnToGuide = false;
    }
    if (els.rulesFrame.getAttribute('src') !== 'rules.html') {
      els.rulesFrame.setAttribute('src', 'rules.html');
    }
    els.guide.classList.add('visible');
    return true;
  }

  function closeGuide() {
    els.guide.classList.remove('visible');
    return true;
  }

  function renderTutorial() {
    var step = TUTORIAL_STEPS[state.tutorial.index];
    if (!step) return false;
    els.tutorialProgress.innerHTML = TUTORIAL_STEPS.map(function (_, index) {
      return '<span class="tutorial-dot' + (index === state.tutorial.index ? ' active' : '') +
        '" aria-hidden="true"></span>';
    }).join('');
    els.tutorialProgress.setAttribute('aria-label', 'Tutorial step ' +
      (state.tutorial.index + 1) + ' of ' + TUTORIAL_STEPS.length);
    if (step.images) {
      els.tutorialArt.innerHTML = step.images.map(function (source) {
        return '<img class="' + (step.images.length > 1 ? 'tutorial-art-pair' : '') +
          '" src="' + escapeHtml(source) + '" alt="">';
      }).join('');
    } else {
      els.tutorialArt.innerHTML = '<span class="tutorial-symbol">' +
        escapeHtml(step.symbol) + '</span>';
    }
    els.tutorialBadge.textContent = step.badge;
    els.tutorialTitle.textContent = step.title;
    els.tutorialDescription.textContent = step.description;
    els.tutorialTip.textContent = step.tip;
    els.tutorialBack.disabled = state.tutorial.index === 0;
    els.tutorialNext.textContent = state.tutorial.index === TUTORIAL_STEPS.length - 1
      ? 'LET’S PLAY' : 'NEXT';
    return true;
  }

  function openTutorial(returnToGuide) {
    if (state.busy) return false;
    state.tutorial.returnToGuide = Boolean(returnToGuide);
    if (state.tutorial.returnToGuide) els.guide.classList.remove('visible');
    state.tutorial.index = 0;
    state.tutorial.visible = true;
    renderTutorial();
    els.tutorial.classList.add('visible');
    return true;
  }

  function closeTutorial() {
    els.tutorial.classList.remove('visible');
    state.tutorial.visible = false;
    var restoreGuide = state.tutorial.returnToGuide;
    state.tutorial.returnToGuide = false;
    if (restoreGuide) els.guide.classList.add('visible');
    return true;
  }

  function advanceTutorial(direction) {
    if (!state.tutorial.visible || direction !== 1 && direction !== -1) return false;
    var next = state.tutorial.index + direction;
    if (next < 0) return false;
    if (next >= TUTORIAL_STEPS.length) return closeTutorial();
    state.tutorial.index = next;
    return renderTutorial();
  }

  function wait(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function movementWait(ms) {
    return wait(Math.max(14, Math.round(ms * SPEED_FACTORS[state.movementSpeed])));
  }

  function unlockAudio() {
    if (!state.sound) return false;
    try {
      var Context = window.AudioContext || window.webkitAudioContext;
      if (!state.audio && Context) state.audio = new Context();
      if (state.audio && state.audio.state === 'suspended' && typeof state.audio.resume === 'function') {
        var resumed = state.audio.resume();
        if (resumed && typeof resumed.catch === 'function') resumed.catch(function () {});
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  function syncAmbientSound() {
    var shouldPlay = state.started && state.sound && state.ambience &&
      document.hidden !== true;
    if (!shouldPlay) {
      if (state.ambientClip && typeof state.ambientClip.pause === 'function') {
        state.ambientClip.pause();
      }
      state.ambientPlaying = false;
      return false;
    }
    if (state.ambientPlaying) return true;
    if (typeof window.Audio !== 'function') return false;
    try {
      if (!state.ambientClip) {
        state.ambientClip = new window.Audio('sounds/jungle_ambience.mp3');
        state.ambientClip.loop = true;
        state.ambientClip.preload = 'auto';
      }
      state.ambientClip.volume = .28;
      var playing = state.ambientClip.play();
      state.ambientPlaying = true;
      if (playing && typeof playing.catch === 'function') {
        playing.catch(function () { state.ambientPlaying = false; });
      }
      return true;
    } catch (error) {
      state.ambientPlaying = false;
      return false;
    }
  }

  function updateJungleParallax(event) {
    if (!state.livingJungle || !state.animations || !els.board ||
        !els.board.style || typeof els.board.style.setProperty !== 'function' ||
        typeof els.board.getBoundingClientRect !== 'function') return false;
    if (typeof window.matchMedia === 'function' &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false;
    var bounds = els.board.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return false;
    var horizontal = (event.clientX - bounds.left) / bounds.width * 2 - 1;
    var vertical = (event.clientY - bounds.top) / bounds.height * 2 - 1;
    els.board.style.setProperty('--jungle-depth-x', (horizontal * 4).toFixed(2) + 'px');
    els.board.style.setProperty('--jungle-depth-y', (vertical * 2.5).toFixed(2) + 'px');
    return true;
  }

  function clearJungleParallax() {
    if (!els.board || !els.board.style ||
        typeof els.board.style.setProperty !== 'function') return false;
    els.board.style.setProperty('--jungle-depth-x', '0px');
    els.board.style.setProperty('--jungle-depth-y', '0px');
    return true;
  }

  function playSound(type) {
    state.lastSound = type;
    state.soundEvents.push(type);
    if (state.soundEvents.length > 40) state.soundEvents.shift();
    if (!state.sound) return;

    // Real, bundled clips include spoken crying, relief, and celebration.
    if (typeof window.Audio === 'function') {
      try {
        if (!state.clips[type]) {
          var extension = type === 'gate_open' || type === 'gate_close' ? '.wav' : '.mp3';
          state.clips[type] = new window.Audio('sounds/' + type + extension);
          state.clips[type].preload = 'auto';
        }
        var clip = typeof state.clips[type].cloneNode === 'function'
          ? state.clips[type].cloneNode(true) : state.clips[type];
        clip.volume = .96;
        var playback = clip.play();
        if (playback && typeof playback.catch === 'function') {
          playback.catch(function () { synthesizeSound(type); });
        }
        return;
      } catch (clipError) {
        // Older browsers still receive the fully offline Web Audio fallback.
      }
    }
    synthesizeSound(type);
  }

  function synthesizeSound(type) {
    try {
      if (!unlockAudio() || !state.audio) return;
      var audio = state.audio;
      var now = audio.currentTime;

      function voice(offset, duration, startFrequency, endFrequency, shape, volume) {
        var start = now + offset;
        var oscillator = audio.createOscillator();
        var gain = audio.createGain();
        oscillator.type = shape || 'sine';
        oscillator.frequency.setValueAtTime(startFrequency, start);
        oscillator.frequency.exponentialRampToValueAtTime(Math.max(35, endFrequency), start + duration);
        gain.gain.setValueAtTime(.0001, start);
        gain.gain.exponentialRampToValueAtTime(volume || .07, start + Math.min(.045, duration / 4));
        gain.gain.exponentialRampToValueAtTime(.0001, start + duration);
        oscillator.connect(gain);
        gain.connect(audio.destination);
        oscillator.start(start);
        oscillator.stop(start + duration + .015);
      }

      function breath(offset, duration, tone, volume) {
        if (typeof audio.createBuffer !== 'function' || typeof audio.createBufferSource !== 'function') {
          voice(offset, duration, tone / 3, tone / 5, 'triangle', volume || .035);
          return;
        }
        var length = Math.max(1, Math.floor(audio.sampleRate * duration));
        var buffer = audio.createBuffer(1, length, audio.sampleRate);
        var channel = buffer.getChannelData(0);
        for (var point = 0; point < channel.length; point++) channel[point] = Math.random() * 2 - 1;
        var source = audio.createBufferSource();
        var filter = audio.createBiquadFilter();
        var gain = audio.createGain();
        var start = now + offset;
        source.buffer = buffer;
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(tone, start);
        filter.Q.value = .8;
        gain.gain.setValueAtTime(.0001, start);
        gain.gain.exponentialRampToValueAtTime(volume || .08, start + Math.min(.06, duration / 3));
        gain.gain.exponentialRampToValueAtTime(.0001, start + duration);
        source.connect(filter);
        filter.connect(gain);
        gain.connect(audio.destination);
        source.start(start);
        source.stop(start + duration + .01);
      }

      if (type === 'lion') {
        voice(0, .45, 142, 55, 'sawtooth', .115);
        voice(.14, .44, 106, 43, 'triangle', .105);
        breath(.03, .46, 340, .16);
      } else if (type === 'wolf') {
        voice(0, .33, 310, 615, 'sine', .1);
        voice(.31, .48, 610, 355, 'sine', .11);
        voice(.06, .7, 460, 330, 'triangle', .035);
      } else if (type === 'fight') {
        for (var hit = 0; hit < 3; hit++) {
          voice(hit * .13, .12, 210 - hit * 22, 62, 'triangle', .1);
          breath(hit * .13, .105, 1180 - hit * 160, .18);
        }
      } else if (type === 'cry') {
        voice(0, .25, 590, 380, 'sine', .085);
        voice(.28, .3, 630, 330, 'sine', .09);
        voice(.62, .33, 505, 245, 'triangle', .07);
      } else if (type === 'relief') {
        breath(.02, .62, 1250, .085);
        voice(.12, .5, 370, 225, 'sine', .075);
        voice(.19, .42, 555, 320, 'sine', .026);
      } else if (type === 'hurray') {
        [392, 523, 659, 784].forEach(function (note, index) {
          voice(index * .095, .24, note, note * 1.035, 'triangle', .078);
        });
        voice(.34, .36, 580, 880, 'sine', .075);
      } else if (type === 'win') {
        [523, 659, 784, 1047, 1319].forEach(function (note, index) {
          voice(index * .115, .3, note, note * 1.015, 'triangle', .083);
        });
      } else if (type === 'good') {
        [659, 784, 988].forEach(function (note, index) {
          voice(index * .085, .17, note, note * 1.02, 'sine', .065);
        });
      } else if (type === 'bad') {
        voice(0, .25, 330, 205, 'triangle', .075);
      } else if (type === 'gate_open') {
        breath(0, .44, 440, .085);
        voice(.08, .49, 172, 318, 'triangle', .082);
        voice(.43, .16, 680, 990, 'sine', .047);
      } else if (type === 'gate_close') {
        breath(0, .34, 370, .08);
        voice(.12, .41, 280, 95, 'triangle', .095);
        voice(.49, .14, 165, 63, 'sine', .074);
      } else if (type === 'knife_pickup') {
        breath(0, .14, 4200, .105);
        voice(.04, .23, 980, 1510, 'sine', .075);
      } else if (type === 'axe_pickup') {
        voice(0, .19, 220, 105, 'triangle', .094);
        voice(.12, .22, 670, 1040, 'sine', .061);
      } else if (type === 'hammer_pickup') {
        voice(0, .25, 155, 75, 'triangle', .11);
        voice(.18, .29, 520, 910, 'sine', .072);
      } else if (type === 'knife_use') {
        breath(0, .29, 3600, .14);
        voice(.08, .23, 1010, 510, 'sine', .062);
      } else if (type === 'axe_use') {
        breath(0, .33, 1180, .13);
        voice(.18, .21, 230, 78, 'triangle', .11);
      } else if (type === 'hammer_hit') {
        breath(0, .14, 780, .155);
        voice(.015, .29, 180, 53, 'triangle', .14);
        voice(.07, .21, 890, 380, 'sine', .061);
      } else if (type === 'lock_break') {
        breath(0, .42, 2450, .16);
        voice(.015, .3, 680, 140, 'triangle', .105);
        [840, 1120, 1480].forEach(function (note, index) {
          voice(.18 + index * .08, .22, note, note * 1.13, 'sine', .049);
        });
      } else {
        voice(0, .105, 425, 335, 'sine', .055);
      }
    } catch (err) {}
  }

  function drawSparkles(stage, color) {
    [[43, 40], [252, 43], [63, 145], [250, 142], [213, 23], [103, 29]].forEach(function (point, index) {
      var size = index % 2 ? 8 : 11;
      svg('path', {
        d: 'M ' + point[0] + ' ' + (point[1] - size) + ' L ' + (point[0] + 3) + ' ' + (point[1] - 3) +
          ' L ' + (point[0] + size) + ' ' + point[1] + ' L ' + (point[0] + 3) + ' ' + (point[1] + 3) +
          ' L ' + point[0] + ' ' + (point[1] + size) + ' L ' + (point[0] - 3) + ' ' + (point[1] + 3) +
          ' L ' + (point[0] - size) + ' ' + point[1] + ' L ' + (point[0] - 3) + ' ' + (point[1] - 3) + ' Z',
        fill: color, class: 'scene-sparkle'
      }, stage);
    });
  }

  function drawKeyScene(stage) {
    drawSparkles(stage, '#e7af3c');
    svg('circle', { cx: 150, cy: 96, r: 66, fill: '#fff2b8', stroke: '#e5b955', 'stroke-width': 2 }, stage);
    var center = svg('g', { transform: 'translate(150,96)' }, stage);
    var turning = svg('g', { class: 'scene-key-spinner' }, center);
    svg('image', { href: artwork('key_glow'), x: -94, y: -74, width: 188, height: 148,
      preserveAspectRatio: 'xMidYMid meet', class: 'scene-approved-key' }, turning);
  }

  function drawUnlockScene(stage) {
    drawSparkles(stage, '#ecc05b');
    svg('image', { href: artwork('gate_unlocking'), x: 37, y: 7, width: 228, height: 174,
      preserveAspectRatio: 'xMidYMid meet', class: 'scene-approved-gate' }, stage);
    // The approved unlocking illustration already includes its own golden key;
    // adding a second key or a legacy drawn shackle makes the scene overlap.
  }

  function drawAnimalScene(stage, kind) {
    svg('ellipse', { cx: 151, cy: 97, rx: 105, ry: 78, fill: kind === 'lion' ? '#fbe1a4' : '#dcebf1',
      opacity: '.67' }, stage);
    var animal = svg('g', { transform: 'translate(148,96)' }, stage);
    var face = svg('g', { class: 'scene-lion-face' }, animal);
    var mane = svg('g', { class: kind === 'lion' ? 'scene-lion-mane' : 'scene-wolf-fur' }, face);
    svg('image', { href: artwork(kind === 'lion' ? 'lion_roar' : 'wolf_howl'),
      x: -89, y: -87, width: 180, height: 176, preserveAspectRatio: 'xMidYMid meet',
      class: 'scene-approved-animal' }, mane);
    var jaw = svg('g', { class: 'scene-animal-jaw' }, face);
    svg('ellipse', { cx: 0, cy: 35, rx: 12, ry: 7, fill: '#d88075', opacity: '.24' }, jaw);
    svg('path', { d: 'M 221 75 Q 243 96 221 116', fill: 'none', stroke: '#bb7040', 'stroke-width': 5,
      'stroke-linecap': 'round', class: 'scene-roar-wave' }, stage);
    svg('path', { d: 'M 235 63 Q 270 96 235 130', fill: 'none', stroke: '#d59251', 'stroke-width': 4,
      'stroke-linecap': 'round', class: 'scene-roar-wave second' }, stage);
  }

  function drawEncounterOutcome(stage, player, animal, loser) {
    var animalLost = loser === 'animal';
    svg('ellipse', { cx: 151, cy: 109, rx: 120, ry: 69,
      fill: animalLost ? '#e1efd3' : '#f1ddcf', opacity: '.79' }, stage);
    svg('ellipse', { cx: 142, cy: 157, rx: 118, ry: 13,
      fill: '#42623e', opacity: '.24' }, stage);
    var animalGroup = svg('g', {
      class: animalLost ? 'scene-outcome-animal scene-animal-fall' :
        'scene-outcome-animal scene-animal-victor'
    }, stage);
    svg('image', { href: artwork(animal + '_' + (animalLost ? 'sleep' :
      animal === 'lion' ? 'roar' : 'howl')), x: 148, y: animalLost ? 45 : 21,
      width: 139, height: 143, preserveAspectRatio: 'xMidYMax meet',
      class: 'scene-approved-outcome-animal' }, animalGroup);
    var explorerGroup = svg('g', {
      class: animalLost ? 'scene-outcome-explorer scene-explorer-victor' :
        'scene-outcome-explorer scene-explorer-fall'
    }, stage);
    drawAvatar(explorerGroup, player, 13, -5, 151, 180,
      animalLost ? 'victory' : 'cry',
      'scene-explorer-avatar scene-avatar-' + (animalLost ? 'recovery' : 'cry'));
    if (animalLost) drawSparkles(stage, '#d2ad55');
  }

  function drawToolScene(stage, kind, player) {
    var pickup = kind.indexOf('pickup_') === 0;
    var weapon = kind.replace('pickup_', '').replace('defend_', '');
    var pose = pickup ? 'pickup' : weapon === 'knife' ? 'knife' : 'tool';
    svg('ellipse', { cx: 150, cy: 98, rx: 107, ry: 79,
      fill: weapon === 'hammer' ? '#f5e1a2' : '#dcebcf', opacity: '.72' }, stage);
    drawSparkles(stage, weapon === 'hammer' ? '#dfac40' : '#92ad6d');
    drawAvatar(stage, player, 45, -6, 162, 189, pose,
      'scene-explorer-avatar scene-avatar-' + pose);
    var object = drawIcon(stage, weapon, pickup ? 204 : 217,
      pickup ? 143 : weapon === 'hammer' ? 48 : 96, '#795e51');
    object.setAttribute('class', 'scene-tool scene-tool-' + weapon +
      (pickup ? ' scene-tool-pickup' : ' scene-tool-swing'));
  }

  function drawHammerBreakScene(stage, player, broken) {
    svg('ellipse', { cx: 170, cy: 158, rx: 121, ry: 17,
      fill: '#315b38', opacity: '.24' }, stage);
    svg('image', { href: artwork(broken ? 'gate_broken' : 'gate_closed'),
      x: 92, y: 24, width: 194, height: 144, preserveAspectRatio: 'xMidYMid meet',
      class: broken ? 'scene-broken-gate' : 'scene-hammer-gate' }, stage);
    drawAvatar(stage, player, -4, 3, 142, 177, broken ? 'victory' : 'tool',
      'scene-explorer-avatar scene-hammer-explorer');
    if (!broken) {
      var hammer = drawIcon(stage, 'hammer', 130, 58, '#94722d');
      hammer.setAttribute('class', 'scene-hammer-strike');
    } else {
      [[160, 101], [176, 112], [185, 92], [152, 120]].forEach(function (point, index) {
        svg('path', { d: 'M ' + point[0] + ' ' + point[1] + ' l 4 -7 l 4 7 l -4 5 z',
          fill: index % 2 ? '#f9d47a' : '#cc9234',
          class: 'scene-lock-fragment fragment-' + index }, stage);
      });
    }
  }

  function drawRecoveryScene(stage, player) {
    svg('ellipse', { cx: 148, cy: 98, rx: 102, ry: 77,
      fill: '#e6f0d2', opacity: '.82' }, stage);
    drawSparkles(stage, '#83af72');
    drawAvatar(stage, player, 65, -6, 173, 190, 'recovery',
      'scene-explorer-avatar scene-avatar-recovery');
  }

  function drawCryingChild(stage, player) {
    svg('ellipse', { cx: 150, cy: 99, rx: 103, ry: 79,
      fill: '#e5edf8', opacity: '.81' }, stage);
    var child = svg('g', { class: 'scene-cry-child' }, stage);
    drawAvatar(child, player, 63, -6, 176, 191, 'cry',
      'scene-explorer-avatar scene-avatar-cry');
    svg('path', { d: 'M 137 81 Q 131 90 137 94 Q 143 90 137 81 Z', fill: '#68b9ec',
      class: 'scene-cry-tear' }, child);
    svg('path', { d: 'M 166 79 Q 160 88 166 92 Q 172 88 166 79 Z', fill: '#68b9ec',
      class: 'scene-cry-tear second' }, child);
  }

  async function showVisual(kind, position, caption, duration, sound) {
    var titles = { key: 'A GOLDEN KEY!', unlock: 'TURN THE KEY', lion: 'THE LION AWAKENS!',
      wolf: 'A WOLF APPEARS!', cry: 'OH NO... BOO HOO!', recovery: 'FEELING BETTER!',
      pickup_knife: 'A SHARP EXPLORER KNIFE!', pickup_axe: 'A BRAVE JUNGLE AXE!',
      pickup_hammer: 'THE GOLDEN LOCK HAMMER!', defend_knife: 'KNIFE TO THE RESCUE!',
      defend_axe: 'SWING THE JUNGLE AXE!', hammer_use: 'BREAK THE FINAL LOCK!',
      lock_break: 'THE PADLOCK IS BROKEN!', animal_falls: 'THE ANIMAL FALLS!',
      explorer_falls: 'THE EXPLORER FALLS!' };
    state.visualEvents.push({ kind: kind, space: position, player: state.current });
    if (state.visualEvents.length > 60) state.visualEvents.shift();
    if (!state.animations) {
      els.message.textContent = caption;
      if (sound) playSound(sound);
      await wait(55);
      return;
    }
    els.sceneTitle.textContent = titles[kind] || 'ADVENTURE!';
    els.sceneCaption.textContent = caption;
    els.sceneStage.textContent = '';
    els.sceneStage.setAttribute('data-scene', kind);
    els.sceneStage.setAttribute('aria-label', titles[kind] || 'Animated adventure event');
    if (kind === 'key') drawKeyScene(els.sceneStage);
    else if (kind === 'unlock') drawUnlockScene(els.sceneStage);
    else if (kind === 'lion' || kind === 'wolf') drawAnimalScene(els.sceneStage, kind);
    else if (kind === 'animal_falls' || kind === 'explorer_falls') {
      drawEncounterOutcome(els.sceneStage, state.players[state.current],
        position === 17 ? 'lion' : 'wolf', kind === 'animal_falls' ? 'animal' : 'explorer');
    }
    else if (kind === 'cry') drawCryingChild(els.sceneStage, state.players[state.current]);
    else if (kind === 'recovery') drawRecoveryScene(els.sceneStage, state.players[state.current]);
    else if (kind === 'hammer_use' || kind === 'lock_break') {
      drawHammerBreakScene(els.sceneStage, state.players[state.current], kind === 'lock_break');
    } else if (kind.indexOf('pickup_') === 0 || kind.indexOf('defend_') === 0) {
      drawToolScene(els.sceneStage, kind, state.players[state.current]);
    }
    els.scene.className = 'scene-overlay visible scene-' + kind;
    els.scene.setAttribute('aria-hidden', 'false');
    els.message.textContent = caption;
    if (sound) playSound(sound);
    await wait(duration || 1250);
    els.scene.className = 'scene-overlay';
    els.scene.setAttribute('aria-hidden', 'true');
    await wait(110);
  }

  async function celebrateKey(position, caption) {
    var tile = document.getElementById('tile-' + position);
    var icon = document.getElementById('space-icon-' + position);
    var image = els.boardArtwork[position];
    tile.classList.add('board-key-active');
    icon.classList.add('board-key-spin');
    if (image) image.setAttribute('href', artwork('key_glow'));
    await showVisual('key', position, caption, 1400, 'good');
    if (image) image.setAttribute('href', artwork('key_normal'));
    tile.classList.remove('board-key-active');
    icon.classList.remove('board-key-spin');
  }

  async function animateUnlock(position) {
    var tile = document.getElementById('tile-' + position);
    var shackle = document.getElementById('lock-shackle-' + position);
    var closed = shackle.getAttribute('d');
    tile.classList.add('board-lock-active');
    setGateFrame(position, 'unlocking');
    shackle.setAttribute('d', 'M -10 -2 L -10 -13 C -10 -25 7 -26 12 -17');
    await showVisual('unlock', position, 'The golden key turns clockwise and the lock opens!', 1550, 'good');
    await animateGatePassage(position);
    tile.classList.remove('board-lock-active');
    if (position !== 35) shackle.setAttribute('d', closed);
  }

  function setGateFrame(position, frame) {
    state.gateFrames[position] = frame;
    state.gateEvents.push({ space: position, frame: frame });
    if (state.gateEvents.length > 60) state.gateEvents.shift();
    var image = els.boardArtwork && els.boardArtwork[position];
    if (image) {
      var source = frame === 'open' || frame === 'passing' ? 'gate_open'
        : frame === 'half_closing' || frame === 'opening' ? 'gate_half_closing'
          : frame === 'unlocking' ? 'gate_unlocking'
            : frame === 'broken' ? 'gate_broken' : 'gate_closed';
      image.setAttribute('href', artwork(source));
    }
  }

  function drawGateFrame(stage, frame, passing) {
    stage.textContent = '';
    var source = frame === 'open' || frame === 'passing' ? 'gate_open'
      : frame === 'half_closing' || frame === 'opening' ? 'gate_half_closing'
        : frame === 'unlocking' ? 'gate_unlocking' : 'gate_closed';
    svg('ellipse', { cx: 150, cy: 163, rx: 104, ry: 17, fill: '#315b38', opacity: '.22' }, stage);
    svg('image', { href: artwork(source), x: 25, y: 1, width: 250, height: 181,
      preserveAspectRatio: 'xMidYMid meet', class: 'scene-gate-frame scene-gate-' + frame }, stage);
    if (passing) {
      var child = svg('g', { transform: 'translate(154,129)', class: 'scene-gate-child' }, stage);
      drawAvatar(child, state.players[state.current], -20, -43, 40, 62, 'walkA',
        'scene-gate-avatar');
    }
  }

  async function animateGatePassage(position) {
    if (!state.animations) {
      setGateFrame(position, 'opening');
      playSound('gate_open');
      setGateFrame(position, 'open');
      setGateFrame(position, 'passing');
      setGateFrame(position, 'half_closing');
      playSound('gate_close');
      setGateFrame(position, 'closed');
      return;
    }
    els.sceneTitle.textContent = position === 35 ? 'THE WAY HOME IS OPEN!' : 'THROUGH THE JUNGLE GATE';
    els.scene.className = 'scene-overlay visible scene-unlock scene-gate-passage';
    els.scene.setAttribute('aria-hidden', 'false');
    els.sceneStage.setAttribute('data-scene', 'gate');
    setGateFrame(position, 'opening');
    drawGateFrame(els.sceneStage, 'opening', false);
    els.sceneCaption.textContent = 'The heavy wooden doors swing open...';
    playSound('gate_open');
    await wait(430);
    setGateFrame(position, 'open');
    drawGateFrame(els.sceneStage, 'open', false);
    await wait(390);
    setGateFrame(position, 'passing');
    drawGateFrame(els.sceneStage, 'passing', true);
    els.sceneCaption.textContent = 'Your explorer passes safely through the open gate.';
    await wait(520);
    setGateFrame(position, 'half_closing');
    drawGateFrame(els.sceneStage, 'half_closing', false);
    els.sceneCaption.textContent = 'The gate closes behind you.';
    playSound('gate_close');
    await wait(470);
    setGateFrame(position, 'closed');
    drawGateFrame(els.sceneStage, 'closed', false);
    await wait(250);
    els.scene.className = 'scene-overlay';
    els.scene.setAttribute('aria-hidden', 'true');
  }

  async function showAnimal(position, kind) {
    var icon = document.getElementById('space-icon-' + position);
    var image = els.boardArtwork[position];
    icon.classList.add('board-animal-active');
    setAnimalFrame(position, 'walk');
    await wait(165);
    setAnimalFrame(position, kind === 'lion' ? 'roar' : 'howl');
    await showVisual(kind, position,
      kind === 'lion' ? 'The lion wakes up and ROARS!' : 'The hungry wolf howls and lunges!',
      kind === 'lion' ? 1450 : 1650, kind);
    if (image) setAnimalFrame(position, 'idle');
    icon.classList.remove('board-animal-active');
  }

  function setAnimalFrame(position, frame) {
    var kind = position === 17 ? 'lion' : 'wolf';
    state.animalFrames[position] = frame;
    state.animalEvents.push({ space: position, animal: kind, frame: frame });
    if (state.animalEvents.length > 80) state.animalEvents.shift();
    var image = els.boardArtwork && els.boardArtwork[position];
    if (image) image.setAttribute('href', artwork(kind + '_' + frame));
  }

  async function collectTool(player, kind, position) {
    player.avatarPose = 'pickup';
    renderHud();
    var tile = document.getElementById('tile-' + position);
    var icon = document.getElementById('space-icon-' + position);
    if (tile) tile.classList.add('board-tool-active');
    if (icon) icon.classList.add('board-tool-pickup');
    await showVisual('pickup_' + kind, position,
      player.name + ' picks up the ' + kind + ' and adds it to their adventure gear!',
      kind === 'hammer' ? 1350 : 1080, kind + '_pickup');
    player[kind] = true;
    delete player.avatarPose;
    if (tile) tile.classList.remove('board-tool-active');
    if (icon) icon.classList.remove('board-tool-pickup');
    renderHud();
    await announce('You collected ' + (kind === 'axe' ? 'an ' : 'a ') + kind + '!', '', 480);
  }

  async function animateHammerBreak(player, position) {
    if (position !== 35 || !player.hammer) return false;
    var tile = document.getElementById('tile-' + position);
    player.avatarPose = 'tool';
    renderHud();
    if (tile) tile.classList.add('board-lock-active');
    await showVisual('hammer_use', position,
      player.name + ' raises the hammer with both hands and strikes the final padlock!',
      1050, 'hammer_hit');
    playSound('hammer_hit');
    await wait(210);
    setGateFrame(position, 'broken');
    await showVisual('lock_break', position,
      'The golden padlock breaks! The jungle gate can now open.', 960, 'lock_break');
    player.finishMethod = 'hammer';
    delete player.avatarPose;
    await animateGatePassage(position);
    if (tile) tile.classList.remove('board-lock-active');
    return true;
  }

  async function cryingFallback(player, routeName, message) {
    player.expression = 'cry';
    renderHud();
    await showVisual('cry', player.position, message, 1380, 'cry');
    await travelRoute(player, routeName);
    delete player.expression;
    renderHud();
  }

  async function announce(message, kind, duration, effect) {
    els.message.textContent = message;
    els.banner.textContent = message;
    els.banner.className = 'event-banner visible ' + (kind || '');
    if (effect || kind) playSound(effect || kind);
    await wait(duration || 780);
    els.banner.className = 'event-banner';
    await wait(100);
  }

  async function moveOne(player, destination) {
    if (!state.animations) {
      player.position = destination;
      renderHud();
      await movementWait(60);
      return;
    }
    var start = tokenPoint(state.current, player.position);
    var finish = tokenPoint(state.current, destination);
    var dryJungleTurn = player.position === 21 && destination === 22;
    for (var frame = 1; frame <= 8; frame++) {
      var progress = frame / 8;
      var smooth = progress * progress * (3 - 2 * progress);
      player.animatedPoint = {
        x: start.x + (finish.x - start.x) * smooth +
          (dryJungleTurn ? Math.sin(progress * Math.PI) * 50 : 0),
        y: start.y + (finish.y - start.y) * smooth - Math.sin(progress * Math.PI) * 8
      };
      state.motionFrames++;
      drawTokens();
      await movementWait(43);
    }
    delete player.animatedPoint;
    player.position = destination;
    renderHud();
    await movementWait(78);
  }

  async function travelRoute(player, routeName) {
    var route = ROUTES[routeName];
    if (!state.animations) {
      player.position = route.to;
      renderHud();
      await movementWait(95);
      return;
    }
    var pathNode = document.getElementById('route-' + routeName);
    var length = pathNode.getTotalLength();
    var frameCount = route.dashed ? 25 : 21;
    for (var step = 0; step <= frameCount; step++) {
      var progress = step / frameCount;
      var point = pathNode.getPointAtLength(length * progress);
      player.animatedPoint = {
        x: point.x,
        y: point.y - 4 - Math.sin(progress * Math.PI * (route.dashed ? 5 : 3)) * 4
      };
      state.motionFrames++;
      drawTokens();
      await movementWait(route.dashed ? 37 : 33);
    }
    delete player.animatedPoint;
    player.position = route.to;
    renderHud();
  }

  async function encounterAnimal(player, position) {
    var lion = position === 17;
    var animal = lion ? 'lion' : 'wolf';
    await showAnimal(position, animal);
    playSound('fight');
    await wait(680);
    if (player.knife || (lion && player.axe)) {
      var weapon = player.knife ? 'knife' : 'axe';
      player.avatarPose = weapon === 'knife' ? 'knife' : 'tool';
      renderHud();
      await showVisual('defend_' + weapon, position,
        player.name + ' uses ' + (weapon === 'axe' ? 'both hands to swing the axe' :
          'one hand to defend with the knife') + '. The ' + animal + ' retreats safely!',
        1020, weapon + '_use');
      setAnimalFrame(position, 'sleep');
      await animateEncounterDefeat(player, position, 'animal');
      setAnimalFrame(position, 'idle');
      delete player.avatarPose;
      renderHud();
      await announce(lion
        ? 'Your ' + weapon + ' protects you. The lion retreats!'
        : 'Your knife protects you. The wolf retreats!',
      'good', 1250, 'hurray');
      return true;
    }
    await animateEncounterDefeat(player, position, 'explorer');
    await cryingFallback(player, animal, lion
      ? 'No knife or axe! The lion attacked. Return to medical point 10.'
      : 'No knife! The wolf attacked. Return to hospital 24.');
    await showVisual('recovery', player.position, lion
      ? 'Safe at medical point 10. Ahh... feeling better.'
      : 'Safe at hospital 24. Ahh... feeling better.',
    1050, 'relief');
    return false;
  }

  async function animateEncounterDefeat(player, position, loser) {
    var animal = position === 17 ? 'lion' : 'wolf';
    var icon = document.getElementById('space-icon-' + position);
    state.defeatEvents.push({ space: position, animal: animal, loser: loser,
      winner: loser === 'animal' ? 'explorer' : animal, player: state.current });
    if (state.defeatEvents.length > 80) state.defeatEvents.shift();
    if (loser === 'animal') {
      if (icon) icon.classList.add('board-animal-fall');
      await showVisual('animal_falls', position,
        player.name + ' wins the encounter! The ' + animal + ' topples over peacefully.', 920);
      if (icon) icon.classList.remove('board-animal-fall');
      return;
    }
    player.expression = 'fallen';
    if (icon) icon.classList.add('board-animal-victor');
    renderHud();
    await showVisual('explorer_falls', position,
      'The ' + animal + ' wins the encounter! ' + player.name + ' falls down.', 950);
    delete player.expression;
    if (icon) icon.classList.remove('board-animal-victor');
    renderHud();
  }

  async function processLanding(player) {
    var position = player.position;
    if (position === 2) {
      await celebrateKey(position, 'You found the first golden key!');
      player.firstKey = true;
      renderHud();
      await announce('You found the first key!', '', 500);
    } else if (position === 3) {
      await announce('Hurray! Cross the jungle bridge straight to space 11.', 'good', 840, 'hurray');
      await travelRoute(player, 'bypass');
    } else if (position === 10) {
      await announce('Ahh... the medical station helps you feel better.', 'good', 760, 'relief');
    } else if (position === 12) {
      await announce('Hurray! The elevated jungle bridge leads directly to 18.', 'good', 880, 'hurray');
      await travelRoute(player, 'shortcut');
    } else if (position === 13 || position === 26) {
      await collectTool(player, 'knife', position);
    } else if (position === 15) {
      await collectTool(player, 'axe', position);
    } else if (position === 17) {
      await encounterAnimal(player, position);
    } else if (position === 24) {
      await announce('Ahh... the hospital helps you recover.', 'good', 760, 'relief');
    } else if (position === 25) {
      await announce('Hurray! The river bridge safely bypasses the wolf.', 'good', 900, 'hurray');
      await travelRoute(player, 'river');
    } else if (position === 27) {
      await encounterAnimal(player, position);
    } else if (position === 31) {
      await celebrateKey(position, 'The final golden key will unlock HOME!');
      player.finalKey = true;
      renderHud();
      await announce('You found the final key to HOME!', '', 550);
    } else if (position === 33) {
      await collectTool(player, 'hammer', position);
    } else if (position === 35) {
      if (player.finalKey) {
        await animateUnlock(position);
        await announce('The final door is unlocked!', 'win', 780);
        win(player);
      } else if (player.hammer) {
        await animateHammerBreak(player, position);
        await announce('The final lock is broken! Your way HOME is open!', 'win', 780);
        win(player);
      } else {
        await cryingFallback(player, 'final', 'The final door is locked! Return to space 30.');
        await announce('Collect the final key on 31 or the hammer on 33.', '', 700);
      }
    }
  }

  async function takeRoll(forcedValue) {
    if (state.busy || state.won || !state.started ||
        state.players[state.current].finished) return;
    var player = state.players[state.current];
    var value = forcedValue === undefined || forcedValue === null ? nextDie(player) : forcedValue;
    if (!Number.isInteger(value) || value < 1 || value > 6) {
      throw new RangeError('A six-sided die must roll an integer from 1 to 6.');
    }
    state.busy = true;
    renderHud();
    els.die.classList.add('rolling');
    var visibleFace = Number(els.die.getAttribute('data-value')) || 1;
    for (var i = 0; i < 9; i++) {
      // Cosmetic frames must not consume or influence anyone's real dice bag.
      visibleFace = visibleFace % 6 + 1;
      setDieFace(visibleFace);
      await wait(36 + i * 8);
    }
    els.die.classList.remove('rolling');
    setDieFace(value);
    state.lastRoll = value;
    player.rolls++;
    state.turns++;
    els.message.textContent = player.name + ' rolled ' + value + '.';
    playSound('step');

    if (player.position + value > 35) {
      await announce('You need an exact roll to reach the final gate.', 'bad', 720);
    } else {
      var destination = player.position + value;
      var stoppedAtObstacle = false;
      var handledLanding = false;
      for (var space = player.position + 1; space <= destination; space++) {
        await moveOne(player, space);
        if (space === 6) {
          if (!player.firstKey) {
            await cryingFallback(player, 'lock', 'The first gate is locked! Return to space 1.');
            stoppedAtObstacle = true;
            break;
          }
          await animateUnlock(space);
        }
        if (space === 17 || space === 27) {
          var survived = await encounterAnimal(player, space);
          if (!survived) {
            stoppedAtObstacle = true;
            break;
          }
          if (space === destination) handledLanding = true;
        }
      }
      if (!stoppedAtObstacle && !handledLanding) await processLanding(player);
    }

    if (!state.won) {
      state.busy = false;
      if (state.players.length > 1) {
        do {
          state.current = (state.current + 1) % state.players.length;
        } while (state.players[state.current].finished);
        var nextPlayer = state.players[state.current];
        els.hint.textContent = nextPlayer.name + ': tap the dice to roll.';
        els.message.textContent = (state.lastFinishNotice ||
          player.name + ' rolled ' + value + '.') + ' ' + nextPlayer.name + ', your turn!';
        state.lastFinishNotice = '';
        renderHud();
        scheduleAiTurn();
      } else {
        els.hint.textContent = player.name + ': tap the dice to roll again.';
        renderHud();
      }
    }
  }

  function win(player) {
    if (!player || player.finished) return false;
    player.finished = true;
    player.rank = state.rankings.length + 1;
    state.rankings.push(state.players.indexOf(player));
    state.finishEvents.push({ player: state.players.indexOf(player),
      rank: player.rank, automatic: false, method: player.finishMethod || 'key' });
    playSound('win');
    var remaining = state.players.filter(function (item) { return !item.finished; });
    if (remaining.length > 1) {
      state.lastFinishNotice = player.name + ' reached HOME in ' + rankLabel(player.rank) +
        ' place! ' + remaining.length + ' explorers are still racing.';
      els.message.textContent = state.lastFinishNotice;
      renderRankings();
      renderHud();
      return false;
    }
    if (remaining.length === 1) {
      var last = remaining[0];
      last.finished = true;
      last.lastPlace = true;
      last.rank = state.rankings.length + 1;
      state.rankings.push(state.players.indexOf(last));
      state.finishEvents.push({ player: state.players.indexOf(last),
        rank: last.rank, automatic: true, method: 'last_place' });
    }
    state.won = true;
    state.busy = false;
    var champion = state.players[state.rankings[0]];
    els.winner.textContent = champion.name + (champion.finishMethod === 'hammer'
      ? ' smashed the final lock and reached HOME!' : ' unlocked the door and reached HOME!');
    els.stats.textContent = state.players.length > 1
      ? 'Final rankings · ' + state.turns + ' total turns · ' +
        (state.players.length - 1) + ' explorer' + (state.players.length > 2 ? 's' : '') + ' reached HOME'
      : 'Victory in ' + player.rolls + ' rolls · ' + state.turns + ' total turns';
    renderRankings();
    els.victory.classList.add('visible');
    renderHud();
    return true;
  }

  function openRename(index) {
    if (index < 0 || index >= state.players.length || state.busy ||
        (state.network.connected && index !== state.network.localPlayer)) return;
    state.renameIndex = index;
    els.renameInput.value = state.players[index].name;
    els.renameLabel.textContent = 'Choose a new name for explorer ' + (index + 1) + '.';
    els.rename.classList.add('visible');
    setTimeout(function () {
      if (els.renameInput.focus) els.renameInput.focus();
      if (els.renameInput.select) els.renameInput.select();
    }, 40);
  }

  function closeRename() {
    state.renameIndex = -1;
    els.rename.classList.remove('visible');
  }

  function saveRename() {
    if (state.renameIndex < 0) return;
    var index = state.renameIndex;
    var name = setPlayerName(index, els.renameInput.value);
    if (state.network.connected) sendNetwork({ type: 'NAME', player: index, name: name });
    closeRename();
    els.message.textContent = name + ' is ready for the adventure.';
  }

  function bind() {
    els.board = document.getElementById('board');
    els.active = document.getElementById('active-player');
    els.position = document.getElementById('position-line');
    els.inventory = document.getElementById('inventory');
    els.roll = document.getElementById('roll-btn');
    els.die = document.getElementById('die-face');
    els.hint = document.getElementById('turn-hint');
    els.playersList = document.getElementById('players-list');
    els.message = document.getElementById('top-message');
    els.banner = document.getElementById('event-banner');
    els.setup = document.getElementById('setup-overlay');
    els.victory = document.getElementById('victory-overlay');
    els.winner = document.getElementById('winner-line');
    els.stats = document.getElementById('victory-stats');
    els.rankings = document.getElementById('victory-rankings');
    els.preview = document.getElementById('player-preview');
    els.rename = document.getElementById('rename-overlay');
    els.renameInput = document.getElementById('rename-input');
    els.renameLabel = document.getElementById('rename-label');
    els.scene = document.getElementById('scene-overlay');
    els.sceneTitle = document.getElementById('scene-title');
    els.sceneStage = document.getElementById('scene-stage');
    els.sceneCaption = document.getElementById('scene-caption');
    els.settings = document.getElementById('settings-overlay');
    els.settingsSound = document.getElementById('settings-sound-btn');
    els.settingsAmbience = document.getElementById('settings-ambience-btn');
    els.settingsJungle = document.getElementById('settings-jungle-btn');
    els.settingsAnimation = document.getElementById('settings-animation-btn');
    els.guide = document.getElementById('guide-overlay');
    els.rulesFrame = document.getElementById('rules-frame');
    els.tutorial = document.getElementById('tutorial-overlay');
    els.tutorialProgress = document.getElementById('tutorial-progress');
    els.tutorialArt = document.getElementById('tutorial-art');
    els.tutorialBadge = document.getElementById('tutorial-badge');
    els.tutorialTitle = document.getElementById('tutorial-title');
    els.tutorialDescription = document.getElementById('tutorial-description');
    els.tutorialTip = document.getElementById('tutorial-tip');
    els.tutorialBack = document.getElementById('tutorial-back-btn');
    els.tutorialNext = document.getElementById('tutorial-next-btn');
    els.network = document.getElementById('network-overlay');
    els.networkTitle = document.getElementById('network-title');
    els.networkSymbol = document.getElementById('network-symbol');
    els.networkInstructions = document.getElementById('network-instructions');
    els.networkName = document.getElementById('network-name');
    els.networkAddress = document.getElementById('network-address');
    els.networkAddressLabel = document.getElementById('network-address-label');
    els.networkDevices = document.getElementById('network-devices');
    els.networkRefresh = document.getElementById('network-refresh-btn');
    els.networkStatus = document.getElementById('network-status');
    els.wifiPlayerPicker = document.getElementById('wifi-player-picker');
    els.wifiCountButtons = {
      2: document.getElementById('wifi-count-2'),
      3: document.getElementById('wifi-count-3'),
      4: document.getElementById('wifi-count-4')
    };
    els.soundButton = document.getElementById('sound-btn');
    els.modeButtons = {
      hotseat: document.getElementById('mode-hotseat-btn'),
      ai: document.getElementById('mode-ai-btn'),
      wifi: document.getElementById('mode-wifi-btn'),
      bluetooth: document.getElementById('mode-bluetooth-btn'),
      online: document.getElementById('mode-online-btn')
    };
    els.speedButtons = {
      slow: document.getElementById('speed-slow-btn'),
      normal: document.getElementById('speed-normal-btn'),
      fast: document.getElementById('speed-fast-btn')
    };
    loadSettings();

    Array.prototype.forEach.call(document.querySelectorAll('.count-choice'), function (button) {
      button.addEventListener('click', function () {
        state.selectedCount = Number(button.getAttribute('data-count'));
        Array.prototype.forEach.call(document.querySelectorAll('.count-choice'), function (item) {
          item.classList.toggle('selected', item === button);
        });
        previewPlayers();
      });
    });
    els.preview.addEventListener('input', function (event) {
      var indexValue = event.target.getAttribute('data-player-index');
      if (indexValue !== null) state.customNames[Number(indexValue)] = event.target.value;
    });
    document.getElementById('start-btn').addEventListener('click', function () {
      unlockAudio();
      beginGame(state.selectedCount);
    });
    els.roll.addEventListener('click', function () {
      unlockAudio();
      syncAmbientSound();
      requestRoll();
    });
    els.active.addEventListener('click', function () { openRename(state.current); });
    els.playersList.addEventListener('click', function (event) {
      var indexValue = event.target.getAttribute('data-player-index');
      if (indexValue !== null) openRename(Number(indexValue));
    });
    document.getElementById('rename-save-btn').addEventListener('click', saveRename);
    document.getElementById('rename-cancel-btn').addEventListener('click', closeRename);
    els.renameInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') saveRename();
      if (event.key === 'Escape') closeRename();
    });
    document.getElementById('restart-btn').addEventListener('click', function () {
      if (state.network.connected || state.network.role) disconnectNetwork();
      state.started = false;
      state.busy = false;
      syncAmbientSound();
      els.setup.classList.add('visible');
      els.victory.classList.remove('visible');
      previewPlayers();
      renderHud();
    });
    els.soundButton.addEventListener('click', function () {
      if (setSoundEnabled(!state.sound)) playSound('good');
    });
    document.getElementById('settings-btn').addEventListener('click', openSettings);
    document.getElementById('setup-settings-btn').addEventListener('click', openSettings);
    document.getElementById('settings-close-btn').addEventListener('click', closeSettings);
    document.getElementById('help-btn').addEventListener('click', openGuide);
    document.getElementById('field-guide-btn').addEventListener('click', openGuide);
    document.getElementById('setup-guide-btn').addEventListener('click', openGuide);
    document.getElementById('settings-guide-btn').addEventListener('click', openGuide);
    document.getElementById('guide-dismiss-btn').addEventListener('click', closeGuide);
    document.getElementById('guide-close-btn').addEventListener('click', closeGuide);
    document.getElementById('guide-tutorial-btn').addEventListener('click', function () {
      openTutorial(true);
    });
    document.getElementById('setup-tutorial-btn').addEventListener('click', function () {
      openTutorial(false);
    });
    document.getElementById('tutorial-close-btn').addEventListener('click', closeTutorial);
    document.getElementById('tutorial-rules-btn').addEventListener('click', openGuide);
    els.tutorialBack.addEventListener('click', function () { advanceTutorial(-1); });
    els.tutorialNext.addEventListener('click', function () { advanceTutorial(1); });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        if (state.tutorial.visible) closeTutorial();
        else if (els.guide.classList.contains('visible')) closeGuide();
      } else if (state.tutorial.visible && event.key === 'ArrowRight') advanceTutorial(1);
      else if (state.tutorial.visible && event.key === 'ArrowLeft') advanceTutorial(-1);
    });
    document.getElementById('mode-hotseat-btn').addEventListener('click', function () {
      disconnectNetwork();
      els.message.textContent = 'Pass-and-play is ready on this device.';
    });
    if (els.modeButtons.ai) els.modeButtons.ai.addEventListener('click', function () {
      disconnectNetwork();
      state.playMode = 'ai';
      state.selectedCount = Math.max(2, state.selectedCount);
      state.customNames[1] = state.customNames[1] || 'Jungle AI';
      previewPlayers();
      renderSettings();
      els.message.textContent = 'Play vs AI is ready. You control Explorer 1.';
    });
    els.modeButtons.wifi.addEventListener('click', function () { openNetwork('wifi'); });
    els.modeButtons.bluetooth.addEventListener('click', function () { openNetwork('bluetooth'); });
    if (els.modeButtons.online) els.modeButtons.online.addEventListener('click', function () { openNetwork('online'); });
    var voiceButton = document.getElementById('voice-btn');
    if (voiceButton) voiceButton.addEventListener('click', toggleVoiceCall);
    [2, 3, 4].forEach(function (count) {
      var button = els.wifiCountButtons[count];
      if (button) button.addEventListener('click', function () { setWifiPlayerCount(count); });
    });
    document.getElementById('network-host-btn').addEventListener('click', hostNetwork);
    document.getElementById('network-join-btn').addEventListener('click', joinNetwork);
    els.networkRefresh.addEventListener('click', refreshPairedDevices);
    els.networkDevices.addEventListener('click', function (event) {
      var address = event.target.getAttribute('data-address');
      if (address) els.networkAddress.value = address;
    });
    document.getElementById('network-back-btn').addEventListener('click', function () {
      if (!state.network.connected) disconnectNetwork();
      els.network.classList.remove('visible');
    });
    els.settingsSound.addEventListener('click', function () {
      if (setSoundEnabled(!state.sound)) playSound('good');
    });
    if (els.settingsAmbience) {
      els.settingsAmbience.addEventListener('click', function () {
        setAmbientSoundEnabled(!state.ambience);
      });
    }
    if (els.settingsJungle) {
      els.settingsJungle.addEventListener('click', function () {
        setLivingJungleEnabled(!state.livingJungle);
      });
    }
    els.settingsAnimation.addEventListener('click', function () {
      setAnimationsEnabled(!state.animations);
    });
    els.board.addEventListener('pointermove', updateJungleParallax);
    els.board.addEventListener('pointerleave', clearJungleParallax);
    document.addEventListener('visibilitychange', syncAmbientSound);
    Object.keys(SPEED_FACTORS).forEach(function (speed) {
      els.speedButtons[speed].addEventListener('click', function () {
        setMovementSpeed(speed);
      });
    });
    document.getElementById('play-again-btn').addEventListener('click', function () {
      if (state.network.connected) {
        if (state.network.role === 'host') {
          var names = state.players.map(function (player) { return player.name; });
          var restart = { type: 'START', names: names, revision: 0 };
          if (names.length > 2) restart.clientIds = state.network.clientIds.slice();
          if (sendNetwork(restart)) startSharedGame(names, restart.clientIds);
        } else {
          els.message.textContent = 'Ask the host to start the next adventure.';
        }
      } else beginGame(state.selectedCount);
    });
    document.getElementById('new-game-btn').addEventListener('click', function () {
      els.victory.classList.remove('visible');
      els.setup.classList.add('visible');
      previewPlayers();
    });

    state.players = makePlayers(state.selectedCount);
    drawBoard();
    previewPlayers();
    setDieFace(randomDie());
    renderSettings();
    renderHud();
  }

  var publicGame = {
    state: state,
    positions: POS,
    specials: SPECIAL,
    routes: ROUTES,
    beginGame: beginGame,
    setPlayerName: setPlayerName,
    openRename: openRename,
    takeRoll: takeRoll,
    processLanding: processLanding,
    randomDie: randomDie,
    nextDie: nextDie,
    setDieFace: setDieFace,
    showVisual: showVisual,
    animateUnlock: animateUnlock,
    animateHammerBreak: animateHammerBreak,
    collectTool: collectTool,
    avatarArtwork: avatarArtwork,
    setGateFrame: setGateFrame,
    setAnimalFrame: setAnimalFrame,
    encounterAnimal: encounterAnimal,
    animateEncounterDefeat: animateEncounterDefeat,
    rankLabel: rankLabel,
    openSettings: openSettings,
    closeSettings: closeSettings,
    openGuide: openGuide,
    closeGuide: closeGuide,
    openTutorial: openTutorial,
    closeTutorial: closeTutorial,
    advanceTutorial: advanceTutorial,
    tutorialSteps: TUTORIAL_STEPS,
    setSoundEnabled: setSoundEnabled,
    setAmbientSoundEnabled: setAmbientSoundEnabled,
    setLivingJungleEnabled: setLivingJungleEnabled,
    syncAmbientSound: syncAmbientSound,
    updateJungleParallax: updateJungleParallax,
    clearJungleParallax: clearJungleParallax,
    setAnimationsEnabled: setAnimationsEnabled,
    setMovementSpeed: setMovementSpeed,
    loadSettings: loadSettings,
    openNetwork: openNetwork,
    setWifiPlayerCount: setWifiPlayerCount,
    hostNetwork: hostNetwork,
    joinNetwork: joinNetwork,
    pollNetwork: pollNetwork,
    handleNetworkMessage: handleNetworkMessage,
    refreshPairedDevices: refreshPairedDevices,
    disconnectNetwork: disconnectNetwork,
    requestRoll: requestRoll,
    playSound: playSound,
    unlockAudio: unlockAudio
  };
  window.KeysAndClaws = publicGame;
  window.AdventureTrail = publicGame;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else bind();
}());
