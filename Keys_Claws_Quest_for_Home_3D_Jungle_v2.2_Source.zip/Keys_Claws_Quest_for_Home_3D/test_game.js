#!/usr/bin/env node
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ASSET_ROOT = fs.existsSync(path.join(__dirname, 'map.jpg'))
  ? __dirname : path.join(__dirname, '..', 'adventure_android');

const ids = Object.create(null);
const listeners = Object.create(null);
const seenClasses = new Set();
const waitDurations = [];

class ClassList {
  constructor(owner) { this.owner = owner; this.values = new Set(); }
  add(name) { this.values.add(name); }
  remove(name) { this.values.delete(name); }
  toggle(name, force) {
    const enabled = force === undefined ? !this.values.has(name) : force;
    if (enabled) this.values.add(name); else this.values.delete(name);
    return enabled;
  }
  contains(name) { return this.values.has(name); }
}

class Element {
  constructor(tag, id) {
    this.tagName = tag;
    this.id = id || '';
    this.attrs = Object.create(null);
    this.children = [];
    this.handlers = Object.create(null);
    this.classList = new ClassList(this);
    this.style = {
      values: Object.create(null),
      setProperty: function (name, value) { this.values[name] = String(value); }
    };
    this.textContent = '';
    this.innerHTML = '';
    this.disabled = false;
    this.value = '';
    if (id) ids[id] = this;
  }
  setAttribute(name, value) {
    this.attrs[name] = String(value);
    if (name === 'id') { this.id = String(value); ids[this.id] = this; }
    if (name === 'class') seenClasses.add(String(value));
  }
  getAttribute(name) { return this.attrs[name] || null; }
  appendChild(child) { this.children.push(child); return child; }
  addEventListener(name, handler) { this.handlers[name] = handler; }
  focus() {}
  select() {}
  getBoundingClientRect() { return { left: 10, top: 20, width: 200, height: 100 }; }
  getTotalLength() { return 100; }
  getPointAtLength(distance) {
    const numbers = (this.attrs.d || '').match(/-?\d+(?:\.\d+)?/g).map(Number);
    const ratio = distance / 100;
    return {
      x: numbers[0] + (numbers[numbers.length - 2] - numbers[0]) * ratio,
      y: numbers[1] + (numbers[numbers.length - 1] - numbers[1]) * ratio
    };
  }
}

[
  'board', 'active-player', 'position-line', 'inventory', 'roll-btn', 'die-face',
  'turn-hint', 'players-list', 'top-message', 'event-banner', 'setup-overlay',
  'victory-overlay', 'winner-line', 'victory-stats', 'victory-rankings',
  'player-preview', 'start-btn',
  'restart-btn', 'sound-btn', 'play-again-btn', 'new-game-btn', 'rename-overlay',
  'rename-input', 'rename-label', 'rename-save-btn', 'rename-cancel-btn',
  'scene-overlay', 'scene-title', 'scene-stage', 'scene-caption',
  'settings-btn', 'setup-settings-btn', 'settings-overlay', 'settings-close-btn',
  'settings-sound-btn', 'settings-ambience-btn', 'settings-jungle-btn',
  'settings-animation-btn', 'mode-hotseat-btn',
  'mode-wifi-btn', 'mode-bluetooth-btn', 'speed-slow-btn', 'speed-normal-btn',
  'speed-fast-btn', 'network-overlay', 'network-title', 'network-symbol',
  'network-instructions', 'network-name', 'network-address',
  'network-address-label', 'network-devices', 'network-refresh-btn',
  'network-status', 'network-host-btn', 'network-join-btn', 'network-back-btn',
  'wifi-player-picker', 'wifi-count-2', 'wifi-count-3', 'wifi-count-4',
  'help-btn', 'field-guide-btn', 'setup-guide-btn', 'setup-tutorial-btn',
  'settings-guide-btn', 'guide-overlay', 'rules-frame', 'guide-dismiss-btn',
  'guide-close-btn', 'guide-tutorial-btn', 'tutorial-overlay', 'tutorial-progress',
  'tutorial-art', 'tutorial-badge', 'tutorial-title', 'tutorial-description',
  'tutorial-tip', 'tutorial-back-btn', 'tutorial-next-btn', 'tutorial-close-btn',
  'tutorial-rules-btn'
].forEach(function (id) { new Element('div', id); });

const choices = [1, 2, 3, 4].map(function (count) {
  const item = new Element('button');
  item.setAttribute('data-count', count);
  return item;
});

global.document = {
  readyState: 'loading',
  hidden: false,
  createElementNS: function (namespace, name) { return new Element(name); },
  getElementById: function (id) { return ids[id] || null; },
  addEventListener: function (name, callback) { listeners[name] = callback; },
  querySelectorAll: function (selector) { return selector === '.count-choice' ? choices : []; }
};
global.window = {};
global.setTimeout = function (callback, milliseconds) {
  waitDurations.push(milliseconds || 0);
  queueMicrotask(callback);
  return 1;
};
let intervalCounter = 0;
const intervals = new Map();
global.setInterval = function (callback) {
  const id = ++intervalCounter;
  intervals.set(id, callback);
  return id;
};
global.clearInterval = function (id) { intervals.delete(id); };

vm.runInThisContext(fs.readFileSync(path.join(__dirname, 'game.js'), 'utf8'), {
  filename: 'game.js'
});
listeners.DOMContentLoaded();

const game = window.KeysAndClaws;
game.state.sound = false;
const results = [];

function fresh(count) {
  game.beginGame(count || 1);
  game.state.sound = false;
  return game.state.players[0];
}

async function check(name, operation) {
  await operation();
  results.push(name);
}

(async function main() {
  assert.strictEqual(game, window.AdventureTrail);
  assert.strictEqual(Object.keys(game.positions).length, 35);
  assert.deepStrictEqual(Object.values(game.routes).map(function (r) {
    return [r.from, r.to];
  }), [[3, 11], [6, 1], [12, 18], [17, 10], [25, 29], [27, 24], [35, 30]]);

  await check('The jungle trail has exactly 35 unique spaces in approved 7/7/7/6/8 lanes', async function () {
    assert.deepStrictEqual([0, 1, 2, 3, 4].map(function (row) {
      return Object.values(game.positions).filter(function (point) { return point.row === row; }).length;
    }), [7, 7, 7, 6, 8]);
    [[7, 8], [14, 15], [21, 22], [27, 28]].forEach(function (turn) {
      assert.strictEqual(game.positions[turn[0]].x, game.positions[turn[1]].x);
      assert.notStrictEqual(game.positions[turn[0]].row, game.positions[turn[1]].row);
    });
    assert.ok(ids['river-barrier']);
    assert.ok(Number(game.positions[27].x) < 205, 'the ordinary trail must turn at 27 → 28');
    assert.strictEqual(ids['river-barrier'].getAttribute('data-bridge-crossing'), '25-29');
  });

  await check('Spaces 21 and 22 sit together on the existing dry jungle turn, not in the water', async function () {
    assert.strictEqual(game.positions[21].x, 740);
    assert.strictEqual(game.positions[22].x, 740);
    assert.ok(game.positions[21].x <= 760,
      'the right-hand middle-row endpoints extend beyond the dry background path');
    assert.strictEqual(game.positions[21].y, 311);
    assert.strictEqual(game.positions[22].y, 208);
    const source = fs.readFileSync(path.join(__dirname, 'game.js'), 'utf8');
    assert.ok(source.includes('player.position === 21 && destination === 22'));
    assert.ok(source.includes('Math.sin(progress * Math.PI) * 50'));
  });

  await check('Pass-and-play is the default mode with two named explorers', async function () {
    assert.strictEqual(game.state.selectedCount, 2);
    assert.strictEqual(game.state.players.length, 2);
    assert.ok(ids['player-preview'].innerHTML.includes('data-player-index="1"'));
  });

  await check('Every interactive key, lock, lion, wolf, and hammer has an addressable board icon', async function () {
    [2, 6, 17, 27, 31, 33, 35].forEach(function (space) {
      assert.ok(ids['tile-' + space], 'space ' + space + ' tile is missing');
      assert.ok(ids['space-icon-' + space], 'space ' + space + ' icon is missing');
    });
    assert.ok(ids['lock-shackle-6']);
    assert.ok(ids['lock-shackle-35']);
  });

  await check('Approved board artwork fully replaces the old lion, wolf, key, and gate drawings', async function () {
    [[2, 'key_normal'], [6, 'gate_closed'], [17, 'lion_idle'],
      [27, 'wolf_idle'], [31, 'key_normal'], [33, 'hammer'], [35, 'gate_closed']]
      .forEach(function (expected) {
        const icon = ids['space-icon-' + expected[0]];
        const pictures = icon.children.filter(function (child) {
          return child.tagName === 'image';
        });
        assert.strictEqual(pictures.length, 1, 'space ' + expected[0] + ' has duplicated images');
        assert.ok(pictures[0].getAttribute('href').includes(expected[1]));
        const oldVisibleDrawing = icon.children.filter(function (child) {
          return child.tagName !== 'image' && child.getAttribute('opacity') !== '0';
        });
        assert.deepStrictEqual(oldVisibleDrawing, [],
          'space ' + expected[0] + ' still contains an overlapping old drawing');
      });
    assert.strictEqual(ids['lock-shackle-6'].getAttribute('opacity'), '0');
    assert.strictEqual(ids['lock-shackle-35'].getAttribute('opacity'), '0');
  });

  await check('The uploaded natural jungle background stays crisp without baked duplicate objects', async function () {
    const backdrop = ids.board.children.find(function (child) {
      return child.tagName === 'image';
    });
    assert.ok(backdrop);
    assert.strictEqual(backdrop.getAttribute('href'), 'art/jungle_natural.jpg');
    assert.ok(Number(backdrop.getAttribute('opacity')) >= .85);
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.ok(css.includes('art/jungle_natural.jpg'));
  });

  await check('One background-native board replaces the tilted 3D canvas and every camera control', async function () {
    const page = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
    ['id="world-3d"', 'id="world-art"', 'id="world-labels"',
      'id="world-toolbar"', 'id="camera-mode-btn"', 'id="fullscreen-board-btn"',
      'id="zoom-out-btn"',
      'id="zoom-in-btn"', 'src="world3d.js"', 'LIVE 3D WORLD',
      'CAMERA: FOLLOW'].forEach(function (oldLayer) {
      assert.strictEqual(page.includes(oldLayer), false,
        oldLayer + ' reintroduces the unwanted second 3D board');
    });
    assert.ok(page.includes('src="game.js"'));
    const gameplay = fs.readFileSync(path.join(__dirname, 'game.js'), 'utf8');
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.strictEqual(gameplay.includes('KeysClawsWorld3D'), false);
    ['.world-canvas', '.world-art', '.world-labels', '.world-toolbar',
      '.brand-3d', 'board-fullscreen'].forEach(function (oldLayer) {
      assert.strictEqual(css.includes(oldLayer), false,
        oldLayer + ' still styles the removed second board');
    });
    const backgrounds = ids.board.children.filter(function (node) {
      return node.tagName === 'image';
    });
    assert.strictEqual(backgrounds.length, 1);
    assert.strictEqual(backgrounds[0].getAttribute('opacity'), '1');
    assert.strictEqual(ids['river-barrier'].getAttribute('opacity'), '0');
    ['lock', 'lion', 'wolf', 'final'].forEach(function (name) {
      assert.strictEqual(ids['route-' + name].getAttribute('opacity'), '0');
    });
    assert.strictEqual(ids['route-bypass'].getAttribute('opacity'), '.79');
    assert.strictEqual(ids['route-shortcut'].getAttribute('opacity'), '.79');
    assert.strictEqual(ids['route-river'].getAttribute('opacity'), '.79');
  });

  await check('Four flowing rivers animate directly on the one approved background without adding a second board', async function () {
    const water = ids['jungle-water-layer'];
    assert.ok(water, 'the image-native living-water layer is missing');
    assert.strictEqual(water.getAttribute('aria-hidden'), 'true');
    assert.strictEqual(water.children.filter(function (node) {
      return node.getAttribute('class') === 'jungle-river-flow';
    }).length, 4);
    assert.strictEqual(water.children.filter(function (node) {
      return node.getAttribute('class') === 'jungle-river-glint';
    }).length, 4);
    assert.strictEqual(ids.board.children.filter(function (node) {
      return node.tagName === 'image';
    }).length, 1);
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.ok(css.includes('@keyframes jungle-river-current'));
  });

  await check('Three original-image waterfalls have falling water, foam, and soft mist', async function () {
    const water = ids['jungle-water-layer'];
    ['jungle-waterfall-drop', 'jungle-waterfall-foam', 'jungle-mist'].forEach(function (kind) {
      assert.strictEqual(water.children.filter(function (node) {
        return node.getAttribute('class') === kind;
      }).length, 3, 'missing waterfall effect: ' + kind);
    });
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.ok(css.includes('@keyframes jungle-waterfall-fall'));
    assert.ok(css.includes('@keyframes jungle-foam-breathe'));
  });

  await check('Fireflies, foreground leaves, grounded sprites, and bridge shadows create image-native 2.5D depth', async function () {
    assert.strictEqual(ids['jungle-atmosphere'].children.length, 12);
    assert.strictEqual(ids['jungle-foreground'].children.length, 3);
    assert.strictEqual(ids.board.children.filter(function (node) {
      return node.getAttribute('class') === 'wooden-bridge-depth-shadow';
    }).length, 3);
    assert.strictEqual(ids.board.children.filter(function (node) {
      return node.getAttribute('class') === 'jungle-ground-shadow';
    }).length, 4);
    [2, 6, 17, 27, 31, 35].forEach(function (position) {
      assert.ok(ids['space-icon-' + position].getAttribute('class').includes('jungle-object'));
    });
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.ok(css.includes('@keyframes jungle-animal-breathe'));
    assert.ok(css.includes('@keyframes jungle-firefly-float'));
    assert.ok(css.includes('@keyframes jungle-key-live-glow'));
  });

  await check('Pointer parallax remains subtle and respects the reduced-motion preference', async function () {
    game.setLivingJungleEnabled(true);
    game.setAnimationsEnabled(true);
    ids.board.handlers.pointermove({ clientX: 210, clientY: 120 });
    assert.strictEqual(ids.board.style.values['--jungle-depth-x'], '4.00px');
    assert.strictEqual(ids.board.style.values['--jungle-depth-y'], '2.50px');
    window.matchMedia = function () { return { matches: true }; };
    assert.strictEqual(game.updateJungleParallax({ clientX: 10, clientY: 20 }), false);
    assert.strictEqual(ids.board.style.values['--jungle-depth-x'], '4.00px');
    delete window.matchMedia;
    ids.board.handlers.pointerleave();
    assert.strictEqual(ids.board.style.values['--jungle-depth-x'], '0px');
    assert.strictEqual(ids.board.style.values['--jungle-depth-y'], '0px');
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    assert.ok(css.includes('@media (prefers-reduced-motion: reduce)'));
  });

  await check('All printed board numbers are hidden while 35 internal spaces and approved objects remain aligned', async function () {
    assert.deepStrictEqual([0, 1, 2, 3, 4].map(function (row) {
      return Object.values(game.positions).find(function (point) {
        return point.row === row;
      }).y;
    }), [548, 421, 311, 208, 106]);
    const visibleNumbers = ids.board.children.filter(function (node) {
      return node.tagName === 'text' && /^\d+$/.test(node.textContent);
    });
    assert.strictEqual(visibleNumbers.length, 0,
      'a printed number or numbered special-space badge is still visible on the board');
    const hiddenInternalSpaces = ids.board.children.filter(function (node) {
      return node.tagName === 'ellipse' && node.getAttribute('data-space');
    }).map(function (node) { return Number(node.getAttribute('data-space')); });
    assert.strictEqual(hiddenInternalSpaces.length, 35);
    assert.strictEqual(new Set(hiddenInternalSpaces).size, 35);
    assert.deepStrictEqual(ids.board.children.filter(function (node) {
      return node.tagName === 'text';
    }).map(function (node) { return node.textContent; }), ['START', 'HOME']);
    [2, 6, 17, 27, 31, 35].forEach(function (space) {
      const point = game.positions[space];
      assert.strictEqual(ids['space-icon-' + space].getAttribute('transform'),
        'translate(' + point.x + ',' + (point.y + 1) + ')');
    });
  });

  await check('Three visible wooden bridges include the new deliberate 25-to-29 river crossing', async function () {
    assert.ok(ids['space-icon-25'], 'the third bridge entrance is missing');
    assert.strictEqual(game.specials[25].icon, 'shortcut');
    assert.strictEqual(game.routes.river.from, 25);
    assert.strictEqual(game.routes.river.to, 29);
    assert.strictEqual(game.routes.river.bridge, true);
    const planks = ids.board.children.filter(function (node) {
      return node.getAttribute('class') === 'wooden-bridge-planks';
    });
    assert.strictEqual(planks.length, 3);
    assert.ok(ids['route-river'].getAttribute('d').startsWith('M 388 208'));
  });

  await check('The lock-breaking hammer appears directly on hidden jungle space 33', async function () {
    assert.strictEqual(game.specials[33].icon, 'hammer');
    assert.strictEqual(game.positions[33].x, 669);
    assert.strictEqual(game.positions[33].y, 106);
    const pictures = ids['space-icon-33'].children.filter(function (node) {
      return node.tagName === 'image';
    });
    assert.strictEqual(pictures.length, 1);
    assert.strictEqual(pictures[0].getAttribute('href'), 'art/hammer.png');
    assert.strictEqual(ids['tile-33'].getAttribute('data-space'), '33');
  });

  await check('Four distinct full-body 3D-style explorer sprites replace pawn-shaped tokens', async function () {
    fresh(4);
    ['ruby', 'river', 'forest', 'violet'].forEach(function (identity, index) {
      const player = game.state.players[index];
      const token = ids['token-' + index];
      const portraits = token.children.filter(function (node) {
        return node.tagName === 'image';
      });
      assert.strictEqual(player.avatar, identity);
      assert.strictEqual(portraits.length, 1);
      assert.strictEqual(portraits[0].getAttribute('href'),
        'art/avatar_' + identity + '_01.png');
      assert.strictEqual(portraits[0].getAttribute('data-avatar'), identity);
      assert.strictEqual(player.hammer, false);
      for (let frame = 1; frame <= 8; frame++) {
        const filename = 'avatar_' + identity + '_' + String(frame).padStart(2, '0') + '.png';
        assert.ok(fs.existsSync(path.join(ASSET_ROOT, 'art', filename)), filename + ' is missing');
      }
    });
  });

  await check('Explorer walking, pickup, defense, crying, and victory use independent avatar poses', async function () {
    const player = fresh();
    [['idle', '01'], ['walkA', '02'], ['walkB', '03'], ['pickup', '04'],
      ['knife', '05'], ['tool', '06'], ['cry', '07'], ['victory', '08'],
      ['recovery', '08']].forEach(function (pose) {
      assert.strictEqual(game.avatarArtwork(player, pose[0]),
        'art/avatar_ruby_' + pose[1] + '.png');
    });
  });

  await check('The visible board gate swaps its approved images directly on the jungle path', async function () {
    const picture = ids['space-icon-6'].children.find(function (item) {
      return item.tagName === 'image';
    });
    [['unlocking', 'gate_unlocking'], ['opening', 'gate_half_closing'],
      ['open', 'gate_open'], ['passing', 'gate_open'],
      ['half_closing', 'gate_half_closing'], ['closed', 'gate_closed']]
      .forEach(function (expected) {
        game.setGateFrame(6, expected[0]);
        assert.ok(picture.getAttribute('href').includes(expected[1]),
          expected[0] + ' did not update the actual board gate');
      });
  });

  await check('Every elegant dice face displays exactly the correct number of pips', async function () {
    for (let face = 1; face <= 6; face++) {
      game.setDieFace(face);
      assert.strictEqual((ids['die-face'].innerHTML.match(/die-pip active/g) || []).length, face);
      assert.strictEqual(ids['die-face'].getAttribute('data-value'), String(face));
      assert.strictEqual(ids['die-face'].getAttribute('aria-label'), 'Dice showing ' + face);
    }
    assert.throws(function () { game.setDieFace(0); }, RangeError);
    assert.throws(function () { game.setDieFace(7); }, RangeError);
  });

  await check('Secure dice generation rejects biased crypto values', async function () {
    let calls = 0;
    window.crypto = {
      getRandomValues: function (array) {
        array[0] = calls++ === 0 ? 4294967295 : 7;
        return array;
      }
    };
    assert.strictEqual(game.randomDie(), 2);
    assert.strictEqual(calls, 2);
    delete window.crypto;
  });

  await check('All six dice results remain equally reachable', async function () {
    let next = 0;
    const counts = [0, 0, 0, 0, 0, 0];
    window.crypto = {
      getRandomValues: function (array) { array[0] = next++; return array; }
    };
    for (let index = 0; index < 600; index++) counts[game.randomDie() - 1]++;
    assert.deepStrictEqual(counts, [100, 100, 100, 100, 100, 100]);
    delete window.crypto;
  });

  await check('Every player receives all six dice values once in every six rolls', async function () {
    const player = fresh();
    let next = 17;
    window.crypto = {
      getRandomValues: function (array) {
        array[0] = next++ * 2654435761 >>> 0;
        return array;
      }
    };
    const values = [];
    for (let index = 0; index < 60; index++) values.push(game.nextDie(player));
    for (let index = 0; index < values.length; index += 6) {
      assert.deepStrictEqual(values.slice(index, index + 6).sort(), [1, 2, 3, 4, 5, 6]);
    }
    for (let index = 1; index < values.length; index++) {
      assert.notStrictEqual(values[index], values[index - 1], 'a face repeated consecutively');
    }
    delete window.crypto;
  });

  await check('Each explorer owns an independent shuffled dice sequence', async function () {
    fresh(2);
    const first = game.state.players[0];
    const second = game.state.players[1];
    game.nextDie(first);
    assert.strictEqual(first.diceBag.length, 5);
    assert.strictEqual(second.diceBag.length, 0);
    game.nextDie(second);
    assert.strictEqual(first.diceBag.length, 5);
    assert.strictEqual(second.diceBag.length, 5);
    game.nextDie(first);
    assert.strictEqual(first.diceBag.length, 4);
    assert.strictEqual(second.diceBag.length, 5);
  });

  await check('Dice animation does not consume extra real random numbers', async function () {
    fresh();
    let calls = 0;
    window.crypto = {
      getRandomValues: function (array) {
        array[0] = calls++;
        return array;
      }
    };
    await game.takeRoll();
    assert.strictEqual(calls, 5, 'only the five shuffle steps may consume randomness');
    assert.strictEqual(game.state.players[0].diceBag.length, 5);
    delete window.crypto;
  });

  await check('Landing on space 2 collects the first key', async function () {
    const player = fresh();
    const sceneChildrenBefore = ids['scene-stage'].children.length;
    await game.takeRoll(2);
    assert.strictEqual(player.position, 2);
    assert.strictEqual(player.firstKey, true);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['key', 2]]);
    assert.strictEqual(ids['scene-stage'].getAttribute('data-scene'), 'key');
    assert.strictEqual(ids['scene-overlay'].getAttribute('aria-hidden'), 'true');
    assert.strictEqual(ids['tile-2'].classList.contains('board-key-active'), false);
    assert.strictEqual(ids['space-icon-2'].classList.contains('board-key-spin'), false);
    const scenePictures = [];
    function collectPictures(node) {
      if (node.tagName === 'image') scenePictures.push(node);
      node.children.forEach(collectPictures);
    }
    ids['scene-stage'].children.slice(sceneChildrenBefore).forEach(collectPictures);
    assert.strictEqual(scenePictures.length, 1,
      'the key-collection story scene must contain exactly one golden key');
    assert.ok(scenePictures[0].getAttribute('href').includes('key_glow'));
  });

  await check('Explorer movement uses eight slow, smoothly animated frames per space', async function () {
    const player = fresh();
    const before = waitDurations.length;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 1);
    assert.strictEqual(game.state.motionFrames, 8);
    const delays = waitDurations.slice(before);
    assert.strictEqual(delays.filter(function (delay) { return delay === 43; }).length, 8);
    assert.ok(delays.includes(78));
  });

  await check('Space 3 crosses the first elevated bridge, bypasses lock 6, and jumps to 11', async function () {
    const player = fresh();
    await game.takeRoll(3);
    assert.strictEqual(player.position, 11);
    assert.strictEqual(player.firstKey, false);
    assert.strictEqual(game.state.lastSound, 'hurray');
  });

  await check('Crossing gate 6 without a key returns to space 1', async function () {
    const player = fresh();
    player.position = 4;
    seenClasses.delete('crying-board-token');
    await game.takeRoll(4);
    assert.strictEqual(player.position, 1);
    assert.strictEqual(game.state.lastSound, 'cry');
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['cry', 6]]);
    assert.ok(seenClasses.has('crying-board-token'));
    assert.strictEqual(player.expression, undefined);
    assert.ok(game.state.motionFrames >= 42);
  });

  await check('The first key permits passage through gate 6', async function () {
    const player = fresh();
    player.position = 4;
    player.firstKey = true;
    await game.takeRoll(3);
    assert.strictEqual(player.position, 7);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['unlock', 6]]);
    assert.ok(ids['lock-shackle-6'].getAttribute('d').includes('10 -2'));
  });

  await check('A successful gate opens, admits the child, closes halfway, and shuts with distinct sounds', async function () {
    const player = fresh();
    player.position = 5;
    player.firstKey = true;
    await game.takeRoll(1);
    assert.deepStrictEqual(game.state.gateEvents.map(function (event) {
      return [event.space, event.frame];
    }), [[6, 'unlocking'], [6, 'opening'], [6, 'open'], [6, 'passing'],
      [6, 'half_closing'], [6, 'closed']]);
    assert.strictEqual(game.state.gateFrames[6], 'closed');
    assert.strictEqual(game.state.soundEvents.filter(function (effect) {
      return effect === 'gate_open';
    }).length, 1);
    assert.strictEqual(game.state.soundEvents.filter(function (effect) {
      return effect === 'gate_close';
    }).length, 1);
    assert.ok(game.state.soundEvents.indexOf('gate_open') <
      game.state.soundEvents.indexOf('gate_close'));
  });

  await check('Space 13 awards the first knife', async function () {
    const player = fresh();
    player.position = 12;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 13);
    assert.strictEqual(player.knife, true);
    assert.strictEqual(game.state.visualEvents[0].kind, 'pickup_knife');
    assert.ok(game.state.soundEvents.includes('knife_pickup'));
  });

  await check('Space 15 awards an axe', async function () {
    const player = fresh();
    player.position = 14;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 15);
    assert.strictEqual(player.axe, true);
    assert.strictEqual(game.state.visualEvents[0].kind, 'pickup_axe');
    assert.ok(game.state.soundEvents.includes('axe_pickup'));
  });

  await check('Space 12 takes the second elevated bridge directly to 18', async function () {
    const player = fresh();
    player.position = 11;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 18);
    assert.strictEqual(game.state.lastSound, 'hurray');
  });

  await check('The lion sends an unarmed explorer back to medical 10', async function () {
    const player = fresh();
    player.position = 16;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 10);
    assert.strictEqual(game.state.lastSound, 'relief');
    assert.deepStrictEqual(game.state.soundEvents.slice(-5),
      ['step', 'lion', 'fight', 'cry', 'relief']);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['lion', 17], ['explorer_falls', 17], ['cry', 17], ['recovery', 10]]);
    assert.ok(seenClasses.has('scene-lion-mane'));
    assert.ok(seenClasses.has('scene-animal-jaw'));
  });

  await check('A knife protects the explorer from the lion', async function () {
    const player = fresh();
    player.position = 16;
    player.knife = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 17);
    assert.deepStrictEqual(game.state.soundEvents.slice(-5),
      ['step', 'lion', 'fight', 'knife_use', 'hurray']);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return event.kind;
    }), ['lion', 'defend_knife', 'animal_falls']);
  });

  await check('An axe alone protects the explorer from the lion', async function () {
    const player = fresh();
    player.position = 16;
    player.axe = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 17);
    assert.strictEqual(player.knife, false);
    assert.strictEqual(game.state.lastSound, 'hurray');
    assert.ok(game.state.soundEvents.includes('axe_use'));
    assert.ok(game.state.visualEvents.some(function (event) {
      return event.kind === 'defend_axe';
    }));
  });

  await check('A large dice roll cannot jump over the lion without a knife', async function () {
    const player = fresh();
    player.position = 14;
    await game.takeRoll(5);
    assert.strictEqual(player.position, 10);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['lion', 17], ['explorer_falls', 17], ['cry', 17], ['recovery', 10]]);
  });

  await check('A knife permits a player to pass through the lion and finish the roll', async function () {
    const player = fresh();
    player.position = 14;
    player.knife = true;
    await game.takeRoll(5);
    assert.strictEqual(player.position, 19);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['lion', 17], ['defend_knife', 17], ['animal_falls', 17]]);
  });

  await check('An axe permits a player to pass through the lion and finish the roll', async function () {
    const player = fresh();
    player.position = 14;
    player.axe = true;
    await game.takeRoll(5);
    assert.strictEqual(player.position, 19);
    assert.strictEqual(player.knife, false);
  });

  await check('The genuine space-12 bridge bypasses lion 17 without a knife or axe', async function () {
    const player = fresh();
    player.position = 11;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 18);
    assert.strictEqual(player.knife, false);
    assert.strictEqual(player.axe, false);
    assert.strictEqual(game.state.visualEvents.length, 0);
  });

  await check('Landing on 25 crosses the third bridge to 29 and safely bypasses wolf 27', async function () {
    const player = fresh();
    player.position = 24;
    player.knife = false;
    player.axe = false;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 29);
    assert.strictEqual(player.knife, false);
    assert.strictEqual(game.state.lastSound, 'hurray');
    assert.deepStrictEqual(game.state.visualEvents, [],
      'the approved shortcut must not trigger the skipped wolf encounter');
  });

  await check('Passing space 25 without landing does not activate the third shortcut bridge', async function () {
    const player = fresh();
    player.position = 24;
    await game.takeRoll(2);
    assert.strictEqual(player.position, 26);
    assert.strictEqual(player.knife, true);
  });

  await check('Space 26 awards another knife', async function () {
    const player = fresh();
    player.position = 25;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 26);
    assert.strictEqual(player.knife, true);
  });

  await check('The wolf sends an explorer without a knife back to hospital 24', async function () {
    const player = fresh();
    player.position = 26;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 24);
    assert.strictEqual(game.state.lastSound, 'relief');
    assert.deepStrictEqual(game.state.soundEvents.slice(-5),
      ['step', 'wolf', 'fight', 'cry', 'relief']);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['wolf', 27], ['explorer_falls', 27], ['cry', 27], ['recovery', 24]]);
  });

  await check('A knife protects the explorer from the wolf', async function () {
    const player = fresh();
    player.position = 26;
    player.knife = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 27);
  });

  await check('An axe alone does not protect the explorer from the wolf', async function () {
    const player = fresh();
    player.position = 26;
    player.axe = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 24);
    assert.strictEqual(player.knife, false);
  });

  await check('A large dice roll cannot jump over the wolf without a knife', async function () {
    const player = fresh();
    player.position = 25;
    await game.takeRoll(5);
    assert.strictEqual(player.position, 24);
    assert.strictEqual(player.knife, false);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['wolf', 27], ['explorer_falls', 27], ['cry', 27], ['recovery', 24]]);
  });

  await check('A knife permits a player to pass through the wolf and finish the roll', async function () {
    const player = fresh();
    player.position = 25;
    player.knife = true;
    await game.takeRoll(5);
    assert.strictEqual(player.position, 30);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['wolf', 27], ['defend_knife', 27], ['animal_falls', 27]]);
  });

  await check('Landing exactly on an animal runs its encounter only once', async function () {
    const player = fresh();
    player.position = 16;
    player.knife = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.soundEvents.filter(function (sound) {
      return sound === 'lion';
    }).length, 1);
  });

  await check('Space 31 awards the final key', async function () {
    const player = fresh();
    player.position = 30;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 31);
    assert.strictEqual(player.finalKey, true);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['key', 31]]);
  });

  await check('Landing exactly on space 33 awards only that explorer the hammer', async function () {
    const player = fresh(2);
    player.position = 32;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 33);
    assert.strictEqual(player.hammer, true);
    assert.strictEqual(game.state.players[1].hammer, false);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space, event.player];
    }), [['pickup_hammer', 33, 0]]);
    assert.ok(game.state.soundEvents.includes('hammer_pickup'));
  });

  await check('Passing space 33 without landing never collects the hammer', async function () {
    const player = fresh();
    player.position = 31;
    await game.takeRoll(3);
    assert.strictEqual(player.position, 34);
    assert.strictEqual(player.hammer, false);
    assert.strictEqual(game.state.visualEvents.length, 0);
  });

  await check('The hammer is displayed as isolated adventure gear for the current explorer', async function () {
    const player = fresh(2);
    player.position = 32;
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 1);
    assert.ok(ids.inventory.innerHTML.includes('Hammer'));
    assert.strictEqual(game.state.players[1].hammer, false);
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 0);
    assert.ok(ids.inventory.innerHTML.includes('gear active'));
    assert.strictEqual(player.hammer, true);
  });

  await check('A hammer never replaces the first key at gate 6', async function () {
    const player = fresh();
    player.position = 5;
    player.hammer = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 1);
    assert.strictEqual(player.hammer, true);
    assert.strictEqual(player.firstKey, false);
    assert.strictEqual(game.state.won, false);
  });

  await check('A hammer never protects against the lion or wolf', async function () {
    let player = fresh();
    player.position = 16;
    player.hammer = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 10);
    player = fresh();
    player.position = 26;
    player.hammer = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 24);
    assert.strictEqual(player.knife, false);
  });

  await check('Final lock 35 returns a keyless explorer to space 30 without granting a key', async function () {
    const player = fresh();
    player.position = 34;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 30);
    assert.strictEqual(player.finalKey, false);
    assert.strictEqual(game.state.won, false);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['cry', 35]]);
  });

  await check('An exact final arrival with a hammer and no final key breaks the lock and wins', async function () {
    const player = fresh();
    player.position = 34;
    player.hammer = true;
    player.finalKey = false;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 35);
    assert.strictEqual(player.hammer, true);
    assert.strictEqual(player.finalKey, false);
    assert.strictEqual(player.finishMethod, 'hammer');
    assert.strictEqual(game.state.won, true);
    assert.ok(ids['winner-line'].textContent.includes('smashed the final lock'));
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['hammer_use', 35], ['lock_break', 35]]);
    assert.ok(game.state.soundEvents.filter(function (sound) {
      return sound === 'hammer_hit';
    }).length >= 2);
    assert.ok(game.state.soundEvents.includes('lock_break'));
    assert.deepStrictEqual(game.state.gateEvents.map(function (event) {
      return [event.space, event.frame];
    }), [[35, 'broken'], [35, 'opening'], [35, 'open'], [35, 'passing'],
      [35, 'half_closing'], [35, 'closed']]);
  });

  await check('The final key keeps priority over a hammer and uses normal gate unlocking', async function () {
    const player = fresh();
    player.position = 34;
    player.hammer = true;
    player.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.won, true);
    assert.strictEqual(player.finishMethod, undefined);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return event.kind;
    }), ['unlock']);
    assert.strictEqual(game.state.soundEvents.includes('hammer_hit'), false);
    assert.strictEqual(game.state.gateEvents[0].frame, 'unlocking');
  });

  await check('The broken final lock switches to the dedicated approved transparent gate artwork', async function () {
    fresh();
    game.setGateFrame(35, 'broken');
    const picture = ids['space-icon-35'].children.find(function (item) {
      return item.tagName === 'image';
    });
    assert.strictEqual(picture.getAttribute('href'), 'art/gate_broken.png');
    assert.strictEqual(game.state.gateFrames[35], 'broken');
    game.setGateFrame(35, 'closed');
  });

  await check('Lion and wolf cycle through living walk, alert, sleep, and idle artwork', async function () {
    let player = fresh();
    player.position = 16;
    player.axe = true;
    await game.takeRoll(1);
    assert.deepStrictEqual(game.state.animalEvents.map(function (event) {
      return event.frame;
    }), ['walk', 'roar', 'idle', 'sleep', 'idle']);
    player = fresh();
    player.position = 26;
    player.knife = true;
    await game.takeRoll(1);
    assert.deepStrictEqual(game.state.animalEvents.map(function (event) {
      return event.frame;
    }), ['walk', 'howl', 'idle', 'sleep', 'idle']);
  });

  await check('Winning a lion encounter makes the approved lion visibly fall down', async function () {
    const player = fresh();
    player.position = 16;
    player.axe = true;
    await game.takeRoll(1);
    assert.deepStrictEqual(game.state.defeatEvents.map(function (event) {
      return [event.space, event.animal, event.loser, event.winner, event.player];
    }), [[17, 'lion', 'animal', 'explorer', 0]]);
    assert.ok(game.state.visualEvents.some(function (event) {
      return event.kind === 'animal_falls' && event.space === 17;
    }));
    assert.ok(seenClasses.has('scene-outcome-animal scene-animal-fall'));
    assert.ok(seenClasses.has('scene-outcome-explorer scene-explorer-victor'));
    assert.strictEqual(ids['space-icon-17'].classList.contains('board-animal-fall'), false);
  });

  await check('Winning a wolf encounter makes the approved wolf visibly fall down', async function () {
    const player = fresh();
    player.position = 26;
    player.knife = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.defeatEvents[0].animal, 'wolf');
    assert.strictEqual(game.state.defeatEvents[0].loser, 'animal');
    assert.strictEqual(game.state.defeatEvents[0].winner, 'explorer');
    assert.ok(game.state.visualEvents.some(function (event) {
      return event.kind === 'animal_falls' && event.space === 27;
    }));
  });

  await check('Losing to either animal makes that same explorer fall before crying and recovery', async function () {
    let player = fresh();
    player.position = 16;
    await game.takeRoll(1);
    assert.strictEqual(game.state.defeatEvents[0].animal, 'lion');
    assert.strictEqual(game.state.defeatEvents[0].loser, 'explorer');
    assert.strictEqual(game.state.defeatEvents[0].winner, 'lion');
    assert.ok(seenClasses.has('falling-board-token'));
    assert.ok(seenClasses.has('scene-outcome-explorer scene-explorer-fall'));
    assert.strictEqual(player.expression, undefined);
    player = fresh();
    player.position = 26;
    await game.takeRoll(1);
    assert.strictEqual(game.state.defeatEvents[0].animal, 'wolf');
    assert.strictEqual(game.state.defeatEvents[0].winner, 'wolf');
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return event.kind;
    }), ['wolf', 'explorer_falls', 'cry', 'recovery']);
  });

  await check('Crying and recovery scenes use the affected explorer\'s full-body avatar', async function () {
    fresh(2);
    const player = game.state.players[1];
    game.state.current = 1;
    player.position = 16;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 10);
    const pictures = [];
    function collect(node) {
      if (node.tagName === 'image') pictures.push(node.getAttribute('href'));
      node.children.forEach(collect);
    }
    ids['scene-stage'].children.forEach(collect);
    assert.ok(pictures.some(function (source) {
      return source === 'art/avatar_river_07.png';
    }));
    assert.ok(pictures.some(function (source) {
      return source === 'art/avatar_river_08.png';
    }));
  });

  await check('After falling back to 30, landing on 31 collects the final key', async function () {
    const player = fresh();
    player.position = 34;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 30);
    await game.takeRoll(1);
    assert.strictEqual(player.position, 31);
    assert.strictEqual(player.finalKey, true);
  });

  await check('An exact landing on 35 with the final key wins the game', async function () {
    const player = fresh();
    player.position = 34;
    player.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(player.position, 35);
    assert.strictEqual(game.state.won, true);
    assert.strictEqual(ids['victory-overlay'].classList.contains('visible'), true);
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return [event.kind, event.space];
    }), [['unlock', 35]]);
    assert.ok(ids['lock-shackle-35'].getAttribute('d').includes('12 -17'));
  });

  await check('A two-explorer game records the champion and automatically assigns second place', async function () {
    const champion = fresh(2);
    champion.position = 34;
    champion.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.won, true);
    assert.deepStrictEqual(game.state.rankings, [0, 1]);
    assert.strictEqual(champion.finished, true);
    assert.strictEqual(champion.rank, 1);
    assert.strictEqual(game.state.players[1].finished, true);
    assert.strictEqual(game.state.players[1].rank, 2);
    assert.strictEqual(game.state.players[1].lastPlace, true);
    assert.ok(ids['victory-rankings'].innerHTML.includes('ranking-place-1'));
    assert.ok(ids['victory-rankings'].innerHTML.includes('2nd'));
    assert.ok(ids['victory-rankings'].innerHTML.includes(champion.name));
  });

  await check('A three-explorer race continues after first place until one of the final two wins', async function () {
    const champion = fresh(3);
    champion.position = 34;
    champion.hammer = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.won, false);
    assert.strictEqual(champion.rank, 1);
    assert.strictEqual(champion.finished, true);
    assert.deepStrictEqual(game.state.rankings, [0]);
    assert.strictEqual(game.state.current, 1);
    assert.strictEqual(ids['victory-overlay'].classList.contains('visible'), false);
    assert.ok(ids['players-list'].innerHTML.includes('1st'));
    assert.ok(ids['top-message'].textContent.includes('1st place'));
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 2);
    const runnerUp = game.state.players[2];
    runnerUp.position = 34;
    runnerUp.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.won, true);
    assert.deepStrictEqual(game.state.rankings, [0, 2, 1]);
    assert.strictEqual(runnerUp.rank, 2);
    assert.strictEqual(game.state.players[1].rank, 3);
    assert.strictEqual(game.state.players[1].lastPlace, true);
    assert.ok(ids['winner-line'].textContent.includes(champion.name));
    assert.ok(ids['victory-rankings'].innerHTML.includes('3rd'));
  });

  await check('Four explorers race for three finishes while completed players are skipped', async function () {
    const first = fresh(4);
    first.position = 34;
    first.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 1);
    assert.strictEqual(game.state.won, false);
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 2);
    const second = game.state.players[2];
    second.position = 34;
    second.hammer = true;
    await game.takeRoll(1);
    assert.strictEqual(second.rank, 2);
    assert.strictEqual(game.state.current, 3);
    await game.takeRoll(1);
    assert.strictEqual(game.state.current, 1, 'finished explorers one and three cannot roll again');
    const third = game.state.players[1];
    third.position = 34;
    third.finalKey = true;
    await game.takeRoll(1);
    assert.strictEqual(game.state.won, true);
    assert.deepStrictEqual(game.state.rankings, [0, 2, 1, 3]);
    assert.deepStrictEqual(game.state.players.map(function (player) {
      return player.rank;
    }), [1, 3, 2, 4]);
    assert.strictEqual(game.state.players[3].lastPlace, true);
    assert.strictEqual(game.state.finishEvents.length, 4);
    assert.strictEqual(game.state.finishEvents[3].automatic, true);
    assert.ok(ids['victory-rankings'].innerHTML.includes('4th'));
    assert.ok(ids['victory-rankings'].innerHTML.includes('HAMMER'));
  });

  await check('Finished explorers cannot request another roll and restarting clears all ranks', async function () {
    const finisher = fresh(3);
    finisher.position = 34;
    finisher.finalKey = true;
    await game.takeRoll(1);
    const turns = game.state.turns;
    game.state.current = 0;
    assert.strictEqual(game.requestRoll(), false);
    assert.strictEqual(game.state.turns, turns);
    game.beginGame(3);
    assert.deepStrictEqual(game.state.rankings, []);
    assert.deepStrictEqual(game.state.finishEvents, []);
    assert.ok(game.state.players.every(function (player) {
      return player.finished === false && player.rank === 0 && player.lastPlace === false;
    }));
    assert.strictEqual(ids['victory-rankings'].innerHTML, '');
  });

  await check('Key-turning, opening-lock, roaring, and crying visual animations are defined', async function () {
    const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
    ['@keyframes key-clockwise', '@keyframes key-in-lock', '@keyframes shackle-open',
      '@keyframes animal-roar', '@keyframes mane-shake', '@keyframes child-sob',
      '@keyframes falling-tear', '@keyframes explorer-avatar-idle',
      '@keyframes explorer-avatar-stride', '@keyframes explorer-pickup-reach',
      '@keyframes explorer-knife-defense', '@keyframes explorer-tool-windup',
      '@keyframes hammer-final-strike', '@keyframes lock-fragment-burst',
      '@keyframes explorer-recovery-cheer', '@keyframes defeated-animal-topple',
      '@keyframes defeated-explorer-topple', '@keyframes board-animal-topple',
      '@keyframes board-explorer-topple'].forEach(function (animation) {
      assert.ok(css.includes(animation), animation + ' is missing');
    });
  });

  await check('An overshoot leaves the explorer in the original space', async function () {
    const player = fresh();
    player.position = 33;
    player.finalKey = true;
    await game.takeRoll(4);
    assert.strictEqual(player.position, 33);
    assert.strictEqual(game.state.won, false);
  });

  await check('Local multiplayer rotates turns and keeps inventories separate', async function () {
    const first = fresh(3);
    await game.takeRoll(2);
    assert.strictEqual(first.firstKey, true);
    assert.strictEqual(game.state.current, 1);
    assert.strictEqual(game.state.players[1].firstKey, false);
    assert.strictEqual(ids['roll-btn'].disabled, false);
    assert.ok(ids['turn-hint'].textContent.includes(game.state.players[1].name));
    await game.takeRoll(3);
    assert.strictEqual(game.state.players[1].position, 11);
    assert.strictEqual(game.state.current, 2);
  });

  await check('The next explorer can roll immediately without confirmation', async function () {
    fresh(2);
    await game.takeRoll(1);
    assert.strictEqual(ids['roll-btn'].disabled, false);
    await game.takeRoll(1);
    assert.strictEqual(game.state.players[1].position, 1);
    assert.strictEqual(game.state.turns, 2);
    assert.strictEqual(game.state.current, 0);
  });

  await check('Four-player hotseat turns rotate back to the first explorer', async function () {
    fresh(4);
    for (let index = 0; index < 4; index++) {
      assert.strictEqual(game.state.current, index);
      await game.takeRoll(1);
      assert.strictEqual(ids['roll-btn'].disabled, false);
    }
    assert.strictEqual(game.state.current, 0);
    assert.deepStrictEqual(game.state.players.map(function (player) { return player.position; }), [1, 1, 1, 1]);
  });

  await check('No handoff confirmation screen exists in the game interface', async function () {
    const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
    assert.ok(!html.includes('handoff-overlay'));
    assert.ok(!html.includes('ready-btn'));
    fresh();
    await game.takeRoll(1);
    assert.strictEqual(ids['roll-btn'].disabled, false);
  });

  await check('A separate offline rules page accurately documents every approved gameplay rule', async function () {
    const rules = fs.readFileSync(path.join(__dirname, 'rules.html'), 'utf8');
    ['How to Play', '35 spaces', '1 to 6', 'space 2', 'space 6',
      'space 1', '3 → 11', '12 → 18', '25 → 29', 'spaces 13 and 26',
      'space 15', 'Lion · Space 17', 'knife or an axe', 'space 10',
      'Wolf · Space 27', 'Only a', 'space 24', 'space 31', 'space 33',
      'hammer', 'space 35', 'space 30', '1st, 2nd, or 3rd place',
      'last place', 'final ranks', '1–4 explorers',
      '2–4 separate devices',
      'previously paired devices'].forEach(function (rule) {
      assert.ok(rules.toLowerCase().includes(rule.toLowerCase()), 'missing approved rule: ' + rule);
    });
    assert.ok(rules.includes('art/lion_idle.png'));
    assert.ok(rules.includes('art/wolf_idle.png'));
    assert.ok(rules.includes('art/key_normal.png'));
    assert.ok(rules.includes('art/gate_open.png'));
    assert.ok(rules.includes('art/hammer.png'));
    assert.ok(!rules.includes('https://'));
    assert.ok(!rules.includes('world3d.js'));
  });

  await check('How to Play opens the separate rules page inside a lazy-loaded popup', async function () {
    fresh();
    assert.strictEqual(ids['rules-frame'].getAttribute('src'), null);
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), false);
    ids['setup-guide-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    assert.strictEqual(ids['rules-frame'].getAttribute('src'), 'rules.html');
    ids['guide-close-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), false);
  });

  await check('Game rules remain accessible from the toolbar, field guide, and settings', async function () {
    ids['help-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    ids['guide-dismiss-btn'].handlers.click();
    ids['field-guide-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    game.closeGuide();
    game.openSettings();
    ids['settings-guide-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    assert.strictEqual(ids['settings-overlay'].classList.contains('visible'), true);
    game.closeGuide();
    assert.strictEqual(ids['settings-overlay'].classList.contains('visible'), true);
    game.closeSettings();
  });

  await check('The guided tutorial starts from setup with seven illustrated onboarding steps', async function () {
    ids['setup-tutorial-btn'].handlers.click();
    assert.strictEqual(ids['tutorial-overlay'].classList.contains('visible'), true);
    assert.strictEqual(game.state.tutorial.visible, true);
    assert.strictEqual(game.state.tutorial.index, 0);
    assert.strictEqual(game.tutorialSteps.length, 7);
    assert.strictEqual(ids['tutorial-back-btn'].disabled, true);
    assert.ok(ids['tutorial-progress'].getAttribute('aria-label').includes('1 of 7'));
    assert.strictEqual(ids['tutorial-title'].textContent, 'Find Your Way Home');
    ids['tutorial-next-btn'].handlers.click();
    assert.strictEqual(game.state.tutorial.index, 1);
    assert.strictEqual(ids['tutorial-back-btn'].disabled, false);
    ids['tutorial-next-btn'].handlers.click();
    assert.ok(ids['tutorial-art'].innerHTML.includes('art/key_normal.png'));
    assert.ok(ids['tutorial-art'].innerHTML.includes('art/gate_closed.png'));
    ids['tutorial-back-btn'].handlers.click();
    assert.strictEqual(game.state.tutorial.index, 1);
    game.closeTutorial();
  });

  await check('The tutorial explains all bridges, both animal defenses, four-player Wi-Fi, and exact victory', async function () {
    const steps = Array.from(game.tutorialSteps, function (step) {
      return step.title + ' ' + step.description + ' ' + step.tip;
    }).join('\n');
    ['3 to jump to 11', '12 to jump to 18', '25 to cross the river',
      'knives at 13 or 26', 'axe at 15', 'lion at 17', 'wolf at 27',
      'only a knife', '2–4 separate devices', 'exact number', 'space 35',
      'final key', 'space 30', 'hammer', '33', 'finishing rank',
      'Finished explorers', 'only one explorer remains'].forEach(function (requirement) {
      assert.ok(steps.includes(requirement), 'missing tutorial detail: ' + requirement);
    });
  });

  await check('The rules popup can launch a tutorial and restores the rules on completion', async function () {
    game.openGuide();
    ids['guide-tutorial-btn'].handlers.click();
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), false);
    assert.strictEqual(ids['tutorial-overlay'].classList.contains('visible'), true);
    assert.strictEqual(game.state.tutorial.returnToGuide, true);
    for (let index = 1; index < game.tutorialSteps.length; index++) {
      ids['tutorial-next-btn'].handlers.click();
      assert.strictEqual(game.state.tutorial.index, index);
    }
    assert.strictEqual(ids['tutorial-next-btn'].textContent, 'LET’S PLAY');
    ids['tutorial-next-btn'].handlers.click();
    assert.strictEqual(ids['tutorial-overlay'].classList.contains('visible'), false);
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    game.closeGuide();
  });

  await check('Tutorial navigation supports back, arrow keys, Escape, and the full-rules link', async function () {
    game.openTutorial(false);
    assert.strictEqual(game.advanceTutorial(-1), false);
    assert.strictEqual(game.advanceTutorial(2), false);
    listeners.keydown({ key: 'ArrowRight' });
    assert.strictEqual(game.state.tutorial.index, 1);
    listeners.keydown({ key: 'ArrowLeft' });
    assert.strictEqual(game.state.tutorial.index, 0);
    ids['tutorial-rules-btn'].handlers.click();
    assert.strictEqual(game.state.tutorial.visible, false);
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), true);
    listeners.keydown({ key: 'Escape' });
    assert.strictEqual(ids['guide-overlay'].classList.contains('visible'), false);
    game.openTutorial(false);
    listeners.keydown({ key: 'Escape' });
    assert.strictEqual(game.state.tutorial.visible, false);
  });

  await check('Rules and tutorial navigation never changes an active explorer or board state', async function () {
    fresh(4);
    game.state.players[0].position = 11;
    const before = JSON.stringify({ current: game.state.current, turns: game.state.turns,
      position: game.state.players[0].position, count: game.state.players.length });
    game.openGuide();
    game.closeGuide();
    game.openTutorial(false);
    game.advanceTutorial(1);
    game.closeTutorial();
    assert.strictEqual(JSON.stringify({ current: game.state.current, turns: game.state.turns,
      position: game.state.players[0].position, count: game.state.players.length }), before);
    game.state.busy = true;
    assert.strictEqual(game.openGuide(), false);
    assert.strictEqual(game.openTutorial(false), false);
    game.state.busy = false;
  });

  await check('The settings page opens from both setup and the game toolbar', async function () {
    fresh();
    ids['settings-btn'].handlers.click();
    assert.strictEqual(ids['settings-overlay'].classList.contains('visible'), true);
    ids['settings-close-btn'].handlers.click();
    assert.strictEqual(ids['settings-overlay'].classList.contains('visible'), false);
    ids['setup-settings-btn'].handlers.click();
    assert.strictEqual(ids['settings-overlay'].classList.contains('visible'), true);
    assert.strictEqual(game.closeSettings(), true);
  });

  await check('Settings enable real Wi-Fi and Bluetooth multiplayer modes', async function () {
    const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
    assert.ok(html.includes('Wi-Fi Multiplayer'));
    assert.ok(html.includes('Bluetooth Multiplayer'));
    assert.ok(html.includes('2–4 devices on the same network'));
    assert.ok(html.includes('id="wifi-count-4"'));
    assert.ok(!html.includes('PLANNED'));
    assert.strictEqual(ids['mode-wifi-btn'].disabled, false);
    assert.strictEqual(ids['mode-bluetooth-btn'].disabled, false);
    assert.strictEqual(game.state.playMode, 'hotseat');
  });

  await check('A Wi-Fi host starts a genuine native socket lobby and displays its address', async function () {
    const events = [];
    const calls = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function () { return true; },
      localAddress: function () { return '192.168.1.27'; },
      hostWifi: function () { calls.push('hostWifi'); },
      disconnect: function () { calls.push('disconnect'); }
    };
    ids['mode-wifi-btn'].handlers.click();
    assert.strictEqual(ids['network-overlay'].classList.contains('visible'), true);
    assert.strictEqual(game.state.playMode, 'wifi');
    ids['network-name'].value = 'Captain Arya';
    assert.strictEqual(game.hostNetwork(), true);
    assert.deepStrictEqual(calls, ['hostWifi']);
    assert.ok(ids['network-status'].textContent.includes('192.168.1.27'));
    events.push('status|waiting');
    assert.strictEqual(game.pollNetwork(), 1);
    assert.ok(ids['network-status'].textContent.includes('192.168.1.27'));
    game.disconnectNetwork();
    assert.strictEqual(intervals.size, 0);
    delete window.KeysClawsNative;
  });

  await check('The Wi-Fi lobby offers two, three, or four explorers without changing Bluetooth', async function () {
    game.openNetwork('wifi');
    assert.strictEqual(ids['wifi-player-picker'].classList.contains('visible'), true);
    assert.strictEqual(game.state.network.expectedPlayers, 2);
    ids['wifi-count-3'].handlers.click();
    assert.strictEqual(game.state.network.expectedPlayers, 3);
    assert.strictEqual(ids['wifi-count-3'].classList.contains('selected'), true);
    ids['wifi-count-4'].handlers.click();
    assert.strictEqual(game.state.network.expectedPlayers, 4);
    assert.strictEqual(ids['wifi-count-4'].getAttribute('aria-pressed'), 'true');
    assert.strictEqual(game.setWifiPlayerCount(1), false);
    assert.strictEqual(game.setWifiPlayerCount(5), false);
    game.openNetwork('bluetooth');
    assert.strictEqual(ids['wifi-player-picker'].classList.contains('visible'), false);
    assert.strictEqual(game.state.network.expectedPlayers, 2);
    game.disconnectNetwork();
  });

  await check('A four-device Wi-Fi host waits for every guest and assigns unique turn ownership', async function () {
    const events = [];
    const sent = [];
    const requested = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function (value) { sent.push(JSON.parse(value)); return true; },
      localAddress: function () { return '192.168.1.44'; },
      hostWifiPlayers: function (count) { requested.push(count); },
      disconnect: function () {}
    };
    game.openNetwork('wifi');
    ids['wifi-count-4'].handlers.click();
    ids['network-name'].value = 'Host Hero';
    assert.strictEqual(game.hostNetwork(), true);
    assert.deepStrictEqual(requested, [4]);
    assert.strictEqual(game.setWifiPlayerCount(3), false);
    events.push('status|connected|1', 'status|connected|2', 'status|connected|3');
    events.push('data|1|' + JSON.stringify({ type: 'HELLO', name: 'River', clientId: 'river-id' }));
    events.push('data|2|' + JSON.stringify({ type: 'HELLO', name: 'Forest', clientId: 'forest-id' }));
    game.pollNetwork();
    assert.strictEqual(sent.filter(function (item) { return item.type === 'LOBBY'; }).length, 2);
    assert.strictEqual(sent.some(function (item) { return item.type === 'START'; }), false);
    events.push('data|3|' + JSON.stringify({ type: 'HELLO', name: 'Violet', clientId: 'violet-id' }));
    game.pollNetwork();
    const start = sent.pop();
    assert.deepStrictEqual(start.names, ['Host Hero', 'River', 'Forest', 'Violet']);
    assert.deepStrictEqual(start.clientIds, ['host', 'river-id', 'forest-id', 'violet-id']);
    assert.strictEqual(game.state.players.length, 4);
    assert.strictEqual(game.handleNetworkMessage({ type: 'ROLL_REQUEST', player: 3, revision: 0 }, 1), false);
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('A Wi-Fi guest synchronizes names, turns, fair host rolls, and stale revisions', async function () {
    const events = [];
    const sent = [];
    const joined = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function (value) { sent.push(JSON.parse(value)); return true; },
      joinWifi: function (address) { joined.push(address); },
      disconnect: function () {}
    };
    game.openNetwork('wifi');
    ids['network-name'].value = 'River Captain';
    ids['network-address'].value = '192.168.1.27';
    assert.strictEqual(game.joinNetwork(), true);
    assert.deepStrictEqual(joined, ['192.168.1.27']);
    events.push('status|connected');
    game.pollNetwork();
    const hello = sent.pop();
    assert.strictEqual(hello.type, 'HELLO');
    assert.strictEqual(hello.name, 'River Captain');
    assert.strictEqual(hello.clientId, game.state.network.clientId);
    events.push('data|' + JSON.stringify({ type: 'START', names: ['Host Hero', 'River Captain'], revision: 0 }));
    game.pollNetwork();
    assert.deepStrictEqual(game.state.players.map(function (player) { return player.name; }),
      ['Host Hero', 'River Captain']);
    assert.strictEqual(game.state.network.localPlayer, 1);
    assert.strictEqual(ids['roll-btn'].disabled, true);
    events.push('data|' + JSON.stringify({ type: 'ROLL', player: 0, value: 3, revision: 1 }));
    game.pollNetwork();
    await new Promise(function (resolve) { setImmediate(resolve); });
    assert.strictEqual(game.state.players[0].position, 11);
    assert.strictEqual(game.state.current, 1);
    assert.strictEqual(ids['roll-btn'].disabled, false);
    assert.strictEqual(game.requestRoll(), true);
    assert.deepStrictEqual(sent.pop(), { type: 'ROLL_REQUEST', player: 1, revision: 1 });
    assert.strictEqual(ids['roll-btn'].disabled, true);
    assert.strictEqual(game.requestRoll(), false);
    assert.strictEqual(sent.length, 0);
    events.push('data|' + JSON.stringify({ type: 'ROLL', player: 1, value: 2, revision: 2 }));
    game.pollNetwork();
    await new Promise(function (resolve) { setImmediate(resolve); });
    assert.strictEqual(game.state.players[1].position, 2);
    assert.strictEqual(game.state.players[1].firstKey, true);
    events.push('data|' + JSON.stringify({ type: 'ROLL', player: 1, value: 5, revision: 2 }));
    game.pollNetwork();
    assert.strictEqual(game.state.players[1].position, 2);
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('The third Wi-Fi guest receives explorer four and accepts synchronized remote renames', async function () {
    const events = [];
    const sent = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function (value) { sent.push(JSON.parse(value)); return true; },
      joinWifi: function () {},
      disconnect: function () {}
    };
    game.openNetwork('wifi');
    ids['network-name'].value = 'Violet';
    ids['network-address'].value = '192.168.1.44';
    assert.strictEqual(game.joinNetwork(), true);
    events.push('status|connected');
    game.pollNetwork();
    const identity = sent.pop().clientId;
    events.push('data|' + JSON.stringify({ type: 'LOBBY', joined: 3, expected: 4 }));
    game.pollNetwork();
    assert.ok(ids['network-status'].textContent.includes('3 of 4'));
    events.push('data|' + JSON.stringify({ type: 'START', names: ['Host', 'River', 'Forest', 'Violet'],
      clientIds: ['host', 'river-id', 'forest-id', identity], revision: 0 }));
    game.pollNetwork();
    assert.strictEqual(game.state.network.localPlayer, 3);
    assert.strictEqual(game.state.players.length, 4);
    events.push('data|' + JSON.stringify({ type: 'NAME', player: 2, name: 'Forest Captain' }));
    game.pollNetwork();
    assert.strictEqual(game.state.players[2].name, 'Forest Captain');
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('The host alone authorizes both connected players’ dice results', async function () {
    const events = [];
    const sent = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function (value) { sent.push(JSON.parse(value)); return true; },
      localAddress: function () { return '10.0.0.8'; },
      hostWifi: function () {},
      disconnect: function () {}
    };
    game.openNetwork('wifi');
    ids['network-name'].value = 'Host Hero';
    game.hostNetwork();
    events.push('status|connected', 'data|' + JSON.stringify({ type: 'HELLO', name: 'Guest Hero' }));
    game.pollNetwork();
    assert.deepStrictEqual(sent.shift(), { type: 'START', names: ['Host Hero', 'Guest Hero'], revision: 0 });
    assert.strictEqual(game.requestRoll(), true);
    const first = sent.shift();
    assert.strictEqual(first.type, 'ROLL');
    assert.strictEqual(first.player, 0);
    assert.strictEqual(first.revision, 1);
    assert.ok(first.value >= 1 && first.value <= 6);
    await new Promise(function (resolve) { setImmediate(resolve); });
    events.push('data|' + JSON.stringify({ type: 'ROLL_REQUEST', player: 1, revision: 1 }));
    game.pollNetwork();
    const second = sent.shift();
    assert.strictEqual(second.type, 'ROLL');
    assert.strictEqual(second.player, 1);
    assert.strictEqual(second.revision, 2);
    await new Promise(function (resolve) { setImmediate(resolve); });
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('Bluetooth multiplayer lists paired devices and joins through the native RFCOMM bridge', async function () {
    const joined = [];
    window.KeysClawsNative = {
      poll: function () { return ''; },
      send: function () { return true; },
      bondedDevices: function () { return '[AA:BB:CC:DD:EE:FF, 01:23:45:67:89:AB]'; },
      joinBluetooth: function (address) { joined.push(address); },
      hostBluetooth: function () { joined.push('HOST'); },
      disconnect: function () {}
    };
    ids['mode-bluetooth-btn'].handlers.click();
    assert.ok(ids['network-devices'].innerHTML.includes('AA:BB:CC:DD:EE:FF'));
    assert.strictEqual(ids['network-refresh-btn'].classList.contains('visible'), true);
    ids['network-address'].value = 'not-a-device';
    assert.strictEqual(game.joinNetwork(), false);
    ids['network-address'].value = 'AA:BB:CC:DD:EE:FF';
    assert.strictEqual(game.joinNetwork(), true);
    assert.deepStrictEqual(joined, ['AA:BB:CC:DD:EE:FF']);
    game.disconnectNetwork();
    game.openNetwork('bluetooth');
    assert.strictEqual(game.hostNetwork(), true);
    assert.deepStrictEqual(joined, ['AA:BB:CC:DD:EE:FF', 'HOST']);
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('Nearby multiplayer reports connection errors without pretending to connect', async function () {
    game.openNetwork('wifi');
    assert.strictEqual(game.hostNetwork(), false);
    assert.strictEqual(game.state.network.connected, false);
    assert.strictEqual(ids['network-status'].classList.contains('error'), true);
    ids['network-back-btn'].handlers.click();
    assert.strictEqual(game.state.playMode, 'hotseat');
  });

  await check('A disconnected multiplayer game cannot silently continue on one phone', async function () {
    const events = [];
    window.KeysClawsNative = {
      poll: function () { return events.shift() || ''; },
      send: function () { return true; },
      localAddress: function () { return '10.0.0.8'; },
      hostWifi: function () {},
      disconnect: function () {}
    };
    game.openNetwork('wifi');
    game.hostNetwork();
    events.push('status|connected', 'data|' + JSON.stringify({ type: 'HELLO', name: 'Friend' }));
    game.pollNetwork();
    assert.strictEqual(game.state.started, true);
    events.push('error|java.io.EOFException');
    game.pollNetwork();
    assert.strictEqual(game.state.network.connected, false);
    assert.strictEqual(ids['roll-btn'].disabled, true);
    assert.strictEqual(game.requestRoll(), false);
    game.disconnectNetwork();
    delete window.KeysClawsNative;
  });

  await check('The settings sound switch remains synchronized with the toolbar', async function () {
    fresh();
    game.openSettings();
    assert.strictEqual(ids['settings-sound-btn'].textContent, 'OFF');
    ids['settings-sound-btn'].handlers.click();
    assert.strictEqual(game.state.sound, true);
    assert.strictEqual(ids['settings-sound-btn'].textContent, 'ON');
    assert.strictEqual(ids['sound-btn'].textContent, '♪');
    ids['sound-btn'].handlers.click();
    assert.strictEqual(game.state.sound, false);
    assert.strictEqual(ids['settings-sound-btn'].textContent, 'OFF');
    game.closeSettings();
  });

  await check('Living-jungle scenery has its own persistent switch and follows the animation safety setting', async function () {
    assert.strictEqual(ids['settings-jungle-btn'].textContent, 'ON');
    assert.strictEqual(ids.board.getAttribute('data-living-jungle'), 'true');
    ids['settings-jungle-btn'].handlers.click();
    assert.strictEqual(game.state.livingJungle, false);
    assert.strictEqual(ids['settings-jungle-btn'].textContent, 'OFF');
    assert.strictEqual(ids['settings-jungle-btn'].getAttribute('aria-pressed'), 'false');
    assert.strictEqual(ids.board.getAttribute('data-living-jungle'), 'false');
    game.setLivingJungleEnabled(true);
    game.setAnimationsEnabled(false);
    assert.strictEqual(ids.board.getAttribute('data-living-jungle'), 'false');
    game.setAnimationsEnabled(true);
    assert.strictEqual(ids.board.getAttribute('data-living-jungle'), 'true');
  });

  await check('The offline river, waterfall, and bird soundtrack loops softly and obeys both sound controls', async function () {
    const activity = [];
    function AmbientAudio(source) {
      this.source = source;
      this.volume = 0;
      this.loop = false;
    }
    AmbientAudio.prototype.play = function () {
      activity.push('play:' + this.source);
      return { catch: function () {} };
    };
    AmbientAudio.prototype.pause = function () { activity.push('pause:' + this.source); };
    window.Audio = AmbientAudio;
    game.state.ambientClip = null;
    game.state.ambientPlaying = false;
    game.state.ambience = true;
    game.state.sound = true;
    game.beginGame(1);
    assert.strictEqual(game.state.ambientClip.source, 'sounds/jungle_ambience.mp3');
    assert.strictEqual(game.state.ambientClip.loop, true);
    assert.strictEqual(game.state.ambientClip.volume, .28);
    assert.strictEqual(game.state.ambientPlaying, true);
    assert.deepStrictEqual(activity, ['play:sounds/jungle_ambience.mp3']);
    ids['settings-ambience-btn'].handlers.click();
    assert.strictEqual(game.state.ambience, false);
    assert.strictEqual(ids['settings-ambience-btn'].textContent, 'OFF');
    assert.strictEqual(game.state.ambientPlaying, false);
    assert.strictEqual(activity[activity.length - 1], 'pause:sounds/jungle_ambience.mp3');
    game.setAmbientSoundEnabled(true);
    assert.strictEqual(game.state.ambientPlaying, true);
    game.setSoundEnabled(false);
    assert.strictEqual(game.state.ambientPlaying, false);
    game.setSoundEnabled(true);
    assert.strictEqual(game.state.ambientPlaying, true);
    document.hidden = true;
    listeners.visibilitychange();
    assert.strictEqual(game.state.ambientPlaying, false);
    document.hidden = false;
    listeners.visibilitychange();
    assert.strictEqual(game.state.ambientPlaying, true);
    game.setSoundEnabled(false);
    game.state.ambientClip = null;
    game.state.ambientPlaying = false;
    delete window.Audio;
  });

  await check('Jungle ambience never autoplays before an adventure begins', async function () {
    let played = 0;
    window.Audio = function () {
      this.play = function () { played++; };
      this.pause = function () {};
    };
    game.state.started = false;
    game.state.sound = true;
    game.state.ambience = true;
    game.state.ambientClip = null;
    game.state.ambientPlaying = false;
    assert.strictEqual(game.syncAmbientSound(), false);
    assert.strictEqual(played, 0);
    ids['start-btn'].handlers.click();
    assert.strictEqual(played, 1);
    game.setSoundEnabled(false);
    game.state.ambientClip = null;
    delete window.Audio;
  });

  await check('Obstacle animations can be disabled without changing gameplay rules', async function () {
    game.setAnimationsEnabled(false);
    const player = fresh();
    player.position = 15;
    await game.takeRoll(2);
    assert.strictEqual(player.position, 10);
    assert.strictEqual(game.state.motionFrames, 0);
    assert.strictEqual(ids['settings-animation-btn'].textContent, 'OFF');
    assert.deepStrictEqual(game.state.visualEvents.map(function (event) {
      return event.kind;
    }), ['lion', 'explorer_falls', 'cry', 'recovery']);
    game.setAnimationsEnabled(true);
    assert.strictEqual(ids['settings-animation-btn'].textContent, 'ON');
  });

  await check('Slow, normal, and fast settings change real player movement speed', async function () {
    game.setMovementSpeed('fast');
    assert.strictEqual(ids['speed-fast-btn'].classList.contains('selected'), true);
    const player = fresh();
    const before = waitDurations.length;
    await game.takeRoll(1);
    const delays = waitDurations.slice(before);
    assert.strictEqual(player.position, 1);
    assert.ok(delays.includes(18));
    assert.ok(delays.includes(33));
    ids['speed-normal-btn'].handlers.click();
    assert.strictEqual(game.state.movementSpeed, 'normal');
    ids['speed-slow-btn'].handlers.click();
    assert.strictEqual(game.state.movementSpeed, 'slow');
    assert.throws(function () { game.setMovementSpeed('turbo'); }, RangeError);
  });

  await check('Game settings are persisted and restored on the device', async function () {
    const saved = Object.create(null);
    window.localStorage = {
      getItem: function (key) { return saved[key] || null; },
      setItem: function (key, value) { saved[key] = value; }
    };
    game.setMovementSpeed('normal');
    game.setAnimationsEnabled(false);
    game.setAmbientSoundEnabled(false);
    game.setLivingJungleEnabled(false);
    game.setSoundEnabled(false);
    game.state.movementSpeed = 'slow';
    game.state.animations = true;
    game.state.ambience = true;
    game.state.livingJungle = true;
    assert.strictEqual(game.loadSettings(), true);
    assert.strictEqual(game.state.movementSpeed, 'normal');
    assert.strictEqual(game.state.animations, false);
    assert.strictEqual(game.state.ambience, false);
    assert.strictEqual(game.state.livingJungle, false);
    assert.strictEqual(game.state.sound, false);
    delete window.localStorage;
    game.setMovementSpeed('slow');
    game.setAnimationsEnabled(true);
    game.setAmbientSoundEnabled(true);
    game.setLivingJungleEnabled(true);
  });

  await check('Medical stations play a relieved treatment sound', async function () {
    let player = fresh();
    player.position = 9;
    await game.takeRoll(1);
    assert.strictEqual(game.state.lastSound, 'relief');
    player = fresh();
    player.position = 23;
    await game.takeRoll(1);
    assert.strictEqual(game.state.lastSound, 'relief');
  });

  await check('Invalid forced dice values cannot advance a player', async function () {
    const player = fresh();
    await assert.rejects(game.takeRoll(7), RangeError);
    await assert.rejects(game.takeRoll(0), RangeError);
    assert.strictEqual(player.position, 0);
    assert.strictEqual(game.state.busy, false);
  });

  await check('Every game event has a bundled, nonempty offline audio clip', async function () {
    ['lion', 'wolf', 'fight', 'cry', 'relief', 'hurray', 'win', 'good', 'bad', 'step',
      'knife_pickup', 'axe_pickup', 'hammer_pickup', 'knife_use', 'axe_use',
      'hammer_hit', 'lock_break']
      .forEach(function (effect) {
        const file = path.join(ASSET_ROOT, 'sounds', effect + '.mp3');
        assert.ok(fs.existsSync(file), effect + ' clip is missing');
        assert.ok(fs.statSync(file).size > 1000, effect + ' clip is unexpectedly small');
      });
    ['gate_open', 'gate_close'].forEach(function (effect) {
      const file = path.join(ASSET_ROOT, 'sounds', effect + '.wav');
      assert.ok(fs.existsSync(file), effect + ' original gate audio is missing');
      assert.ok(fs.statSync(file).size > 100000, effect + ' original audio is unexpectedly small');
    });
    const ambience = path.join(ASSET_ROOT, 'sounds', 'jungle_ambience.mp3');
    assert.ok(fs.existsSync(ambience), 'the offline jungle ambience soundtrack is missing');
    assert.ok(fs.statSync(ambience).size > 100000, 'the jungle ambience track is unexpectedly short');
  });

  await check('Approved independent jungle artwork and the correct river topology are bundled', async function () {
    const manifest = JSON.parse(fs.readFileSync(path.join(ASSET_ROOT, 'art', 'manifest.json'), 'utf8'));
    assert.deepStrictEqual(manifest.shortcut_bridges, [[3, 11], [12, 18], [25, 29]]);
    assert.strictEqual(manifest.board_numbers_visible, false);
    assert.strictEqual(manifest.background_reference_upload, '1000254601.png');
    assert.strictEqual(manifest.offline_jungle_ambience, 'sounds/jungle_ambience.mp3');
    assert.ok(manifest.image_native_depth_illusion.includes('2.5D'));
    assert.ok(manifest.living_jungle_effects.includes('animated waterfalls'));
    assert.deepStrictEqual(manifest.legal_turns, [[7, 8], [14, 15], [21, 22], [27, 28]]);
    assert.strictEqual(manifest.states.length, 15);
    assert.strictEqual(manifest.hammer.space, 33);
    assert.strictEqual(manifest.hammer.requires_exact_landing, true);
    assert.strictEqual(manifest.hammer.works_only_at_final_gate, 35);
    assert.strictEqual(manifest.hammer.opens_first_gate, false);
    assert.strictEqual(manifest.hammer.protects_against_animals, false);
    assert.deepStrictEqual(manifest.ranked_multiplayer, {
      continues_after_first_finisher: true,
      skips_finished_explorers: true,
      automatic_last_place: true,
      maximum_explorers: 4
    });
    assert.deepStrictEqual(manifest.encounter_outcomes, {
      human_victory: 'animal_falls',
      animal_victory: 'explorer_falls',
      reuses_approved_transparent_artwork: true
    });
    assert.strictEqual(manifest.explorer_avatar_frame_size, 256);
    assert.deepStrictEqual(manifest.explorer_avatars.map(function (avatar) {
      return avatar.id;
    }), ['ruby', 'river', 'forest', 'violet']);
    manifest.states.forEach(function (entry) {
      assert.ok(fs.existsSync(path.join(ASSET_ROOT, entry.file)), entry.file + ' is missing');
      assert.strictEqual(entry.real_alpha, true);
    });
    assert.ok(manifest.states.some(function (entry) {
      return entry.file === 'art/gate_half_closing.png' && entry.transparent_gate_passage;
    }));
  });

  await check('Scenario sounds play their own audible bundled media files', async function () {
    const requested = [];
    function FakeAudio(source) { this.source = source; this.volume = 0; }
    FakeAudio.prototype.cloneNode = function () { return new FakeAudio(this.source); };
    FakeAudio.prototype.play = function () {
      requested.push({ source: this.source, volume: this.volume });
      return { catch: function () {} };
    };
    window.Audio = FakeAudio;
    game.state.clips = {};
    game.state.sound = true;
    ['cry', 'relief', 'hurray', 'lion', 'wolf', 'fight', 'gate_open', 'gate_close',
      'knife_pickup', 'axe_pickup', 'hammer_pickup', 'knife_use', 'axe_use',
      'hammer_hit', 'lock_break'].forEach(function (effect) {
      game.playSound(effect);
    });
    assert.deepStrictEqual(requested.map(function (item) { return item.source; }), [
      'sounds/cry.mp3', 'sounds/relief.mp3', 'sounds/hurray.mp3',
      'sounds/lion.mp3', 'sounds/wolf.mp3', 'sounds/fight.mp3',
      'sounds/gate_open.wav', 'sounds/gate_close.wav',
      'sounds/knife_pickup.mp3', 'sounds/axe_pickup.mp3', 'sounds/hammer_pickup.mp3',
      'sounds/knife_use.mp3', 'sounds/axe_use.mp3', 'sounds/hammer_hit.mp3',
      'sounds/lock_break.mp3'
    ]);
    requested.forEach(function (item) { assert.ok(item.volume >= .9); });
    delete window.Audio;
    game.state.sound = false;
    game.state.clips = {};
  });

  await check('Audio playback is unlocked during the actual start-button gesture', async function () {
    let resumed = 0;
    window.AudioContext = function () {
      this.state = 'suspended';
      this.resume = function () { resumed++; this.state = 'running'; };
    };
    game.state.audio = null;
    game.state.sound = true;
    ids['start-btn'].handlers.click();
    assert.strictEqual(resumed, 1);
    assert.strictEqual(game.state.audio.state, 'running');
    delete window.AudioContext;
    game.state.audio = null;
    game.state.sound = false;
  });

  await check('Offline animal, battle, crying, relief, and celebration sounds synthesize successfully', async function () {
    const started = [];
    function parameter() { return { setValueAtTime() {}, exponentialRampToValueAtTime() {}, value: 0 }; }
    function node() { return { connect() {}, start(time) { started.push(time); }, stop() {}, frequency: parameter(), gain: parameter(), Q: parameter() }; }
    game.state.audio = {
      currentTime: 0, sampleRate: 8000, state: 'running', destination: {},
      createOscillator: node, createGain: node, createBufferSource: node,
      createBiquadFilter: node,
      createBuffer: function (channels, length) { return { getChannelData: function () { return new Float32Array(length); } }; }
    };
    game.state.sound = true;
    ['lion', 'wolf', 'fight', 'cry', 'relief', 'hurray', 'win', 'good', 'bad',
      'step', 'gate_open', 'gate_close', 'knife_pickup', 'axe_pickup',
      'hammer_pickup', 'knife_use', 'axe_use', 'hammer_hit',
      'lock_break'].forEach(function (effect) {
      const before = started.length;
      game.playSound(effect);
      assert.ok(started.length > before, effect + ' produced no audio');
      assert.strictEqual(game.state.lastSound, effect);
      assert.strictEqual(game.state.sound, true);
    });
    game.state.sound = false;
    game.state.audio = null;
  });

  await check('Custom explorer names entered during setup are used in a new game', async function () {
    game.setPlayerName(0, 'Arya');
    game.setPlayerName(1, 'Rohit');
    game.beginGame(2);
    assert.strictEqual(game.state.players[0].name, 'Arya');
    assert.strictEqual(game.state.players[1].name, 'Rohit');
    assert.ok(ids['active-player'].innerHTML.includes('Arya'));
  });

  await check('The setup input event changes the selected explorer name', async function () {
    ids['player-preview'].handlers.input({
      target: {
        getAttribute: function (name) {
          return name === 'data-player-index' ? '0' : null;
        },
        value: 'Captain Arya'
      }
    });
    game.beginGame(1);
    assert.strictEqual(game.state.players[0].name, 'Captain Arya');
  });

  await check('An explorer can be renamed while the game is in progress', async function () {
    fresh(2);
    game.openRename(1);
    assert.strictEqual(ids['rename-overlay'].classList.contains('visible'), true);
    ids['rename-input'].value = '  Brave Explorer  ';
    ids['rename-save-btn'].handlers.click();
    assert.strictEqual(game.state.players[1].name, 'Brave Explorer');
    assert.strictEqual(game.state.customNames[1], 'Brave Explorer');
    assert.strictEqual(ids['rename-overlay'].classList.contains('visible'), false);
  });

  await check('Explorer names are escaped and limited to 22 characters', async function () {
    fresh();
    const name = game.setPlayerName(0, '<Arya> & Explorer With A Very Long Name');
    assert.strictEqual(name.length, 22);
    assert.ok(ids['active-player'].innerHTML.includes('&lt;Arya&gt;'));
    assert.ok(!ids['active-player'].innerHTML.includes('<Arya>'));
  });

  console.log(JSON.stringify({ passed: results.length, tests: results }, null, 2));
}()).catch(function (error) {
  console.error(error.stack || error);
  process.exitCode = 1;
});
