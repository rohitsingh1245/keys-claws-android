#!/usr/bin/env node
'use strict';

// Exercise four independent game instances through three actual TCP sockets.
// The JavaScript bridge uses the same two-byte UTF frame shape as Android's
// DataInputStream/DataOutputStream transport.

const assert = require('assert');
const fs = require('fs');
const net = require('net');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, 'game.js'), 'utf8');
const channel = { server: null, port: 0, bridges: [] };

class ClassList {
  constructor() { this.values = new Set(); }
  add(value) { this.values.add(value); }
  remove(value) { this.values.delete(value); }
  contains(value) { return this.values.has(value); }
  toggle(value, force) {
    const present = force === undefined ? !this.values.has(value) : force;
    if (present) this.values.add(value); else this.values.delete(value);
    return present;
  }
}

function bridge() {
  const events = [];
  const sockets = [];
  let hosting = false;
  let ownServer = null;

  function attach(connection, slot) {
    let buffer = Buffer.alloc(0);
    sockets.push(connection);
    connection.on('data', function (piece) {
      buffer = Buffer.concat([buffer, piece]);
      while (buffer.length >= 2 && buffer.length >= buffer.readUInt16BE(0) + 2) {
        const size = buffer.readUInt16BE(0);
        events.push('data|' + (hosting ? slot + '|' : '') +
          buffer.subarray(2, size + 2).toString('utf8'));
        buffer = buffer.subarray(size + 2);
      }
    });
    connection.on('error', function (error) { events.push('error|' + error.message); });
    connection.on('close', function () { events.push('error|connection closed'); });
    events.push('status|connected' + (hosting ? '|' + slot : ''));
  }

  const result = {
    poll: function () { return events.shift() || ''; },
    send: function (message) {
      const connected = sockets.filter(function (socket) { return !socket.destroyed; });
      if (!connected.length) return false;
      const text = Buffer.from(message, 'utf8');
      const packet = Buffer.alloc(text.length + 2);
      packet.writeUInt16BE(text.length, 0);
      text.copy(packet, 2);
      connected.forEach(function (socket) { socket.write(packet); });
      return true;
    },
    localAddress: function () { return '127.0.0.1'; },
    hostWifiPlayers: function (expected) {
      assert.ok(expected >= 2 && expected <= 4);
      hosting = true;
      ownServer = net.createServer(function (connection) {
        const slot = sockets.length + 1;
        if (slot >= expected) {
          connection.destroy();
          return;
        }
        attach(connection, slot);
      });
      channel.server = ownServer;
      ownServer.listen(0, '127.0.0.1', function () {
        channel.port = ownServer.address().port;
        events.push('status|waiting');
      });
      return 'started';
    },
    joinWifi: function (address) {
      const connection = net.createConnection({ host: address, port: channel.port });
      connection.once('connect', function () { attach(connection, 0); });
      connection.on('error', function (error) { events.push('error|' + error.message); });
      return 'started';
    },
    disconnect: function () {
      sockets.forEach(function (socket) { socket.destroy(); });
      if (ownServer && ownServer.listening) ownServer.close();
    }
  };
  channel.bridges.push(result);
  return result;
}

function createGame(nativeBridge) {
  const ids = Object.create(null);
  const listeners = Object.create(null);

  class Element {
    constructor(tag, id) {
      this.tagName = tag;
      this.id = id || '';
      this.attrs = Object.create(null);
      this.children = [];
      this.handlers = Object.create(null);
      this.classList = new ClassList();
      this.style = {};
      this.textContent = '';
      this.innerHTML = '';
      this.disabled = false;
      this.value = '';
      if (id) ids[id] = this;
    }
    setAttribute(key, value) {
      this.attrs[key] = String(value);
      if (key === 'id') ids[String(value)] = this;
    }
    getAttribute(key) { return this.attrs[key] || null; }
    addEventListener(key, callback) { this.handlers[key] = callback; }
    appendChild(element) { this.children.push(element); return element; }
    focus() {}
    select() {}
    getTotalLength() { return 100; }
    getPointAtLength(distance) {
      const points = (this.attrs.d || '').match(/-?\d+(?:\.\d+)?/g).map(Number);
      const ratio = distance / 100;
      return {
        x: points[0] + (points[points.length - 2] - points[0]) * ratio,
        y: points[1] + (points[points.length - 1] - points[1]) * ratio
      };
    }
  }

  [
    'board', 'active-player', 'position-line', 'inventory', 'roll-btn', 'die-face',
    'turn-hint', 'players-list', 'top-message', 'event-banner', 'setup-overlay',
    'victory-overlay', 'winner-line', 'victory-stats', 'victory-rankings',
    'player-preview', 'start-btn',
    'restart-btn', 'sound-btn', 'play-again-btn', 'new-game-btn', 'rename-overlay',
    'rename-input', 'rename-label', 'rename-save-btn', 'rename-cancel-btn',
    'scene-overlay', 'scene-title', 'scene-stage', 'scene-caption', 'settings-btn',
    'setup-settings-btn', 'settings-overlay', 'settings-close-btn',
    'settings-sound-btn', 'settings-animation-btn', 'mode-hotseat-btn',
    'mode-wifi-btn', 'mode-bluetooth-btn', 'speed-slow-btn', 'speed-normal-btn',
    'speed-fast-btn', 'network-overlay', 'network-title', 'network-symbol',
    'network-instructions', 'network-name', 'network-address',
    'network-address-label', 'network-devices', 'network-refresh-btn',
    'network-status', 'network-host-btn', 'network-join-btn', 'network-back-btn',
    'wifi-player-picker', 'wifi-count-2', 'wifi-count-3', 'wifi-count-4',
    'help-btn', 'field-guide-btn', 'setup-guide-btn', 'setup-tutorial-btn',
    'settings-guide-btn', 'guide-overlay', 'rules-frame', 'guide-dismiss-btn',
    'guide-close-btn', 'guide-tutorial-btn', 'tutorial-overlay', 'tutorial-progress',
    'tutorial-art', 'tutorial-badge', 'tutorial-title', 'tutorial-description',
    'tutorial-tip', 'tutorial-back-btn', 'tutorial-next-btn', 'tutorial-close-btn',
    'tutorial-rules-btn'
  ].forEach(function (id) { new Element('div', id); });

  const choices = [1, 2, 3, 4].map(function (count) {
    const element = new Element('button');
    element.setAttribute('data-count', count);
    return element;
  });

  const browser = {
    readyState: 'loading',
    createElementNS: function (_, tag) { return new Element(tag); },
    getElementById: function (id) { return ids[id] || null; },
    addEventListener: function (event, callback) { listeners[event] = callback; },
    querySelectorAll: function (selector) {
      return selector === '.count-choice' ? choices : [];
    }
  };

  const activeIntervals = new Set();
  const sandbox = {
    document: browser,
    window: { KeysClawsNative: nativeBridge },
    setTimeout: function (callback) { queueMicrotask(callback); return 1; },
    setInterval: function (callback) {
      const timer = setInterval(callback, 2);
      activeIntervals.add(timer);
      return timer;
    },
    clearInterval: function (timer) {
      clearInterval(timer);
      activeIntervals.delete(timer);
    },
    Uint32Array: Uint32Array
  };
  vm.runInNewContext(source, sandbox, { filename: 'game.js' });
  listeners.DOMContentLoaded();
  const game = sandbox.window.KeysAndClaws;
  game.state.sound = false;
  return { game: game, ids: ids, timers: activeIntervals };
}

async function waitUntil(description, predicate) {
  const end = Date.now() + 3500;
  while (Date.now() < end) {
    if (predicate()) return;
    await new Promise(function (resolve) { setTimeout(resolve, 5); });
  }
  throw new Error('Timed out waiting for ' + description);
}

(async function main() {
  const transports = [bridge(), bridge(), bridge(), bridge()];
  const instances = transports.map(createGame);
  const host = instances[0];
  const names = ['Host Explorer', 'River Explorer', 'Forest Explorer', 'Violet Explorer'];

  try {
    host.game.openNetwork('wifi');
    host.ids['wifi-count-4'].handlers.click();
    host.ids['network-name'].value = names[0];
    assert.strictEqual(host.game.hostNetwork(), true);
    await waitUntil('TCP listener', function () { return channel.port > 0; });

    for (let index = 1; index < instances.length; index++) {
      const guest = instances[index];
      guest.game.openNetwork('wifi');
      guest.ids['network-name'].value = names[index];
      guest.ids['network-address'].value = '127.0.0.1';
      assert.strictEqual(guest.game.joinNetwork(), true);
      await waitUntil('guest ' + index + ' TCP connection', function () {
        return guest.game.state.network.connected;
      });
    }

    await waitUntil('four synchronized game instances', function () {
      return instances.every(function (item) {
        return item.game.state.started && item.game.state.players.length === 4 &&
          item.game.state.network.connected;
      });
    });
    instances.forEach(function (item, index) {
      assert.deepStrictEqual(Array.from(item.game.state.players, function (player) {
        return player.name;
      }), names);
      assert.strictEqual(item.game.state.network.localPlayer, index);
      assert.strictEqual(item.ids['roll-btn'].disabled, index !== 0);
    });

    instances[2].game.openRename(2);
    instances[2].ids['rename-input'].value = 'Forest Captain';
    instances[2].ids['rename-save-btn'].handlers.click();
    names[2] = 'Forest Captain';
    await waitUntil('guest rename broadcast to every device', function () {
      return instances.every(function (item) {
        return item.game.state.players[2].name === 'Forest Captain';
      });
    });

    transports[1].send(JSON.stringify({ type: 'ROLL_REQUEST', player: 2, revision: 0 }));
    await new Promise(function (resolve) { setTimeout(resolve, 35); });
    assert.strictEqual(host.game.state.network.revision, 0);

    async function sharedTurn(player, value, expectedPosition, description, prepare) {
      if (prepare) instances.forEach(function (item) { prepare(item.game.state.players[player]); });
      host.game.state.players[player].diceBag = [value];
      const previous = host.game.state.turns;
      instances.forEach(function (item, index) {
        assert.strictEqual(item.ids['roll-btn'].disabled, index !== player);
      });
      assert.strictEqual(instances[player].game.requestRoll(), true);
      await waitUntil(description, function () {
        return instances.every(function (item) {
          return item.game.state.turns === previous + 1 && !item.game.state.busy;
        });
      });
      instances.forEach(function (item) {
        assert.strictEqual(item.game.state.players[player].position, expectedPosition);
        assert.strictEqual(item.game.state.network.revision, previous + 1);
      });
    }

    await sharedTurn(0, 2, 2, 'host collects the first key');
    await sharedTurn(1, 3, 11, 'first guest crosses the 3-to-11 bridge');
    await sharedTurn(2, 1, 1, 'second guest takes the third explorer turn');
    await sharedTurn(3, 2, 2, 'third guest takes the fourth explorer turn');
    await sharedTurn(0, 1, 29, 'host crosses the 25-to-29 river bridge', function (player) {
      player.position = 24;
      player.knife = false;
      player.axe = false;
    });
    await sharedTurn(1, 1, 17, 'first guest defeats the lion with an axe', function (player) {
      player.position = 16;
      player.knife = false;
      player.axe = true;
    });
    await sharedTurn(2, 1, 24, 'second guest falls back from the wolf', function (player) {
      player.position = 26;
      player.knife = false;
      player.axe = true;
    });
    await sharedTurn(3, 1, 30, 'third guest falls back from the final lock', function (player) {
      player.position = 34;
      player.finalKey = false;
      player.hammer = false;
    });

    await sharedTurn(0, 1, 33, 'host collects the space-33 hammer on all four devices', function (player) {
      player.position = 32;
      player.hammer = false;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.players[0].hammer, true);
      assert.strictEqual(item.game.state.players[1].hammer, false);
    });

    await sharedTurn(1, 3, 34, 'first guest passes space 33 without collecting a hammer', function (player) {
      player.position = 31;
      player.hammer = false;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.players[1].hammer, false);
    });

    await sharedTurn(2, 2, 32, 'second guest continues independently before the hammer gate', function (player) {
      player.position = 30;
      player.hammer = false;
    });

    await sharedTurn(3, 1, 33, 'third guest collects a separate personal hammer', function (player) {
      player.position = 32;
      player.hammer = false;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.players[0].hammer, true);
      assert.strictEqual(item.game.state.players[3].hammer, true);
      assert.strictEqual(item.game.state.players[2].hammer, false);
    });

    await sharedTurn(0, 1, 35, 'the host breaks the final lock and earns first place while the race continues', function (player) {
      player.position = 34;
      player.finalKey = false;
      player.hammer = true;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.won, false);
      assert.strictEqual(item.game.state.players[0].finishMethod, 'hammer');
      assert.strictEqual(item.game.state.players[0].rank, 1);
      assert.strictEqual(item.game.state.players[0].finished, true);
      assert.strictEqual(item.game.state.current, 1);
      assert.strictEqual(item.ids['victory-overlay'].classList.contains('visible'), false);
      assert.ok(item.ids['players-list'].innerHTML.includes('1st'));
    });

    await sharedTurn(1, 1, 35, 'first guest unlocks HOME and earns synchronized second place', function (player) {
      player.position = 34;
      player.finalKey = true;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.players[1].rank, 2);
      assert.strictEqual(item.game.state.players[1].finished, true);
      assert.strictEqual(item.game.state.current, 2);
      assert.strictEqual(item.game.state.won, false);
    });

    await sharedTurn(2, 1, 33, 'second guest collects a hammer while two finished explorers wait', function (player) {
      player.position = 32;
      player.hammer = false;
    });
    await sharedTurn(3, 1, 34, 'last guest advances and finished host and guest are skipped', function (player) {
      player.position = 33;
      player.hammer = true;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.current, 2);
      assert.strictEqual(item.game.state.won, false);
    });

    await sharedTurn(2, 1, 35, 'second guest takes third place and the final explorer automatically ranks fourth', function (player) {
      player.position = 34;
      player.finalKey = false;
      player.hammer = true;
    });
    instances.forEach(function (item) {
      assert.strictEqual(item.game.state.won, true);
      assert.deepStrictEqual(Array.from(item.game.state.rankings), [0, 1, 2, 3]);
      assert.deepStrictEqual(Array.from(item.game.state.players, function (player) {
        return player.rank;
      }), [1, 2, 3, 4]);
      assert.strictEqual(item.game.state.players[3].lastPlace, true);
      assert.strictEqual(item.ids['victory-overlay'].classList.contains('visible'), true);
      assert.ok(item.ids['victory-rankings'].innerHTML.includes('4th'));
      assert.ok(item.ids['winner-line'].textContent.includes(names[0]));
    });

    host.ids['play-again-btn'].handlers.click();
    await waitUntil('all four devices restart with their assigned explorer', function () {
      return instances.every(function (item, index) {
        return item.game.state.turns === 0 && item.game.state.network.revision === 0 &&
          item.game.state.network.localPlayer === index &&
          item.game.state.rankings.length === 0 &&
          item.game.state.players.every(function (player) {
            return player.hammer === false && player.rank === 0 && player.finished === false;
          });
      });
    });

    process.stdout.write(JSON.stringify({
      passed: true,
      transport: 'three actual loopback TCP sockets',
      independently_running_game_instances: 4,
      host_devices: 1,
      guest_devices: 3,
      synchronized_turns: 17,
      synchronized_rules: ['first key', '3-to-11 bridge', '25-to-29 river bridge',
        'axe defeats lion', 'axe does not defeat wolf', 'final lock returns to 30',
        'space-33 hammer collection is synchronized and isolated',
        'passing space 33 cannot collect the hammer',
        'hammer final-lock victory earns first place without ending the race',
        'second-place finisher is skipped on every later turn',
        'last two explorers compete for third and fourth place',
        'all four final rankings synchronize across every device'],
      host_controls_dice: true,
      turn_impersonation_rejected: true,
      guest_renames_broadcast_to_all_devices: true,
      four_player_restart_synchronized: true,
      ranked_finish_order: [1, 2, 3, 4],
      finished_explorers_skipped: true,
      automatic_last_place: true
    }, null, 2) + '\n');
  } finally {
    instances.forEach(function (item) {
      item.game.disconnectNetwork();
      item.timers.forEach(clearInterval);
    });
    if (channel.server && channel.server.listening) channel.server.close();
  }
}()).catch(function (error) {
  console.error(error.stack || error);
  process.exitCode = 1;
});
