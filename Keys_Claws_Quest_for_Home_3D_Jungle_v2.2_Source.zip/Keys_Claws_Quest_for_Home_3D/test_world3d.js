#!/usr/bin/env node
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, 'world3d.js'), 'utf8');
const page = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const checks = [];

function check(name, operation) {
  operation();
  checks.push(name);
}

class ClassList {
  constructor() { this.values = new Set(); }
  add(value) { this.values.add(value); }
  remove(value) { this.values.delete(value); }
  contains(value) { return this.values.has(value); }
}

class Element {
  constructor(name, id) {
    this.tagName = name;
    this.id = id || '';
    this.className = '';
    this.classList = new ClassList();
    this.children = [];
    this.handlers = Object.create(null);
    this.attributes = Object.create(null);
    this.style = Object.create(null);
    this.textContent = '';
    this.innerHTML = '';
  }
  appendChild(child) { this.children.push(child); return child; }
  addEventListener(name, handler) { this.handlers[name] = handler; }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] || null; }
}

function createGl(failingShaders) {
  let nextBuffer = 0;
  const gl = {
    VERTEX_SHADER: 35633, FRAGMENT_SHADER: 35632,
    COMPILE_STATUS: 35713, LINK_STATUS: 35714,
    ARRAY_BUFFER: 34962, STATIC_DRAW: 35044, FLOAT: 5126,
    TRIANGLES: 4, COLOR_BUFFER_BIT: 16384, DEPTH_BUFFER_BIT: 256,
    DEPTH_TEST: 2929, CULL_FACE: 2884, BACK: 1029,
    shaders: [], buffers: [], draws: [], enabled: [], uniforms: [],
    viewports: [], attributes: [], currentModel: null, currentGlow: 0, currentOpacity: 1,
    boundBuffer: null,
    createShader(type) {
      const shader = { type, source: '' };
      this.shaders.push(shader);
      return shader;
    },
    shaderSource(shader, value) { shader.source = value; },
    compileShader() {},
    getShaderParameter() { return !failingShaders; },
    getShaderInfoLog() { return 'mock shader compilation failure'; },
    createProgram() { return { shaders: [] }; },
    attachShader(program, shader) { program.shaders.push(shader); },
    linkProgram() {},
    getProgramParameter() { return true; },
    getProgramInfoLog() { return ''; },
    useProgram(program) { this.program = program; },
    getAttribLocation(program, name) {
      return { aPosition: 0, aNormal: 1, aColor: 2 }[name];
    },
    getUniformLocation(program, name) { return { name }; },
    createBuffer() {
      const buffer = { id: ++nextBuffer, values: null };
      this.buffers.push(buffer);
      return buffer;
    },
    bindBuffer(target, buffer) { this.boundBuffer = buffer; },
    bufferData(target, values) { this.boundBuffer.values = Array.from(values); },
    vertexAttribPointer(index, size, type, normalized, stride, offset) {
      this.attributes.push({ index, size, stride, offset });
    },
    enableVertexAttribArray() {},
    uniformMatrix4fv(location, transpose, value) {
      const matrix = Array.from(value);
      this.uniforms.push({ name: location.name, matrix });
      if (location.name === 'uModel') this.currentModel = matrix;
      if (location.name === 'uViewProjection') this.cameraMatrix = matrix;
    },
    uniform1f(location, value) {
      if (location.name === 'uGlow') this.currentGlow = value;
      if (location.name === 'uOpacity') this.currentOpacity = value;
    },
    drawArrays(mode, first, count) {
      this.draws.push({ mode, first, count, buffer: this.boundBuffer,
        model: this.currentModel && this.currentModel.slice(), glow: this.currentGlow,
        opacity: this.currentOpacity });
    },
    viewport(x, y, width, height) { this.viewports.push({ width, height }); },
    clearColor() {},
    clear(mask) { this.lastClear = mask; },
    enable(value) { this.enabled.push(value); },
    cullFace(value) { this.cullMode = value; }
  };
  return gl;
}

function makeGame() {
  const x = [154, 274, 394, 514, 634, 754, 874];
  const y = [550, 438, 326, 214, 92];
  const rows = [x.slice(), x.slice().reverse(), x.slice(),
    [874, 730, 586, 442, 298, 154],
    [154, 257, 360, 463, 566, 669, 772, 875]];
  const positions = {};
  for (let row = 0, number = 1; row < rows.length; row++) {
    for (let column = 0; column < rows[row].length; column++, number++) {
      positions[number] = { x: rows[row][column], y: y[row], row };
    }
  }
  const definition = {
    2: ['KEY', 'key'], 3: ['BRIDGE', 'shortcut'], 6: ['LOCK', 'lock'],
    10: ['MEDICAL', 'medical'], 12: ['BRIDGE', 'shortcut'], 13: ['KNIFE', 'knife'],
    15: ['AXE', 'axe'], 17: ['LION', 'lion'],
    24: ['HOSPITAL', 'hospital'], 26: ['KNIFE', 'knife'],
    27: ['WOLF', 'wolf'], 31: ['FINAL KEY', 'key'],
    35: ['FINAL LOCK', 'lock']
  };
  const specials = {};
  Object.keys(definition).forEach(function (number) {
    specials[number] = { label: definition[number][0], icon: definition[number][1],
      fill: '#f4d376', color: '#347b4e' };
  });
  return {
    positions, specials,
    state: { started: true, won: false, current: 0, players: [
      { name: 'Ruby Explorer', color: '#bf5141', position: 2 },
      { name: 'River Explorer', color: '#347b8a', position: 10 }
    ] }
  };
}

function loadWorld(options) {
  const settings = options || {};
  const ids = Object.create(null);
  const gl = createGl(Boolean(settings.failingShaders));
  const requests = [];
  let rafCount = 0;
  const clock = { now: 1000 };
  const shell = ids['board-shell'] = new Element('section', 'board-shell');
  const canvas = ids['world-3d'] = new Element('canvas', 'world-3d');
  canvas.clientWidth = 980;
  canvas.clientHeight = 620;
  canvas.getContext = function (kind) {
    requests.push(kind);
    return settings.supported === false ? null : gl;
  };
  canvas.setPointerCapture = function (pointer) { this.capturedPointer = pointer; };
  const labels = ids['world-labels'] = new Element('div', 'world-labels');
  const art = ids['world-art'] = new Element('div', 'world-art');
  const toolbar = ids['world-toolbar'] = new Element('div', 'world-toolbar');
  const badge = ids['world-badge'] = new Element('span', 'world-badge');
  const cameraButton = ids['camera-mode-btn'] = new Element('button', 'camera-mode-btn');
  const fullscreenButton = ids['fullscreen-board-btn'] = new Element('button', 'fullscreen-board-btn');
  const zoomOutButton = ids['zoom-out-btn'] = new Element('button', 'zoom-out-btn');
  const zoomInButton = ids['zoom-in-btn'] = new Element('button', 'zoom-in-btn');
  const body = new Element('body', 'body');
  const document = {
    body,
    createElement(name) { return new Element(name); },
    getElementById(id) { return ids[id] || null; }
  };
  const window = {
    devicePixelRatio: 1,
    requestAnimationFrame(callback) {
      this.frameCallback = callback;
      return ++rafCount;
    },
    cancelAnimationFrame(id) { this.cancelledAnimation = id; }
  };
  const performance = { now() { return clock.now; } };
  vm.runInNewContext(source, { window, document, performance, Date, Float32Array,
    Number, Math, Array, String, Boolean, Object, parseInt, Error },
  { filename: 'world3d.js' });
  const game = makeGame();
  const api = window.KeysClawsWorld3D;
  function start() {
    return api.init({ canvas, labels, art: settings.art === false ? null : art,
      toolbar, badge, cameraButton,
      fullscreenButton, zoomOutButton, zoomInButton, game });
  }
  return { api, gl, game, canvas, labels, art, shell, badge, toolbar, cameraButton,
    fullscreenButton, zoomOutButton, zoomInButton, body, document, window,
    clock, requests, start };
}

const scene = loadWorld();
const api = scene.api;

check('3D renderer exposes reusable matrix, projection, and mesh APIs', function () {
  assert.ok(api && api.math && api.geometry);
  assert.deepStrictEqual(Array.from(api.math.rgb('#ff8040')),
    [1, 128 / 255, 64 / 255]);
  assert.deepStrictEqual(Array.from(api.math.rgb('#abc')),
    [170 / 255, 187 / 255, 204 / 255]);
  assert.deepStrictEqual(Array.from(api.math.normalize([3, 0, 4])), [.6, 0, .8]);
});

check('Perspective, view, identity, and model matrices describe a true 3D camera', function () {
  const identity = api.math.identity();
  const transform = api.math.model(2, 3, 4, .3, 1.2);
  assert.deepStrictEqual(Array.from(api.math.multiply(identity, transform)),
    Array.from(transform));
  const projection = api.math.perspective(.73, 980 / 620, .12, 80);
  const view = api.math.lookAt([0, 8, 12], [0, 0, 0], [0, 1, 0]);
  assert.strictEqual(projection[11], -1);
  assert.ok(view[14] < 0);
  const projected = api.math.project(api.math.multiply(projection, view),
    0, 0, 0, 980, 620);
  assert.ok(projected && Math.abs(projected.x - 490) < 1);
});

check('Procedural boxes contain 36 real vertices and every 3D primitive has geometry', function () {
  const box = api.geometry.create();
  api.geometry.box(box, 0, 0, 0, 1, 1, 1, '#ffffff');
  assert.strictEqual(box.count, 36);
  assert.strictEqual(box.values.length, 36 * 9);
  [
    function (mesh) { api.geometry.cylinder(mesh, 0, 0, 0, .3, .8, '#ffffff', 8); },
    function (mesh) { api.geometry.cone(mesh, 0, 0, 0, .3, .8, '#ffffff', 7); },
    function (mesh) { api.geometry.sphere(mesh, 0, 0, 0, .3, '#ffffff', 5, 8); },
    function (mesh) { api.geometry.torus(mesh, 0, 0, 0, .3, .08, '#ffffff', 9, 5); }
  ].forEach(function (create) {
    const mesh = api.geometry.create();
    create(mesh);
    assert.ok(mesh.count > 30);
    assert.strictEqual(mesh.values.length, mesh.count * 9);
  });
});

check('Supported devices initialize a genuine WebGL 3D board', function () {
  assert.strictEqual(scene.start(), true, api.state.failure || 'renderer initialization failed');
  assert.deepStrictEqual(scene.requests, ['webgl']);
  assert.strictEqual(api.state.ready, true);
  assert.strictEqual(scene.shell.classList.contains('board-3d-active'), true);
  assert.strictEqual(scene.badge.textContent, 'LIVE 3D WORLD');
  assert.strictEqual(scene.canvas.width, 980);
  assert.strictEqual(scene.canvas.height, 620);
});

check('Vertex and fragment shaders use 3D coordinates, perspective, normals, and lighting', function () {
  assert.strictEqual(scene.gl.shaders.length, 2);
  const vertex = scene.gl.shaders.find(function (shader) {
    return shader.type === scene.gl.VERTEX_SHADER;
  }).source;
  const fragment = scene.gl.shaders.find(function (shader) {
    return shader.type === scene.gl.FRAGMENT_SHADER;
  }).source;
  ['attribute vec3 aPosition', 'attribute vec3 aNormal',
    'uniform mat4 uViewProjection', 'uModel * vec4'].forEach(function (part) {
    assert.ok(vertex.includes(part));
  });
  ['normalize', 'dot', 'sun', 'fill', 'gl_FragColor'].forEach(function (part) {
    assert.ok(fragment.includes(part));
  });
});

check('All 35 raised spaces, terrain, trees, routes, START, and HOME share real vertex buffers', function () {
  assert.ok(api.state.stats.staticVertices > 35 * 36 * 2);
  assert.strictEqual(api.state.meshes.landscape.count, api.state.stats.staticVertices);
  assert.strictEqual(api.state.meshes.landscape.buffer.values.length,
    api.state.stats.staticVertices * 9);
  assert.ok(api.state.stats.staticVertices > 6000);
});

check('The detailed natural jungle background remains visible behind the real 3D route', function () {
  const landscape = scene.gl.draws.find(function (draw) {
    return draw.buffer === api.state.meshes.landscape.buffer;
  });
  assert.ok(landscape);
  assert.strictEqual(landscape.opacity, .47);
  const explorer = scene.gl.draws.find(function (draw) {
    return draw.buffer === api.state.meshes.player_0.buffer;
  });
  assert.ok(explorer);
  assert.strictEqual(explorer.opacity, 1);
  const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
  assert.ok(css.includes('art/jungle_natural.jpg'));
  assert.ok(source.includes('premultipliedAlpha: false'));
});

check('All board numbers and eight shortcut, fallback, START, and HOME labels exist', function () {
  assert.strictEqual(api.state.markers.length, 35);
  assert.strictEqual(api.state.routeMarkers.length, 8);
  assert.strictEqual(scene.labels.children.length, 43);
  assert.strictEqual(api.state.markers[0].node.getAttribute('data-space'), '1');
  assert.strictEqual(api.state.markers[34].node.getAttribute('data-space'), '35');
  const labels = Array.from(api.state.routeMarkers, function (entry) {
    return entry.node.textContent;
  });
  assert.deepStrictEqual(labels, ['3 → 11', '6 → 1', '12 → 18', '17 → 10',
    '27 → 24', '35 → 30', 'START', 'HOME']);
});

check('The approved 7/7/7/6/8 jungle path has both elevated bridges and one legal river crossing', function () {
  assert.deepStrictEqual(Array.from(api.state.stats.bridgeRoutes, function (route) {
    return Array.from(route);
  }), [[3, 11], [12, 18]]);
  assert.deepStrictEqual(Array.from(api.state.stats.riverBarrier.legalCrossing), [27, 28]);
  assert.strictEqual(api.state.stats.riverBarrier.startsAtX, 205);
  assert.ok(scene.game.positions[27].x < api.state.stats.riverBarrier.startsAtX);
  assert.strictEqual(scene.game.positions[27].x, scene.game.positions[28].x);
});

check('Six separate approved transparent artwork sprites align with 3D board positions', function () {
  assert.strictEqual(api.state.spriteMarkers.length, 6);
  assert.strictEqual(scene.art.children.length, 6);
  assert.deepStrictEqual(Array.from(api.state.spriteMarkers, function (entry) {
    return [entry.kind, entry.space];
  }), [['key', 2], ['gate', 6], ['lion', 17], ['wolf', 27], ['key', 31], ['gate', 35]]);
  api.state.spriteMarkers.forEach(function (entry) {
    assert.ok(entry.node.getAttribute('src').startsWith('art/'));
    assert.ok(Number.isFinite(parseFloat(entry.node.style.left)));
    assert.ok(Number.isFinite(parseFloat(entry.node.style.top)));
  });
});

check('Approved lion, wolf, key, and gate artwork completely replaces overlapping legacy models', function () {
  ['lion', 'wolf', 'key', 'lock', 'shackle'].forEach(function (name) {
    assert.strictEqual(scene.gl.draws.some(function (draw) {
      return draw.buffer === api.state.meshes[name].buffer;
    }), false, 'an old ' + name + ' model is visible behind the approved artwork');
  });
});

check('Legacy models remain available only when the approved artwork layer is unavailable', function () {
  const compatibility = loadWorld({ art: false });
  assert.strictEqual(compatibility.start(), true);
  assert.strictEqual(compatibility.api.state.spriteMarkers.length, 0);
  ['lion', 'wolf', 'key', 'lock', 'shackle'].forEach(function (name) {
    assert.ok(compatibility.gl.draws.some(function (draw) {
      return draw.buffer === compatibility.api.state.meshes[name].buffer;
    }), 'the ' + name + ' compatibility model was not available');
  });
});

check('A missing artwork image falls back to exactly its own legacy model and recovers cleanly', function () {
  const compatibility = loadWorld();
  assert.strictEqual(compatibility.start(), true);
  const lion = compatibility.api.state.spriteMarkers.find(function (entry) {
    return entry.kind === 'lion';
  });
  lion.node.handlers.error();
  compatibility.gl.draws.length = 0;
  compatibility.api.renderFrame(compatibility.clock.now + 5);
  assert.strictEqual(lion.node.style.display, 'none');
  assert.ok(compatibility.gl.draws.some(function (draw) {
    return draw.buffer === compatibility.api.state.meshes.lion.buffer;
  }));
  assert.strictEqual(compatibility.gl.draws.some(function (draw) {
    return draw.buffer === compatibility.api.state.meshes.wolf.buffer;
  }), false);
  lion.node.handlers.load();
  compatibility.gl.draws.length = 0;
  compatibility.api.renderFrame(compatibility.clock.now + 10);
  assert.strictEqual(lion.node.style.display, '');
  assert.strictEqual(compatibility.gl.draws.some(function (draw) {
    return draw.buffer === compatibility.api.state.meshes.lion.buffer;
  }), false);
});

check('Animated river glints and jungle fireflies have independent WebGL draw calls', function () {
  assert.ok(api.state.meshes.water_glint);
  const glints = scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.water_glint.buffer;
  });
  assert.strictEqual(glints.length, 6);
});

check('Every key, lock, weapon, medical station, animal, and player is a separate 3D mesh', function () {
  ['landscape', 'key', 'lock', 'shackle', 'knife', 'axe', 'medical', 'hospital',
    'shortcut', 'lion', 'wolf', 'particle', 'tear', 'player_0', 'player_1']
    .forEach(function (name) {
      assert.ok(api.state.meshes[name], 'missing ' + name);
      assert.ok(api.state.meshes[name].count > 0, 'empty ' + name);
    });
  assert.ok(api.state.meshes.lion.count > 500);
  assert.ok(api.state.meshes.wolf.count > 500);
  assert.ok(api.state.meshes.player_0.count > 500);
});

check('The approved seated lion stays large and visible without displaying its old fallback model', function () {
  const lion = api.state.meshes.lion;
  const wolf = api.state.meshes.wolf;
  assert.ok(lion.count > wolf.count, 'the detailed seated lion should exceed the wolf mesh');
  const heights = [];
  for (let index = 1; index < lion.buffer.values.length; index += 9) {
    heights.push(lion.buffer.values[index]);
  }
  assert.ok(Math.max.apply(Math, heights) > 1);
  const approvedLion = api.state.spriteMarkers.find(function (entry) {
    return entry.kind === 'lion';
  });
  assert.ok(approvedLion);
  assert.ok(parseFloat(approvedLion.node.style.height) >= 56,
    'the approved resting lion must remain clearly visible');
  assert.strictEqual(scene.gl.draws.some(function (draw) {
    return draw.buffer === lion.buffer;
  }), false, 'the old lion model overlaps the approved lion artwork');
  assert.ok(source.includes('friendly seated lion'));
});

check('Rendered frames enable depth testing and submit 3D triangles to WebGL', function () {
  assert.ok(scene.gl.enabled.includes(scene.gl.DEPTH_TEST));
  assert.ok(scene.gl.enabled.includes(scene.gl.CULL_FACE));
  assert.strictEqual(scene.gl.cullMode, scene.gl.BACK);
  assert.ok(scene.gl.draws.length > 15);
  assert.ok(scene.gl.draws.every(function (draw) { return draw.mode === scene.gl.TRIANGLES; }));
  assert.ok(scene.gl.attributes.some(function (attribute) {
    return attribute.stride === 36 && attribute.offset === 24;
  }));
  assert.ok(scene.gl.cameraMatrix && scene.gl.cameraMatrix.length === 16);
});

check('Projected 3D labels follow the board and have finite independent screen positions', function () {
  const first = api.state.markers[0].node.style;
  const last = api.state.markers[34].node.style;
  assert.ok(Number.isFinite(parseFloat(first.left)));
  assert.ok(Number.isFinite(parseFloat(first.top)));
  assert.ok(Number.isFinite(parseFloat(last.left)));
  assert.notStrictEqual(first.left + first.top, last.left + last.top);
});

check('Lion encounters focus and animate the lion with additional glowing particles', function () {
  assert.strictEqual(api.playEvent('lion', 17, 0), true);
  assert.strictEqual(api.state.event.kind, 'lion');
  assert.strictEqual(api.state.event.space, 17);
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 20);
  const lionBuffer = api.state.meshes.lion.buffer;
  assert.strictEqual(scene.gl.draws.some(function (draw) {
    return draw.buffer === lionBuffer;
  }), false, 'the old lion model overlaps the approved roaring artwork');
  const particle = scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.particle.buffer;
  });
  assert.ok(particle.length >= 5);
  const sprite = api.state.spriteMarkers.find(function (entry) { return entry.kind === 'lion'; });
  assert.strictEqual(sprite.node.getAttribute('data-art-state'), 'lion_roar');
});

check('Victorious animal encounters temporarily use the approved sleeping artwork', function () {
  assert.strictEqual(api.showDefeated(17), true);
  api.renderFrame(scene.clock.now + 24);
  const sprite = api.state.spriteMarkers.find(function (entry) { return entry.kind === 'lion'; });
  assert.strictEqual(sprite.node.getAttribute('data-art-state'), 'lion_sleep');
});

check('Golden keys brighten when collected without showing a second legacy key', function () {
  api.playEvent('key', 2, 0);
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 30);
  const sprite = api.state.spriteMarkers.find(function (entry) {
    return entry.kind === 'key' && entry.space === 2;
  });
  assert.strictEqual(sprite.node.getAttribute('data-art-state'), 'key_glow');
  assert.strictEqual(scene.gl.draws.some(function (draw) {
    return draw.buffer === api.state.meshes.key.buffer;
  }), false, 'a legacy key overlaps the approved golden key');
  assert.ok(scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.particle.buffer;
  }).length >= 5);
});

check('Unlock events show only the approved unlocking gate and its embedded golden key', function () {
  api.setGateState(6, 'unlocking');
  api.playEvent('unlock', 6, 0);
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 40);
  const gate = api.state.spriteMarkers.find(function (entry) {
    return entry.kind === 'gate' && entry.space === 6;
  });
  assert.strictEqual(gate.node.getAttribute('data-art-state'), 'gate_unlocking');
  ['key', 'lock', 'shackle'].forEach(function (name) {
    assert.strictEqual(scene.gl.draws.some(function (draw) {
      return draw.buffer === api.state.meshes[name].buffer;
    }), false, 'an old ' + name + ' overlaps the approved unlocking gate');
  });
  assert.ok(scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.particle.buffer;
  }).length >= 5);
});

check('Gates expose unlocking, open, halfway-closing, and closed approved artwork states', function () {
  const gate = api.state.spriteMarkers.find(function (entry) { return entry.space === 6; });
  [['unlocking', 'gate_unlocking'], ['open', 'gate_open'],
    ['half_closing', 'gate_half_closing'], ['closed', 'gate_closed']]
    .forEach(function (expectation, index) {
      assert.strictEqual(api.setGateState(6, expectation[0]), true);
      api.renderFrame(scene.clock.now + 45 + index);
      assert.strictEqual(gate.node.getAttribute('data-art-state'), expectation[1]);
    });
});

check('Walking player models move to the actual smoothly animated board location', function () {
  const player = scene.game.state.players[0];
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 50);
  const before = scene.gl.draws.find(function (draw) {
    return draw.buffer === api.state.meshes.player_0.buffer;
  }).model;
  player.animatedPoint = { x: 540, y: 400 };
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 70);
  const after = scene.gl.draws.find(function (draw) {
    return draw.buffer === api.state.meshes.player_0.buffer;
  }).model;
  assert.notStrictEqual(before[12], after[12]);
  assert.notStrictEqual(before[14], after[14]);
  assert.ok(Math.abs(after[12] - api.math.boardPoint(540, 400).x) < .0001);
  delete player.animatedPoint;
});

check('Crying fallbacks render two animated three-dimensional teardrops', function () {
  scene.game.state.players[0].expression = 'cry';
  api.playEvent('cry', 17, 0);
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 80);
  const tears = scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.tear.buffer;
  });
  assert.strictEqual(tears.length, 2);
  assert.notStrictEqual(tears[0].model[12], tears[1].model[12]);
  delete scene.game.state.players[0].expression;
});

check('Victory keeps the approved final gate and surrounds the explorer with celebratory particles', function () {
  scene.game.state.won = true;
  scene.game.state.players[0].position = 35;
  api.playEvent('victory', 35, 0);
  scene.gl.draws.length = 0;
  api.renderFrame(scene.clock.now + 90);
  assert.strictEqual(api.state.event.kind, 'victory');
  assert.strictEqual(scene.gl.draws.some(function (draw) {
    return draw.buffer === api.state.meshes.shackle.buffer;
  }), false, 'an old final-lock shackle overlaps the approved jungle gate');
  assert.ok(scene.gl.draws.filter(function (draw) {
    return draw.buffer === api.state.meshes.particle.buffer;
  }).length >= 5);
  scene.game.state.won = false;
});

check('Follow and overview cameras toggle from the visible camera button', function () {
  assert.strictEqual(api.state.cameraMode, 'follow');
  scene.cameraButton.handlers.click();
  assert.strictEqual(api.state.cameraMode, 'overview');
  assert.strictEqual(scene.cameraButton.textContent, 'CAMERA: OVERVIEW');
  scene.cameraButton.handlers.click();
  assert.strictEqual(api.state.cameraMode, 'follow');
});

check('Dragging rotates the board while camera orbit remains safely clamped', function () {
  scene.canvas.handlers.pointerdown({ clientX: 100, pointerId: 7 });
  assert.strictEqual(scene.canvas.capturedPointer, 7);
  scene.canvas.handlers.pointermove({ clientX: 500 });
  assert.strictEqual(api.state.yaw, .82);
  scene.canvas.handlers.pointerup();
  assert.strictEqual(api.state.pointer, null);
  assert.strictEqual(api.setYaw(-100), -.8);
  assert.strictEqual(api.setYaw(100), .82);
});

check('The board starts large and camera zoom remains within safe readable limits', function () {
  assert.strictEqual(api.state.distance, 11.6);
  assert.strictEqual(api.setDistance(1), 7.8);
  assert.strictEqual(api.setDistance(100), 16.8);
  scene.zoomInButton.handlers.click();
  assert.strictEqual(api.state.distance, 15.9);
  scene.zoomOutButton.handlers.click();
  assert.strictEqual(api.state.distance, 16.8);
  let prevented = false;
  scene.canvas.handlers.wheel({ deltaY: -1, preventDefault() { prevented = true; } });
  assert.strictEqual(prevented, true);
  assert.ok(Math.abs(api.state.distance - 16.1) < .0001);
  assert.ok(page.includes('user-scalable=no'));
});

check('Two-finger pinch changes camera zoom while one-finger drag still orbits', function () {
  api.setDistance(11.6);
  scene.canvas.handlers.pointerdown({ clientX: 100, clientY: 100, pointerId: 1 });
  scene.canvas.handlers.pointerdown({ clientX: 200, clientY: 100, pointerId: 2 });
  scene.canvas.handlers.pointermove({ clientX: 250, clientY: 100, pointerId: 2 });
  assert.ok(api.state.distance < 11.6);
  scene.canvas.handlers.pointerup({ pointerId: 2 });
  scene.canvas.handlers.pointerup({ pointerId: 1 });
});

check('The full-screen option expands the board and keeps compact dice controls available', function () {
  assert.strictEqual(api.state.fullScreen, false);
  assert.strictEqual(scene.fullscreenButton.textContent, 'FULL SCREEN');
  scene.fullscreenButton.handlers.click();
  assert.strictEqual(api.state.fullScreen, true);
  assert.strictEqual(scene.body.classList.contains('board-fullscreen'), true);
  assert.strictEqual(scene.fullscreenButton.textContent, 'EXIT FULL SCREEN');
  assert.strictEqual(scene.fullscreenButton.getAttribute('aria-pressed'), 'true');
  scene.fullscreenButton.handlers.click();
  assert.strictEqual(api.state.fullScreen, false);
  assert.strictEqual(scene.body.classList.contains('board-fullscreen'), false);
});

check('Third and fourth explorers receive independent dynamically generated 3D human models', function () {
  scene.game.state.players.push(
    { name: 'Forest Explorer', color: '#4c8653', position: 12 },
    { name: 'Violet Explorer', color: '#795980', position: 13 }
  );
  api.renderFrame(scene.clock.now + 110);
  assert.ok(api.state.meshes.player_2);
  assert.ok(api.state.meshes.player_3);
});

check('Devices without WebGL keep the original complete 2D board as a working fallback', function () {
  const unsupported = loadWorld({ supported: false });
  assert.strictEqual(unsupported.start(), false);
  assert.deepStrictEqual(unsupported.requests, ['webgl', 'experimental-webgl']);
  assert.strictEqual(unsupported.api.state.fallback, true);
  assert.strictEqual(unsupported.canvas.style.display, 'none');
  assert.strictEqual(unsupported.labels.style.display, 'none');
  assert.strictEqual(unsupported.badge.textContent, 'ADVENTURE MAP');
  assert.strictEqual(unsupported.shell.classList.contains('board-3d-active'), false);
});

check('A failed shader compilation also falls back safely without stopping gameplay', function () {
  const broken = loadWorld({ failingShaders: true });
  assert.strictEqual(broken.start(), false);
  assert.strictEqual(broken.api.state.fallback, true);
  assert.ok(broken.api.state.failure.includes('shader compilation failure'));
});

check('The legacy WebGL source stays archived but the Android app shows only the natural image board', function () {
  ['id="world-3d"', 'id="world-art"', 'id="world-labels"',
    'id="world-toolbar"', 'id="camera-mode-btn"', 'id="fullscreen-board-btn"',
    'id="zoom-out-btn"', 'id="zoom-in-btn"', 'src="world3d.js"']
    .forEach(function (oldLayer) {
      assert.strictEqual(page.includes(oldLayer), false, oldLayer + ' is still visible');
    });
  assert.ok(page.includes('id="board"'));
  assert.ok(page.includes('src="game.js"'));
  assert.ok(page.includes('QUEST FOR HOME · JUNGLE ADVENTURE'));
  assert.ok(source.includes("getContext('webgl'"));
  assert.ok(source.includes('gl.drawArrays(gl.TRIANGLES'));
});

check('Animation scheduling can be cancelled cleanly when the 3D world closes', function () {
  assert.ok(scene.window.frameCallback);
  api.destroy();
  assert.strictEqual(api.state.ready, false);
  assert.ok(scene.window.cancelledAnimation > 0);
});

console.log(JSON.stringify({
  passed: checks.length,
  archived_renderer: 'historical offline WebGL source; never loaded by the current app',
  active_board: 'single natural jungle image with directly positioned objects',
  numbered_spaces: 35,
  route_and_destination_labels: 8,
  checks
}, null, 2));
