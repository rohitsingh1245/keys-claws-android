#!/usr/bin/env python3
"""Generate the original offline tool-pickup, tool-use, and lock-break sounds.

The generated MP3 clips are packaged with the source and APK. NumPy, SciPy,
and FFmpeg are needed only when intentionally regenerating these assets.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from generate_sounds import RATE, filtered_noise, mix, save, tone


PROJECT = Path(__file__).resolve().parent


def build_clips() -> dict[str, object]:
    clips = {
        'knife_pickup': mix(.74, [
            (.025, filtered_noise(.17, 2600, 7900), .52),
            (.075, tone(.32, 1120, 1680, (1, .17, .04)), .72),
            (.24, tone(.28, 1810, 2280, (1, .12)), .31),
        ]),
        'axe_pickup': mix(.86, [
            (.02, tone(.24, 230, 112, (1, .47, .17)), .67),
            (.045, filtered_noise(.18, 190, 1550), .61),
            (.23, tone(.35, 610, 1010, (1, .2, .04)), .57),
        ]),
        'hammer_pickup': mix(1.02, [
            (.02, tone(.31, 183, 74, (1, .52, .2)), .77),
            (.05, filtered_noise(.22, 120, 1220), .74),
            (.27, tone(.35, 520, 890, (1, .2, .08)), .52),
            (.48, tone(.3, 980, 1390, (1, .14)), .39),
        ]),
        'knife_use': mix(.71, [
            (.035, filtered_noise(.31, 1600, 8700), .91),
            (.09, tone(.27, 1440, 540, (1, .1)), .49),
            (.31, filtered_noise(.13, 2650, 8100), .31),
        ]),
        'axe_use': mix(.91, [
            (.025, filtered_noise(.37, 440, 3250), .87),
            (.19, tone(.29, 305, 72, (1, .42, .12)), .88),
            (.205, filtered_noise(.2, 170, 1550), .93),
            (.44, tone(.22, 610, 355, (1, .12)), .19),
        ]),
        'hammer_hit': mix(.88, [
            (.018, filtered_noise(.19, 120, 1900), 1.03),
            (.025, tone(.32, 194, 53, (1, .64, .27)), .97),
            (.065, tone(.35, 920, 435, (1, .31, .11)), .54),
            (.24, filtered_noise(.17, 1250, 6350), .42),
        ]),
        'lock_break': mix(1.18, [
            (.015, filtered_noise(.43, 780, 7900), .91),
            (.018, tone(.32, 750, 132, (1, .53, .16)), .76),
            (.22, tone(.26, 910, 1100, (1, .18)), .37),
            (.37, tone(.29, 1260, 1450, (1, .16)), .35),
            (.52, tone(.31, 1620, 1850, (1, .14)), .31),
        ]),
    }
    with tempfile.TemporaryDirectory(prefix='keys-claws-adventure-sounds-') as folder:
        scratch = Path(folder)
        results = [save(name, samples, scratch)
                   for name, samples in sorted(clips.items())]
    return {'clips': results, 'count': len(results), 'sample_rate': RATE,
            'offline': True, 'family_friendly': True}


if __name__ == '__main__':
    print(json.dumps(build_clips(), indent=2))
