#!/usr/bin/env python3
"""Verify approved standalone RGBA jungle artwork and original gate recordings."""

from __future__ import annotations

import hashlib
import json
import struct
import wave
import zlib
from pathlib import Path


PROJECT = Path(__file__).resolve().parent


def paeth(left: int, above: int, upper_left: int) -> int:
    predictor = left + above - upper_left
    distances = [abs(predictor - left), abs(predictor - above),
                 abs(predictor - upper_left)]
    return [left, above, upper_left][distances.index(min(distances))]


def read_rgba(path: Path) -> tuple[int, int, bytes]:
    payload = path.read_bytes()
    assert payload.startswith(b'\x89PNG\r\n\x1a\n'), path
    offset = 8
    pieces: list[bytes] = []
    width = height = 0
    while offset + 12 <= len(payload):
        length = struct.unpack_from('>I', payload, offset)[0]
        kind = payload[offset + 4:offset + 8]
        chunk = payload[offset + 8:offset + 8 + length]
        if kind == b'IHDR':
            width, height, depth, color, compression, filters, interlace = struct.unpack(
                '>IIBBBBB', chunk)
            assert depth == 8 and color == 6, f'{path.name} is not genuine 8-bit RGBA'
            assert compression == 0 and filters == 0 and interlace == 0, path
        elif kind == b'IDAT':
            pieces.append(chunk)
        elif kind == b'IEND':
            break
        offset += 12 + length

    raw = zlib.decompress(b''.join(pieces))
    stride = width * 4
    assert len(raw) == height * (stride + 1), path
    pixels = bytearray(height * stride)
    for row in range(height):
        method = raw[row * (stride + 1)]
        source = raw[row * (stride + 1) + 1:(row + 1) * (stride + 1)]
        row_start = row * stride
        for column, current in enumerate(source):
            left = pixels[row_start + column - 4] if column >= 4 else 0
            above = pixels[row_start - stride + column] if row else 0
            upper_left = pixels[row_start - stride + column - 4] if row and column >= 4 else 0
            if method == 0:
                prediction = 0
            elif method == 1:
                prediction = left
            elif method == 2:
                prediction = above
            elif method == 3:
                prediction = (left + above) // 2
            elif method == 4:
                prediction = paeth(left, above, upper_left)
            else:
                raise AssertionError(f'{path.name}: unknown PNG filter {method}')
            pixels[row_start + column] = (current + prediction) & 255
    return width, height, bytes(pixels)


def main() -> None:
    manifest = json.loads((PROJECT / 'art' / 'manifest.json').read_text())
    assert manifest['row_spaces'] == [[1, 7], [8, 14], [15, 21], [22, 27], [28, 35]]
    assert manifest['legal_turns'] == [[7, 8], [14, 15], [21, 22], [27, 28]]
    assert manifest['shortcut_bridges'] == [[3, 11], [12, 18], [25, 29]]
    assert len(manifest['states']) == 15
    assert manifest['neutral_natural_background'] == 'art/jungle_natural.jpg'
    assert manifest['visible_webgl_board'] is False
    assert manifest['board_numbers_visible'] is False
    assert manifest['path_lane_centers'] == [548, 421, 311, 208, 106]
    assert manifest['dry_middle_row_endpoint'] == 740
    assert manifest['background_reference_upload'] == '1000254601.png'
    assert '2.5D' in manifest['image_native_depth_illusion']
    assert 'flowing river highlights' in manifest['living_jungle_effects']
    assert 'animated waterfalls' in manifest['living_jungle_effects']
    assert manifest['offline_jungle_ambience'] == 'sounds/jungle_ambience.mp3'
    assert manifest['explorer_avatar_frame_size'] == 256
    assert manifest['explorer_avatar_poses'] == [
        'idle', 'walk_left', 'walk_right', 'pickup', 'knife_defense',
        'two_handed_tool', 'crying', 'recovery_victory',
    ]
    explorers = manifest['explorer_avatars']
    assert [explorer['id'] for explorer in explorers] == [
        'ruby', 'river', 'forest', 'violet',
    ]
    assert len({explorer['color'] for explorer in explorers}) == 4
    hammer = manifest['hammer']
    assert hammer['space'] == 33
    assert hammer['requires_exact_landing'] is True
    assert hammer['works_only_at_final_gate'] == 35
    assert hammer['opens_first_gate'] is False
    assert hammer['protects_against_animals'] is False
    rankings = manifest['ranked_multiplayer']
    assert rankings['continues_after_first_finisher'] is True
    assert rankings['skips_finished_explorers'] is True
    assert rankings['automatic_last_place'] is True
    assert rankings['maximum_explorers'] == 4
    encounters = manifest['encounter_outcomes']
    assert encounters['human_victory'] == 'animal_falls'
    assert encounters['animal_victory'] == 'explorer_falls'
    assert encounters['reuses_approved_transparent_artwork'] is True
    ambience = PROJECT / manifest['offline_jungle_ambience']
    assert ambience.is_file(), 'The offline living-jungle soundtrack is missing'
    assert ambience.stat().st_size > 100000, 'The ambience loop is unexpectedly short'
    assert 'directly on its paths' in manifest['board_presentation']
    assert manifest['background_contains_baked_game_objects'] is False
    natural_background = PROJECT / manifest['neutral_natural_background']
    background_sha256 = hashlib.sha256(natural_background.read_bytes()).hexdigest()
    assert background_sha256 == manifest['background_sha256'], (
        'The exact user-uploaded jungle image must remain unchanged')
    payload = natural_background.read_bytes()
    assert payload.startswith(b'\xff\xd8'), 'The uploaded image is a genuine JPEG'
    offset = 2
    background_width = background_height = 0
    while offset + 4 <= len(payload):
        assert payload[offset] == 0xff
        while payload[offset] == 0xff:
            offset += 1
        marker = payload[offset]
        offset += 1
        if marker in {0xd9, 0xda}:
            break
        length = struct.unpack_from('>H', payload, offset)[0]
        if marker in {0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7,
                      0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf}:
            background_height, background_width = struct.unpack_from('>HH', payload, offset + 3)
            break
        offset += length
    assert background_width >= 1000 and background_height >= 600
    assert natural_background.stat().st_size > 100000

    transparent_states = []
    gate_passages = []
    for entry in manifest['states']:
        width, height, rgba = read_rgba(PROJECT / entry['file'])
        assert width == entry['width'] and height == entry['height']
        assert any(alpha == 0 for alpha in rgba[3::4]), entry['file']
        assert any(alpha > 245 for alpha in rgba[3::4]), entry['file']
        transparent_states.append(entry['file'])
        if entry['transparent_gate_passage']:
            alpha = rgba[(int(height * .57) * width + width // 2) * 4 + 3]
            assert alpha <= 12, f'{entry["file"]} does not have a transparent doorway'
            gate_passages.append(entry['file'])
    assert sorted(gate_passages) == ['art/gate_half_closing.png', 'art/gate_open.png']

    avatar_frames = []
    for explorer in explorers:
        assert explorer['frames'] == 8
        for frame in range(1, explorer['frames'] + 1):
            relative = explorer['asset_pattern'].replace('XX', f'{frame:02d}')
            width, height, rgba = read_rgba(PROJECT / relative)
            assert (width, height) == (256, 256), relative
            assert any(alpha == 0 for alpha in rgba[3::4]), relative
            assert any(alpha > 245 for alpha in rgba[3::4]), relative
            avatar_frames.append(relative)
    assert len(avatar_frames) == 32

    adventure_art = {}
    for relative in [hammer['asset'], hammer['broken_gate_asset']]:
        width, height, rgba = read_rgba(PROJECT / relative)
        assert any(alpha == 0 for alpha in rgba[3::4]), relative
        assert any(alpha > 245 for alpha in rgba[3::4]), relative
        adventure_art[relative] = {'width': width, 'height': height,
                                   'genuine_transparent_alpha': True}
    assert adventure_art[hammer['broken_gate_asset']] == {
        'width': 620, 'height': 413, 'genuine_transparent_alpha': True,
    }

    tool_sounds = {}
    for effect in ['knife_pickup', 'axe_pickup', 'hammer_pickup',
                   'knife_use', 'axe_use', 'hammer_hit', 'lock_break']:
        relative = manifest['sound_events'][effect]
        assert relative == f'sounds/{effect}.mp3'
        clip = PROJECT / relative
        assert clip.is_file() and clip.stat().st_size > 1000, relative
        tool_sounds[effect] = clip.stat().st_size

    recordings = {}
    for name, expected_duration in [('gate_open', 2.10), ('gate_close', 1.95)]:
        with wave.open(str(PROJECT / 'sounds' / f'{name}.wav'), 'rb') as audio:
            assert audio.getnchannels() == 2
            assert audio.getframerate() == 48000
            assert audio.getsampwidth() == 2
            duration = audio.getnframes() / audio.getframerate()
            assert abs(duration - expected_duration) < .02
            recordings[name] = {'sample_rate': 48000, 'channels': 2,
                                'duration_seconds': round(duration, 2)}

    print(json.dumps({
        'passed': True,
        'independent_real_alpha_artwork_states': len(transparent_states),
        'full_body_explorer_avatars': len(explorers),
        'normalized_transparent_explorer_animation_frames': len(avatar_frames),
        'transparent_hammer_and_broken_gate': adventure_art,
        'hammer_exact_landing_space': hammer['space'],
        'hammer_works_only_at_final_gate': hammer['works_only_at_final_gate'],
        'ranked_multiplayer_continues_after_first_finisher': rankings,
        'winner_and_loser_fall_animation_outcomes': encounters,
        'distinct_offline_tool_pickup_and_use_sounds': tool_sounds,
        'genuinely_transparent_gate_passages': gate_passages,
        'approved_lane_lengths': [7, 7, 7, 6, 8],
        'objects_directly_on_natural_background': True,
        'printed_board_numbers_visible': False,
        'visible_webgl_board': False,
        'image_native_2_5d_depth_illusion': True,
        'living_jungle_effects': manifest['living_jungle_effects'],
        'offline_looping_jungle_ambience': {
            'file': manifest['offline_jungle_ambience'],
            'bytes': ambience.stat().st_size,
        },
        'image_aligned_lane_centers': manifest['path_lane_centers'],
        'natural_neutral_jungle_background': {
            'file': manifest['neutral_natural_background'],
            'width': background_width,
            'height': background_height,
            'exact_uploaded_image_sha256': background_sha256,
            'contains_baked_game_objects': False,
        },
        'elevated_bridges': [[3, 11], [12, 18], [25, 29]],
        'original_gate_recordings': recordings,
    }, indent=2))


if __name__ == '__main__':
    main()
