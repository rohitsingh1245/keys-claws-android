#!/usr/bin/env python3
"""Build a self-contained, signed Android APK without an installed Android SDK."""

from __future__ import annotations

import base64
import datetime as dt
import hashlib
import io
import json
import math
import os
import re
import struct
import zipfile
import zlib
from dataclasses import dataclass
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.serialization import pkcs7
from cryptography.x509.oid import NameOID


PROJECT = Path(__file__).resolve().parent
SHARED_ASSETS = PROJECT if (PROJECT / 'map.jpg').is_file() else PROJECT.parent / 'adventure_android'
OUTPUT = PROJECT.parent / 'Keys_Claws_Quest_for_Home_3D_Jungle_v2.2.apk'
PACKAGE = 'com.keysandclaws.questforhome3d'
MAIN_CLASS = PACKAGE + '.MainActivity'
MAIN_DESCRIPTOR = 'L' + PACKAGE.replace('.', '/') + '/MainActivity;'
APP_LABEL = 'Keys & Claws: Quest for Home 3D'
VERSION_CODE = 12
VERSION_NAME = '2.2-ai-online-voice'
TARGET_SDK = 36
LAUNCHER_ICON_ID = 0x7F010000
ANDROID_NS = 'http://schemas.android.com/apk/res/android'


def u16(value: int) -> bytes:
    return struct.pack('<H', value)


def u32(value: int) -> bytes:
    return struct.pack('<I', value & 0xFFFFFFFF)


def u64(value: int) -> bytes:
    return struct.pack('<Q', value)


def prefixed(data: bytes) -> bytes:
    return u32(len(data)) + data


def uleb(value: int) -> bytes:
    result = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        result.append(byte | (0x80 if value else 0))
        if not value:
            return bytes(result)


def align(buffer: bytearray, size: int = 4) -> None:
    buffer.extend(bytes((-len(buffer)) % size))


def xml_string_pool(strings: list[str]) -> bytes:
    offsets: list[int] = []
    data = bytearray()
    for string in strings:
        encoded = string.encode('utf-8')
        utf16_length = len(string.encode('utf-16-le')) // 2
        if utf16_length >= 128 or len(encoded) >= 128:
            raise ValueError('Manifest string is unexpectedly long')
        offsets.append(len(data))
        data.extend(bytes([utf16_length, len(encoded)]))
        data.extend(encoded)
        data.append(0)
    while len(data) % 4:
        data.append(0)
    header_size = 28
    string_start = header_size + 4 * len(strings)
    size = string_start + len(data)
    header = struct.pack('<HHIIIIII', 0x0001, header_size, size, len(strings), 0,
                         0x00000100, string_start, 0)
    return header + b''.join(u32(offset) for offset in offsets) + data


def build_resource_table() -> bytes:
    """Compile one drawable resource so Android displays the branded app icon."""
    global_strings = xml_string_pool(['res/drawable/ic_launcher.png'])
    type_strings = xml_string_pool(['drawable'])
    key_strings = xml_string_pool(['ic_launcher'])

    type_spec = struct.pack('<HHIBBHI', 0x0202, 16, 20, 1, 0, 0, 1) + u32(0)
    config = u32(64) + bytes(60)
    type_header_size = 20 + len(config)
    entries_start = type_header_size + 4
    entry = struct.pack('<HHI', 8, 0, 0) + struct.pack('<HBBI', 8, 0, 0x03, 0)
    resource_type = (
        struct.pack('<HHIBBHII', 0x0201, type_header_size,
                    entries_start + len(entry), 1, 0, 0, 1, entries_start)
        + config + u32(0) + entry
    )

    package_header_size = 288
    encoded_name = PACKAGE.encode('utf-16-le')
    if len(encoded_name) > 254:
        raise ValueError('Android resource package name is unexpectedly long')
    package_name = encoded_name + bytes(256 - len(encoded_name))
    key_strings_offset = package_header_size + len(type_strings)
    package_size = (package_header_size + len(type_strings) + len(key_strings)
                    + len(type_spec) + len(resource_type))
    package = (
        struct.pack('<HHII256sIIIII', 0x0200, package_header_size, package_size,
                    0x7F, package_name, package_header_size, 1,
                    key_strings_offset, 1, 0)
        + type_strings + key_strings + type_spec + resource_type
    )
    total_size = 12 + len(global_strings) + len(package)
    return struct.pack('<HHII', 0x0002, 12, total_size, 1) + global_strings + package


@dataclass(frozen=True)
class XmlAttribute:
    name: str
    value: str | int | bool
    namespace: bool = True
    value_type: int | None = None
    raw: str | None = None


def build_manifest() -> bytes:
    # Android attribute names occupy the first string-pool slots so the resource
    # map indexes line up with the parser's expected framework attribute IDs.
    attributes = [
        ('label', 0x01010001),
        ('icon', 0x01010002),
        ('name', 0x01010003),
        ('exported', 0x01010010),
        ('screenOrientation', 0x0101001E),
        ('minSdkVersion', 0x0101020C),
        ('targetSdkVersion', 0x01010270),
        ('maxSdkVersion', 0x01010271),
        ('versionCode', 0x0101021B),
        ('versionName', 0x0101021C),
    ]
    strings = [item[0] for item in attributes] + [
        'android', ANDROID_NS, 'manifest', 'package', PACKAGE, VERSION_NAME,
        'uses-sdk', 'uses-permission', 'android.permission.INTERNET',
        'android.permission.ACCESS_WIFI_STATE', 'android.permission.BLUETOOTH',
        'android.permission.BLUETOOTH_CONNECT', 'android.permission.RECORD_AUDIO',
        'application', APP_LABEL, 'activity', MAIN_CLASS,
        'landscape', 'intent-filter', 'action', 'android.intent.action.MAIN',
        'category', 'android.intent.category.LAUNCHER',
    ]
    indexes = {value: index for index, value in enumerate(strings)}
    namespace_index = indexes[ANDROID_NS]
    none = 0xFFFFFFFF
    chunks = [xml_string_pool(strings)]

    resources = b''.join(u32(value) for _, value in attributes)
    chunks.append(struct.pack('<HHI', 0x0180, 8, 8 + len(resources)) + resources)

    def namespace(start: bool, line: int) -> bytes:
        return struct.pack('<HHIIIII', 0x0100 if start else 0x0101, 16, 24,
                           line, none, indexes['android'], namespace_index)

    def start(name: str, attrs: list[XmlAttribute], line: int) -> bytes:
        encoded = bytearray()
        for attr in attrs:
            attribute_ns = namespace_index if attr.namespace else none
            if isinstance(attr.value, bool):
                raw_value = none
                value_type = 0x12
                data = 0xFFFFFFFF if attr.value else 0
            elif isinstance(attr.value, int):
                raw_value = indexes[attr.raw] if attr.raw else none
                value_type = attr.value_type if attr.value_type is not None else 0x10
                data = attr.value
            else:
                raw_value = indexes[attr.value]
                value_type = 0x03
                data = indexes[attr.value]
            encoded.extend(struct.pack('<IIIHBBI', attribute_ns, indexes[attr.name],
                                       raw_value, 8, 0, value_type, data))

        size = 36 + len(encoded)
        header = struct.pack('<HHIII', 0x0102, 16, size, line, none)
        extension = struct.pack('<IIHHHHHH', none, indexes[name], 20, 20,
                                len(attrs), 0, 0, 0)
        return header + extension + encoded

    def end(name: str, line: int) -> bytes:
        return struct.pack('<HHIIIII', 0x0103, 16, 24, line, none, none, indexes[name])

    chunks.append(namespace(True, 1))
    chunks.append(start('manifest', [
        XmlAttribute('versionCode', VERSION_CODE),
        XmlAttribute('versionName', VERSION_NAME),
        XmlAttribute('package', PACKAGE, namespace=False),
    ], 2))
    chunks.append(start('uses-sdk', [
        XmlAttribute('minSdkVersion', 24),
        XmlAttribute('targetSdkVersion', TARGET_SDK),
    ], 3))
    chunks.append(end('uses-sdk', 3))
    permissions = [
        ('android.permission.INTERNET', None),
        ('android.permission.ACCESS_WIFI_STATE', None),
        ('android.permission.BLUETOOTH', 30),
        ('android.permission.BLUETOOTH_CONNECT', None),
        ('android.permission.RECORD_AUDIO', None),
    ]
    for permission, maximum_sdk in permissions:
        attrs = [XmlAttribute('name', permission)]
        if maximum_sdk is not None:
            attrs.append(XmlAttribute('maxSdkVersion', maximum_sdk))
        chunks.append(start('uses-permission', attrs, 3))
        chunks.append(end('uses-permission', 3))
    chunks.append(start('application', [
        XmlAttribute('label', APP_LABEL),
        XmlAttribute('icon', LAUNCHER_ICON_ID, value_type=0x01),
    ], 4))
    chunks.append(start('activity', [
        XmlAttribute('name', MAIN_CLASS),
        XmlAttribute('exported', True),
        XmlAttribute('screenOrientation', 0, raw='landscape'),
    ], 5))
    chunks.append(start('intent-filter', [], 6))
    chunks.append(start('action', [
        XmlAttribute('name', 'android.intent.action.MAIN'),
    ], 7))
    chunks.append(end('action', 7))
    chunks.append(start('category', [
        XmlAttribute('name', 'android.intent.category.LAUNCHER'),
    ], 8))
    chunks.append(end('category', 8))
    chunks.append(end('intent-filter', 9))
    chunks.append(end('activity', 10))
    chunks.append(end('application', 11))
    chunks.append(end('manifest', 12))
    chunks.append(namespace(False, 13))
    contents = b''.join(chunks)
    return struct.pack('<HHI', 0x0003, 8, 8 + len(contents)) + contents


@dataclass(frozen=True)
class MethodSpec:
    owner: str
    name: str
    result: str
    parameters: tuple[str, ...] = ()


def build_legacy_dex() -> bytes:
    activity = 'Landroid/app/Activity;'
    context = 'Landroid/content/Context;'
    bundle = 'Landroid/os/Bundle;'
    view = 'Landroid/view/View;'
    window = 'Landroid/view/Window;'
    settings = 'Landroid/webkit/WebSettings;'
    webview = 'Landroid/webkit/WebView;'
    string_type = 'Ljava/lang/String;'

    specifications = [
        MethodSpec(activity, '<init>', 'V'),
        MethodSpec(activity, 'onCreate', 'V', (bundle,)),
        MethodSpec(activity, 'requestWindowFeature', 'Z', ('I',)),
        MethodSpec(activity, 'getWindow', window),
        MethodSpec(activity, 'setContentView', 'V', (view,)),
        MethodSpec(window, 'setFlags', 'V', ('I', 'I')),
        MethodSpec(settings, 'setJavaScriptEnabled', 'V', ('Z',)),
        MethodSpec(settings, 'setDomStorageEnabled', 'V', ('Z',)),
        MethodSpec(settings, 'setMediaPlaybackRequiresUserGesture', 'V', ('Z',)),
        MethodSpec(webview, '<init>', 'V', (context,)),
        MethodSpec(webview, 'getSettings', settings),
        MethodSpec(webview, 'loadUrl', 'V', (string_type,)),
        MethodSpec(MAIN_DESCRIPTOR, '<init>', 'V'),
        MethodSpec(MAIN_DESCRIPTOR, 'onCreate', 'V', (bundle,)),
    ]

    descriptors = sorted({
        activity, context, bundle, view, window, settings, webview,
        string_type, MAIN_DESCRIPTOR, 'I', 'V', 'Z',
    })

    def short_type(descriptor: str) -> str:
        return 'L' if descriptor.startswith('L') or descriptor.startswith('[') else descriptor

    proto_specs = {(item.result, item.parameters) for item in specifications}
    shorties = {
        short_type(result) + ''.join(short_type(item) for item in parameters)
        for result, parameters in proto_specs
    }
    url = 'file:///android_asset/index.html'
    strings = sorted(set(descriptors) | {item.name for item in specifications} |
                     shorties | {url, 'MainActivity.java'})
    string_idx = {item: index for index, item in enumerate(strings)}
    descriptors = sorted(descriptors, key=lambda item: string_idx[item])
    type_idx = {item: index for index, item in enumerate(descriptors)}

    protos = sorted(proto_specs,
                    key=lambda item: (type_idx[item[0]],
                                      tuple(type_idx[value] for value in item[1])))
    proto_idx = {item: index for index, item in enumerate(protos)}

    methods = sorted(set(specifications),
                     key=lambda item: (type_idx[item.owner], string_idx[item.name],
                                       proto_idx[(item.result, item.parameters)]))
    method_idx = {item: index for index, item in enumerate(methods)}

    header_size = 112
    string_ids_off = header_size
    type_ids_off = string_ids_off + 4 * len(strings)
    proto_ids_off = type_ids_off + 4 * len(descriptors)
    method_ids_off = proto_ids_off + 12 * len(protos)
    class_defs_off = method_ids_off + 8 * len(methods)
    data_off = class_defs_off + 32
    data = bytearray(data_off)

    string_offsets: dict[str, int] = {}
    first_string_data = len(data)
    for value in strings:
        string_offsets[value] = len(data)
        encoded = value.encode('utf-8')
        data.extend(uleb(len(value.encode('utf-16-le')) // 2))
        data.extend(encoded)
        data.append(0)

    parameter_lists: dict[tuple[str, ...], int] = {}
    for _, parameters in protos:
        if not parameters or parameters in parameter_lists:
            continue
        align(data)
        parameter_lists[parameters] = len(data)
        data.extend(u32(len(parameters)))
        for item in parameters:
            data.extend(u16(type_idx[item]))

    def invoke(opcode: int, method: MethodSpec, registers: list[int]) -> list[int]:
        if len(registers) > 5:
            raise ValueError('Too many invoke registers')
        packed = 0
        for index, register in enumerate(registers[:4]):
            packed |= register << (4 * index)
        fifth = registers[4] if len(registers) == 5 else 0
        return [opcode | (fifth << 8) | (len(registers) << 12),
                method_idx[method], packed]

    def add_code(registers: int, incoming: int, outgoing: int, instructions: list[int]) -> int:
        align(data)
        offset = len(data)
        data.extend(struct.pack('<HHHHII', registers, incoming, outgoing, 0, 0,
                                len(instructions)))
        data.extend(b''.join(u16(item) for item in instructions))
        return offset

    constructor_instructions = invoke(0x70, MethodSpec(activity, '<init>', 'V'), [0])
    constructor_instructions.append(0x000E)
    constructor_off = add_code(1, 1, 1, constructor_instructions)

    body: list[int] = []
    body.extend(invoke(0x6F, MethodSpec(activity, 'onCreate', 'V', (bundle,)), [3, 4]))
    body.append(0x1012)  # const/4 v0, 1
    body.extend(invoke(0x6E, MethodSpec(activity, 'requestWindowFeature', 'Z', ('I',)),
                       [3, 0]))
    body.extend(invoke(0x6E, MethodSpec(activity, 'getWindow', window), [3]))
    body.append(0x020C)  # move-result-object v2
    body.extend([0x0013, 0x0400])  # const/16 v0, FLAG_FULLSCREEN
    body.extend(invoke(0x6E, MethodSpec(window, 'setFlags', 'V', ('I', 'I')),
                       [2, 0, 0]))
    body.extend([0x0122, type_idx[webview]])  # new-instance v1, WebView
    body.extend(invoke(0x70, MethodSpec(webview, '<init>', 'V', (context,)), [1, 3]))
    body.extend(invoke(0x6E, MethodSpec(webview, 'getSettings', settings), [1]))
    body.append(0x020C)  # move-result-object v2
    body.append(0x1012)  # const/4 v0, true
    body.extend(invoke(0x6E, MethodSpec(settings, 'setJavaScriptEnabled', 'V', ('Z',)),
                       [2, 0]))
    body.extend(invoke(0x6E, MethodSpec(settings, 'setDomStorageEnabled', 'V', ('Z',)),
                       [2, 0]))
    body.append(0x0012)  # const/4 v0, false: event audio may play after animation.
    body.extend(invoke(0x6E, MethodSpec(settings, 'setMediaPlaybackRequiresUserGesture',
                                        'V', ('Z',)), [2, 0]))
    body.extend(invoke(0x6E, MethodSpec(activity, 'setContentView', 'V', (view,)),
                       [3, 1]))
    body.extend([0x001A, string_idx[url]])  # const-string v0, asset URL
    body.extend(invoke(0x6E, MethodSpec(webview, 'loadUrl', 'V', (string_type,)),
                       [1, 0]))
    body.append(0x000E)
    on_create_off = add_code(5, 2, 3, body)

    class_data_off = len(data)
    own_init = method_idx[MethodSpec(MAIN_DESCRIPTOR, '<init>', 'V')]
    own_on_create = method_idx[MethodSpec(MAIN_DESCRIPTOR, 'onCreate', 'V', (bundle,))]
    data.extend(uleb(0) + uleb(0) + uleb(1) + uleb(1))
    data.extend(uleb(own_init) + uleb(0x10001) + uleb(constructor_off))
    data.extend(uleb(own_on_create) + uleb(0x0001) + uleb(on_create_off))

    align(data)
    map_off = len(data)
    map_items = [
        (0x0000, 1, 0),
        (0x0001, len(strings), string_ids_off),
        (0x0002, len(descriptors), type_ids_off),
        (0x0003, len(protos), proto_ids_off),
        (0x0005, len(methods), method_ids_off),
        (0x0006, 1, class_defs_off),
        (0x2002, len(strings), first_string_data),
        (0x1001, len(parameter_lists), min(parameter_lists.values())),
        (0x2001, 2, constructor_off),
        (0x2000, 1, class_data_off),
        (0x1000, 1, map_off),
    ]
    map_items.sort(key=lambda item: item[2])
    data.extend(u32(len(map_items)))
    for item_type, count, offset in map_items:
        data.extend(struct.pack('<HHII', item_type, 0, count, offset))

    for index, value in enumerate(strings):
        struct.pack_into('<I', data, string_ids_off + index * 4, string_offsets[value])
    for index, value in enumerate(descriptors):
        struct.pack_into('<I', data, type_ids_off + index * 4, string_idx[value])
    for index, (result, parameters) in enumerate(protos):
        shorty = short_type(result) + ''.join(short_type(item) for item in parameters)
        struct.pack_into('<III', data, proto_ids_off + index * 12, string_idx[shorty],
                         type_idx[result], parameter_lists.get(parameters, 0))
    for index, item in enumerate(methods):
        struct.pack_into('<HHI', data, method_ids_off + index * 8, type_idx[item.owner],
                         proto_idx[(item.result, item.parameters)], string_idx[item.name])

    struct.pack_into('<IIIIIIII', data, class_defs_off,
                     type_idx[MAIN_DESCRIPTOR], 0x0001, type_idx[activity], 0,
                     string_idx['MainActivity.java'], 0, class_data_off, 0)

    data[0:8] = b'dex\n035\0'
    struct.pack_into('<20I', data, 32,
                     len(data), header_size, 0x12345678, 0, 0, map_off,
                     len(strings), string_ids_off,
                     len(descriptors), type_ids_off,
                     len(protos), proto_ids_off,
                     0, 0,
                     len(methods), method_ids_off,
                     1, class_defs_off,
                     len(data) - data_off, data_off)
    data[12:32] = hashlib.sha1(data[32:]).digest()
    struct.pack_into('<I', data, 8, zlib.adler32(data[12:]) & 0xFFFFFFFF)
    return bytes(data)


def build_dex() -> bytes:
    """Include the real TCP/Bluetooth transport and its JavaScript bridge."""
    from native_dex import build_network_dex

    return build_network_dex(MAIN_DESCRIPTOR)


def digest_line(data: bytes) -> bytes:
    return base64.b64encode(hashlib.sha256(data).digest())


def jar_header(name: bytes, value: bytes) -> bytes:
    raw = name + b': ' + value
    parts = []
    while len(raw) > 70:
        parts.append(raw[:70])
        raw = b' ' + raw[70:]
    parts.append(raw)
    return b'\r\n'.join(parts) + b'\r\n'


def make_certificate() -> tuple[rsa.RSAPrivateKey, x509.Certificate]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, 'Keys & Claws Android Game'),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, 'Keys & Claws'),
    ])
    now = dt.datetime.now(dt.timezone.utc)
    certificate = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(now + dt.timedelta(days=3650))
        .sign(key, hashes.SHA256())
    )
    return key, certificate


def v1_signature(entries: dict[str, bytes], key: rsa.RSAPrivateKey,
                 certificate: x509.Certificate) -> dict[str, bytes]:
    main = b'Manifest-Version: 1.0\r\nCreated-By: Keys and Claws\r\n\r\n'
    sections: dict[str, bytes] = {}
    for name in sorted(entries):
        sections[name] = (
            jar_header(b'Name', name.encode('utf-8'))
            + jar_header(b'SHA-256-Digest', digest_line(entries[name]))
            + b'\r\n'
        )
    manifest = main + b''.join(sections.values())
    sf = (
        b'Signature-Version: 1.0\r\n'
        b'Created-By: Keys and Claws\r\n'
        + jar_header(b'SHA-256-Digest-Manifest', digest_line(manifest))
        + jar_header(b'SHA-256-Digest-Manifest-Main-Attributes', digest_line(main))
        + b'\r\n'
    )
    for name, section in sections.items():
        sf += jar_header(b'Name', name.encode('utf-8'))
        sf += jar_header(b'SHA-256-Digest', digest_line(section))
        sf += b'\r\n'
    block = (
        pkcs7.PKCS7SignatureBuilder()
        .set_data(sf)
        .add_signer(certificate, key, hashes.SHA256(), rsa_padding=padding.PKCS1v15())
        .sign(serialization.Encoding.DER,
              [pkcs7.PKCS7Options.Binary, pkcs7.PKCS7Options.DetachedSignature])
    )
    return {
        'META-INF/MANIFEST.MF': manifest,
        'META-INF/CERT.SF': sf,
        'META-INF/CERT.RSA': block,
    }


def zip_end(apk: bytes) -> tuple[int, int, int]:
    offset = apk.rfind(b'PK\x05\x06')
    if offset < 0:
        raise ValueError('ZIP end-of-central-directory record not found')
    directory_size, directory_offset = struct.unpack_from('<II', apk, offset + 12)
    return offset, directory_offset, directory_size


def content_digest(sections: list[bytes]) -> bytes:
    chunk_hashes: list[bytes] = []
    chunk_size = 1024 * 1024
    for section in sections:
        for offset in range(0, len(section), chunk_size):
            chunk = section[offset:offset + chunk_size]
            chunk_hashes.append(hashlib.sha256(b'\xA5' + u32(len(chunk)) + chunk).digest())
    return hashlib.sha256(b'\x5A' + u32(len(chunk_hashes))
                          + b''.join(chunk_hashes)).digest()


def sign_v2(apk: bytes, key: rsa.RSAPrivateKey,
            certificate: x509.Certificate) -> bytes:
    eocd_offset, directory_offset, _ = zip_end(apk)
    entries = apk[:directory_offset]
    directory = apk[directory_offset:eocd_offset]
    eocd = apk[eocd_offset:]

    digest = content_digest([entries, directory, eocd])
    algorithm = 0x0103  # RSA PKCS#1 v1.5 with SHA-256.
    digest_record = prefixed(u32(algorithm) + prefixed(digest))
    certificate_der = certificate.public_bytes(serialization.Encoding.DER)
    signed_data = prefixed(digest_record) + prefixed(prefixed(certificate_der)) + prefixed(b'')
    signature = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    signature_record = prefixed(u32(algorithm) + prefixed(signature))
    public_key = key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    signer = prefixed(signed_data) + prefixed(signature_record) + prefixed(public_key)
    v2_value = prefixed(prefixed(signer))
    pair = u64(4 + len(v2_value)) + u32(0x7109871A) + v2_value

    block_size = len(pair) + 24
    signing_block = u64(block_size) + pair + u64(block_size) + b'APK Sig Block 42'
    updated_eocd = bytearray(eocd)
    struct.pack_into('<I', updated_eocd, 16, directory_offset + len(signing_block))
    return entries + signing_block + directory + updated_eocd


def build() -> Path:
    entries = {
        'AndroidManifest.xml': build_manifest(),
        'classes.dex': build_dex(),
        'resources.arsc': build_resource_table(),
        'res/drawable/ic_launcher.png': (SHARED_ASSETS / 'ic_launcher.png').read_bytes(),
        'assets/index.html': (PROJECT / 'index.html').read_bytes(),
        'assets/rules.html': (PROJECT / 'rules.html').read_bytes(),
        'assets/style.css': (PROJECT / 'style.css').read_bytes(),
        'assets/game.js': (PROJECT / 'game.js').read_bytes(),
        'assets/world3d.js': (PROJECT / 'world3d.js').read_bytes(),
        'assets/map.jpg': (SHARED_ASSETS / 'map.jpg').read_bytes(),
        'assets/logo.png': (SHARED_ASSETS / 'logo.png').read_bytes(),
    }
    for sound in sorted((SHARED_ASSETS / 'sounds').iterdir()):
        if sound.is_file() and sound.suffix.lower() in {'.mp3', '.wav'}:
            entries['assets/sounds/' + sound.name] = sound.read_bytes()
    artwork = PROJECT / 'art'
    if not artwork.is_dir():
        raise FileNotFoundError('Approved independent jungle artwork is missing')
    for asset in sorted(artwork.iterdir()):
        if asset.is_file() and asset.suffix.lower() in {'.png', '.jpg', '.json'}:
            entries['assets/art/' + asset.name] = asset.read_bytes()
    key, certificate = make_certificate()
    entries.update(v1_signature(entries, key, certificate))

    unsigned = io.BytesIO()
    with zipfile.ZipFile(unsigned, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, contents in entries.items():
            item = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            item.compress_type = (zipfile.ZIP_STORED
                                  if name.endswith('.jpg') or name == 'resources.arsc'
                                  else zipfile.ZIP_DEFLATED)
            if name == 'resources.arsc':
                padding = (-(unsigned.tell() + 30 + len(name.encode('utf-8')) + 4)) % 4
                item.extra = struct.pack('<HH', 0xCAFE, padding) + bytes(padding)
            item.external_attr = 0o644 << 16
            archive.writestr(item, contents)

    signed = sign_v2(unsigned.getvalue(), key, certificate)
    OUTPUT.write_bytes(signed)
    metadata = {
        'apk': str(OUTPUT),
        'package': PACKAGE,
        'main_activity': MAIN_CLASS,
        'minimum_android_api': 24,
        'target_android_api': TARGET_SDK,
        'app_label': APP_LABEL,
        'version_name': VERSION_NAME,
        'bytes': len(signed),
        'entries': sorted(entries),
        'sha256': hashlib.sha256(signed).hexdigest(),
        'certificate_sha256': certificate.fingerprint(hashes.SHA256()).hex(),
    }
    print(json.dumps(metadata, indent=2))
    return OUTPUT


if __name__ == '__main__':
    build()
