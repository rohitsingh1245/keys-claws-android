#!/usr/bin/env python3
"""Independently inspect Android manifest, Dalvik bytecode, and APK signatures."""

from __future__ import annotations

import base64
import hashlib
import json
import shutil
import struct
import subprocess
import tempfile
import zipfile
import zlib
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from build_apk import (
    APP_LABEL, LAUNCHER_ICON_ID, MAIN_CLASS, MAIN_DESCRIPTOR, OUTPUT, PACKAGE,
    TARGET_SDK, VERSION_CODE, VERSION_NAME, content_digest, zip_end,
)


def read_u32(data: bytes, offset: int) -> int:
    return struct.unpack_from('<I', data, offset)[0]


def read_u64(data: bytes, offset: int) -> int:
    return struct.unpack_from('<Q', data, offset)[0]


def read_uleb(data: bytes, offset: int) -> tuple[int, int]:
    value = 0
    shift = 0
    while True:
        current = data[offset]
        offset += 1
        value |= (current & 0x7f) << shift
        if not current & 0x80:
            return value, offset
        shift += 7
        assert shift <= 28


def validate_dalvik_code(data: bytes, offset: int, string_count: int,
                         type_count: int, field_count: int,
                         method_count: int) -> dict:
    registers, incoming, outgoing, tries, _, size = struct.unpack_from(
        '<HHHHII', data, offset)
    assert registers >= incoming and size > 0
    words = struct.unpack_from('<' + 'H' * size, data, offset + 16)
    cursor = 0
    starts = set()
    targets = []
    previous_invoke = False
    while cursor < size:
        starts.add(cursor)
        first = words[cursor]
        opcode = first & 0xff
        register_a = first >> 8 & 0xf
        register_b = first >> 12 & 0xf
        previous = previous_invoke
        previous_invoke = False
        if opcode in (0x0a, 0x0c, 0x0d, 0x0f, 0x11):
            assert first >> 8 < registers
            if opcode in (0x0a, 0x0c):
                assert previous
            width = 1
        elif opcode == 0x0e:
            width = 1
        elif opcode == 0x12:
            assert register_a < registers
            width = 1
        elif opcode in (0x13, 0x16, 0x1a, 0x1f, 0x22, 0x60):
            assert first >> 8 < registers
            if opcode == 0x16:
                assert (first >> 8) + 1 < registers
            if opcode == 0x1a:
                assert words[cursor + 1] < string_count
            if opcode in (0x1f, 0x22):
                assert words[cursor + 1] < type_count
            if opcode == 0x60:
                assert words[cursor + 1] < field_count
            width = 2
        elif opcode == 0x14:
            assert first >> 8 < registers
            width = 3
        elif opcode == 0x23:
            assert register_a < registers and register_b < registers
            assert words[cursor + 1] < type_count
            width = 2
        elif opcode in (0x29, 0x32, 0x34, 0x38):
            if opcode != 0x29:
                assert register_a < registers
            if opcode in (0x32, 0x34):
                assert register_b < registers
            distance = struct.unpack('<h', struct.pack('<H', words[cursor + 1]))[0]
            assert distance
            targets.append(cursor + distance)
            width = 2
        elif opcode == 0x4d:
            assert first >> 8 < registers
            assert words[cursor + 1] & 0xff < registers
            assert words[cursor + 1] >> 8 < registers
            width = 2
        elif opcode in (0x52, 0x54, 0x59, 0x5b):
            assert register_a < registers and register_b < registers
            assert words[cursor + 1] < field_count
            width = 2
        elif opcode in (0x6e, 0x6f, 0x70, 0x71, 0x72):
            count = first >> 12
            fifth = first >> 8 & 0xf
            assert count <= 5 and count <= outgoing
            assert words[cursor + 1] < method_count
            packed = words[cursor + 2]
            arguments = [(packed >> (4 * index)) & 0xf
                         for index in range(min(4, count))]
            if count == 5:
                arguments.append(fifth)
            assert all(argument < registers for argument in arguments)
            previous_invoke = True
            width = 3
        else:
            raise AssertionError('Unsupported or invalid Dalvik opcode ' + hex(opcode))
        assert cursor + width <= size
        cursor += width
    assert set(targets) <= starts

    if tries:
        assert tries == 1
        try_offset = offset + 16 + size * 2 + (2 if size % 2 else 0)
        start_address, protected_size, handler_offset = struct.unpack_from(
            '<IHH', data, try_offset)
        assert start_address == 0 and protected_size in starts
        handlers = try_offset + 8
        handler_count, handler_start = read_uleb(data, handlers)
        assert handler_count == 1 and handler_offset == handler_start - handlers
        assert data[handler_start] == 0  # catch-all
        handler_address, _ = read_uleb(data, handler_start + 1)
        assert handler_address == protected_size and handler_address in starts
        assert words[handler_address] & 0xff == 0x0d  # move-exception

    return {'registers': registers, 'incoming': incoming,
            'outgoing': outgoing, 'tries': tries, 'instructions': size,
            'branch_targets_valid': True}


def get_prefixed(data: bytes, offset: int = 0) -> tuple[bytes, int]:
    size = read_u32(data, offset)
    end = offset + 4 + size
    if end > len(data):
        raise AssertionError('Length-prefixed APK signature value exceeds its container')
    return data[offset + 4:end], end


def parse_manifest(data: bytes) -> dict:
    chunk_type, header_size, total = struct.unpack_from('<HHI', data, 0)
    assert chunk_type == 0x0003 and header_size == 8 and total == len(data)
    offset = 8
    strings: list[str] = []
    elements = []
    while offset < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, offset)
        assert size >= header and offset + size <= len(data)
        if kind == 0x0001:
            count, _, flags, strings_start, _ = struct.unpack_from('<IIIII', data, offset + 8)
            assert flags & 0x100
            for index in range(count):
                relative = read_u32(data, offset + header + index * 4)
                start = offset + strings_start + relative
                utf8_length = data[start + 1]
                strings.append(data[start + 2:start + 2 + utf8_length].decode('utf-8'))
        elif kind == 0x0102:
            name = read_u32(data, offset + 20)
            count = struct.unpack_from('<H', data, offset + 28)[0]
            attrs = {}
            cursor = offset + 36
            for _ in range(count):
                namespace, attr_name, raw, value_size, _, value_type, value = struct.unpack_from(
                    '<IIIHBBI', data, cursor)
                assert value_size == 8
                if value_type == 0x03:
                    parsed = strings[value]
                elif value_type == 0x12:
                    parsed = bool(value)
                else:
                    parsed = value
                attrs[strings[attr_name]] = parsed
                cursor += 20
            elements.append({'name': strings[name], 'attributes': attrs})
        offset += size

    by_name = {element['name']: element['attributes'] for element in elements}
    assert by_name['manifest']['package'] == PACKAGE
    assert by_name['manifest']['versionCode'] == VERSION_CODE
    assert by_name['manifest']['versionName'] == VERSION_NAME
    assert by_name['uses-sdk']['minSdkVersion'] == 24
    assert by_name['uses-sdk']['targetSdkVersion'] == TARGET_SDK
    assert by_name['application']['label'] == APP_LABEL
    assert by_name['application']['icon'] == LAUNCHER_ICON_ID
    assert by_name['activity']['name'] == MAIN_CLASS
    assert by_name['activity']['exported'] is True
    assert by_name['activity']['screenOrientation'] == 0
    assert by_name['action']['name'] == 'android.intent.action.MAIN'
    assert by_name['category']['name'] == 'android.intent.category.LAUNCHER'
    permissions = {element['attributes']['name']: element['attributes']
                   for element in elements if element['name'] == 'uses-permission'}
    required_permissions = {
        'android.permission.INTERNET',
        'android.permission.ACCESS_WIFI_STATE',
        'android.permission.BLUETOOTH',
        'android.permission.BLUETOOTH_CONNECT',
        'android.permission.RECORD_AUDIO',
    }
    assert set(permissions) == required_permissions
    assert permissions['android.permission.BLUETOOTH']['maxSdkVersion'] == 30
    return {'package': PACKAGE, 'activity': MAIN_CLASS, 'label': APP_LABEL,
            'icon_resource': hex(LAUNCHER_ICON_ID), 'version_code': VERSION_CODE,
            'version_name': VERSION_NAME, 'min_sdk': 24,
            'target_sdk': TARGET_SDK, 'landscape': True, 'launcher': True,
            'permissions': sorted(permissions)}


def parse_resource_table(data: bytes, archive: zipfile.ZipFile) -> dict:
    kind, header_size, total_size, packages = struct.unpack_from('<HHII', data, 0)
    assert kind == 0x0002 and header_size == 12 and total_size == len(data)
    assert packages == 1
    global_kind, _, global_size = struct.unpack_from('<HHI', data, header_size)
    assert global_kind == 0x0001
    package_offset = header_size + global_size
    package_kind, package_header, package_size, package_id = struct.unpack_from(
        '<HHII', data, package_offset)
    assert package_kind == 0x0200 and package_header == 288 and package_id == 0x7F
    assert package_offset + package_size == len(data)
    package_name = data[package_offset + 12:package_offset + 268].decode('utf-16-le').split('\0')[0]
    assert package_name == PACKAGE
    type_offset, _, key_offset, _, _ = struct.unpack_from('<IIIII', data, package_offset + 268)
    assert type_offset == package_header and key_offset > type_offset
    key_kind, _, key_size = struct.unpack_from('<HHI', data, package_offset + key_offset)
    assert key_kind == 0x0001
    spec_offset = package_offset + key_offset + key_size
    spec_kind, spec_header, spec_size = struct.unpack_from('<HHI', data, spec_offset)
    assert spec_kind == 0x0202 and spec_header == 16 and spec_size == 20
    type_position = spec_offset + spec_size
    type_kind, type_header, type_size, type_id, _, _, count, entries_start = struct.unpack_from(
        '<HHIBBHII', data, type_position)
    assert type_kind == 0x0201 and type_id == 1 and count == 1
    assert type_position + type_size == len(data)
    entry_offset = type_position + entries_start
    entry_size, _, key_index = struct.unpack_from('<HHI', data, entry_offset)
    value_size, _, value_kind, string_index = struct.unpack_from('<HBBI', data, entry_offset + 8)
    assert entry_size == 8 and key_index == 0
    assert value_size == 8 and value_kind == 0x03 and string_index == 0
    info = archive.getinfo('resources.arsc')
    assert info.compress_type == zipfile.ZIP_STORED
    resource_data_offset = (info.header_offset + 30
                            + len(info.filename.encode('utf-8')) + len(info.extra))
    assert resource_data_offset % 4 == 0
    assert archive.read('res/drawable/ic_launcher.png').startswith(b'\x89PNG\r\n\x1a\n')
    return {'package': package_name, 'drawable_id': hex(LAUNCHER_ICON_ID),
            'launcher_icon_present': True, 'resources_uncompressed': True,
            'resources_four_byte_aligned': True}


def parse_dex(data: bytes) -> dict:
    assert data[:8] == b'dex\n035\0'
    assert read_u32(data, 8) == zlib.adler32(data[12:]) & 0xFFFFFFFF
    assert data[12:32] == hashlib.sha1(data[32:]).digest()
    fields = struct.unpack_from('<20I', data, 32)
    (file_size, header_size, endian, _, _, map_off,
     string_count, string_off, type_count, type_off,
     proto_count, proto_off, field_count, field_off,
     method_count, method_off, class_count, class_off,
     data_size, data_off) = fields
    assert file_size == len(data) and header_size == 112 and endian == 0x12345678
    assert class_count == 1 and method_count >= 60 and proto_count >= 5
    assert field_count >= 10 and field_off > proto_off
    strings = []
    for index in range(string_count):
        cursor = read_u32(data, string_off + index * 4)
        while data[cursor] & 0x80:
            cursor += 1
        cursor += 1
        end = data.index(0, cursor)
        strings.append(data[cursor:end].decode('utf-8'))
    assert strings == sorted(strings)
    assert MAIN_DESCRIPTOR in strings
    assert 'file:///android_asset/index.html' in strings
    for required in ['onCreate', 'getSettings', 'setJavaScriptEnabled',
                     'setDomStorageEnabled', 'setMediaPlaybackRequiresUserGesture',
                     'loadUrl', 'setContentView', 'addJavascriptInterface',
                     'requestPermissions', 'hostWifi', 'hostWifiPlayers', 'joinWifi',
                     'hostBluetooth', 'joinBluetooth', 'bondedDevices',
                     'localAddress', 'poll', 'send', 'disconnect', 'run',
                     'listenUsingRfcommWithServiceRecord',
                     'createRfcommSocketToServiceRecord', 'getBondedDevices',
                     'readUTF', 'writeUTF', 'available', 'sleep',
                     'wifiExpected', 'wifiSocket2', 'wifiSocket3',
                     'input2', 'input3', 'output2', 'output3',
                     'Landroid/webkit/JavascriptInterface;',
                     'Landroid/bluetooth/BluetoothSocket;',
                     'Ljava/net/ServerSocket;', 'Ljava/net/Socket;']:
        assert required in strings

    descriptors = [strings[read_u32(data, type_off + index * 4)]
                   for index in range(type_count)]
    methods = []
    for index in range(method_count):
        owner, proto, name = struct.unpack_from('<HHI', data, method_off + index * 8)
        assert owner < type_count and proto < proto_count and name < string_count
        methods.append((descriptors[owner], strings[name]))

    class_type, _, superclass, interface_off, _, annotation_off, class_data_off, _ = (
        struct.unpack_from('<IIIIIIII', data, class_off))
    assert descriptors[class_type] == MAIN_DESCRIPTOR
    assert descriptors[superclass] == 'Landroid/app/Activity;'
    assert read_u32(data, interface_off) == 1
    runnable_index = struct.unpack_from('<H', data, interface_off + 4)[0]
    assert descriptors[runnable_index] == 'Ljava/lang/Runnable;'

    class_annotations, annotated_fields, annotated_methods, annotated_parameters = (
        struct.unpack_from('<IIII', data, annotation_off))
    assert class_annotations == annotated_fields == annotated_parameters == 0
    expected_bridge = {'hostWifi', 'hostWifiPlayers', 'joinWifi', 'hostBluetooth', 'joinBluetooth',
                       'bondedDevices', 'localAddress', 'poll', 'send', 'disconnect'}
    actual_bridge = set()
    for index in range(annotated_methods):
        method_number, annotation_set = struct.unpack_from(
            '<II', data, annotation_off + 16 + index * 8)
        owner, name = methods[method_number]
        assert owner == MAIN_DESCRIPTOR
        assert read_u32(data, annotation_set) == 1
        item_offset = read_u32(data, annotation_set + 4)
        assert data[item_offset] == 1  # runtime-visible JavascriptInterface
        annotation_type, cursor = read_uleb(data, item_offset + 1)
        assert descriptors[annotation_type] == 'Landroid/webkit/JavascriptInterface;'
        members, _ = read_uleb(data, cursor)
        assert members == 0
        actual_bridge.add(name)
    assert actual_bridge == expected_bridge

    cursor = class_data_off
    static_fields, cursor = read_uleb(data, cursor)
    instance_fields, cursor = read_uleb(data, cursor)
    direct_methods, cursor = read_uleb(data, cursor)
    virtual_methods, cursor = read_uleb(data, cursor)
    assert static_fields == 0 and instance_fields == 16
    for _ in range(instance_fields):
        _, cursor = read_uleb(data, cursor)
        _, cursor = read_uleb(data, cursor)
    defined_methods = {}
    for group_count in (direct_methods, virtual_methods):
        current_index = 0
        for _ in range(group_count):
            difference, cursor = read_uleb(data, cursor)
            current_index += difference
            _, cursor = read_uleb(data, cursor)
            code_offset, cursor = read_uleb(data, cursor)
            assert code_offset and code_offset % 4 == 0
            defined_methods[methods[current_index][1]] = validate_dalvik_code(
                data, code_offset, string_count, type_count, field_count,
                method_count)
    assert expected_bridge <= set(defined_methods)
    assert defined_methods['run']['tries'] == 1
    return {'version': '035', 'strings': string_count, 'methods': method_count,
            'fields': field_count, 'classes': class_count,
            'runtime_javascript_bridge': sorted(actual_bridge),
            'native_tcp_and_bluetooth_transport': True,
            'native_wifi_host_supports_four_devices': True,
            'network_exception_handler': True,
            'dalvik_instructions_and_branches_verified': True,
            'sha1_and_adler32_valid': True}


def parse_manifest_sections(content: bytes) -> dict[str, dict[str, str]]:
    sections = content.split(b'\r\n\r\n')
    result = {}
    for section in sections:
        if not section:
            continue
        lines = []
        for raw in section.split(b'\r\n'):
            if raw.startswith(b' ') and lines:
                lines[-1] += raw[1:]
            else:
                lines.append(raw)
        attributes = {}
        for line in lines:
            key, _, value = line.partition(b': ')
            attributes[key.decode()] = value.decode()
        result[attributes.get('Name', '__main__')] = attributes
    return result


def verify_v1(archive: zipfile.ZipFile) -> dict:
    manifest = archive.read('META-INF/MANIFEST.MF')
    sf = archive.read('META-INF/CERT.SF')
    rsa = archive.read('META-INF/CERT.RSA')
    sections = parse_manifest_sections(manifest)
    for name in archive.namelist():
        if name.startswith('META-INF/'):
            continue
        expected = sections[name]['SHA-256-Digest']
        actual = base64.b64encode(hashlib.sha256(archive.read(name)).digest()).decode()
        assert expected == actual, name
    signature_sections = parse_manifest_sections(sf)
    actual_manifest = base64.b64encode(hashlib.sha256(manifest).digest()).decode()
    assert signature_sections['__main__']['SHA-256-Digest-Manifest'] == actual_manifest

    openssl = shutil.which('openssl')
    if not openssl:
        raise RuntimeError('OpenSSL is required for independent PKCS#7 verification')
    with tempfile.TemporaryDirectory() as directory:
        folder = Path(directory)
        (folder / 'signature.der').write_bytes(rsa)
        (folder / 'content.sf').write_bytes(sf)
        result = subprocess.run([
            openssl, 'cms', '-verify', '-binary', '-inform', 'DER',
            '-in', str(folder / 'signature.der'),
            '-content', str(folder / 'content.sf'),
            '-noverify', '-out', str(folder / 'verified.sf'),
        ], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
    return {'entries_verified': len(sections) - 1, 'pkcs7_verified': True}


def verify_v2(data: bytes) -> dict:
    eocd_offset, directory_offset, directory_size = zip_end(data)
    footer = directory_offset - 24
    assert data[footer + 8:footer + 24] == b'APK Sig Block 42'
    block_size = read_u64(data, footer)
    block_offset = directory_offset - block_size - 8
    assert read_u64(data, block_offset) == block_size

    cursor = block_offset + 8
    found = None
    while cursor < footer:
        length = read_u64(data, cursor)
        pair_id = read_u32(data, cursor + 8)
        value = data[cursor + 12:cursor + 8 + length]
        if pair_id == 0x7109871A:
            found = value
        cursor += 8 + length
    assert found is not None

    signers, end = get_prefixed(found)
    assert end == len(found)
    signer, end = get_prefixed(signers)
    assert end == len(signers)
    signed_data, offset = get_prefixed(signer)
    signatures, offset = get_prefixed(signer, offset)
    public_key_der, offset = get_prefixed(signer, offset)
    assert offset == len(signer)

    signature_record, end = get_prefixed(signatures)
    assert end == len(signatures)
    algorithm = read_u32(signature_record, 0)
    signature, end = get_prefixed(signature_record, 4)
    assert algorithm == 0x0103 and end == len(signature_record)
    public_key = serialization.load_der_public_key(public_key_der)
    public_key.verify(signature, signed_data, padding.PKCS1v15(), hashes.SHA256())

    digest_sequence, offset = get_prefixed(signed_data)
    certificate_sequence, offset = get_prefixed(signed_data, offset)
    attrs, offset = get_prefixed(signed_data, offset)
    assert offset == len(signed_data) and attrs == b''
    digest_record, end = get_prefixed(digest_sequence)
    assert end == len(digest_sequence) and read_u32(digest_record, 0) == algorithm
    expected_digest, end = get_prefixed(digest_record, 4)
    assert end == len(digest_record)
    cert_der, end = get_prefixed(certificate_sequence)
    assert end == len(certificate_sequence)
    certificate = x509.load_der_x509_certificate(cert_der)
    assert certificate.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ) == public_key_der

    eocd = bytearray(data[eocd_offset:])
    struct.pack_into('<I', eocd, 16, block_offset)
    actual_digest = content_digest([
        data[:block_offset],
        data[directory_offset:eocd_offset],
        bytes(eocd),
    ])
    assert actual_digest == expected_digest
    return {
        'scheme': 'APK Signature Scheme v2',
        'algorithm': 'RSA PKCS1 SHA-256',
        'signature_verified': True,
        'content_digest_verified': True,
        'certificate_sha256': certificate.fingerprint(hashes.SHA256()).hex(),
    }


def main() -> None:
    data = OUTPUT.read_bytes()
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        required = {
            'AndroidManifest.xml', 'classes.dex', 'resources.arsc',
            'res/drawable/ic_launcher.png', 'assets/index.html',
            'assets/rules.html', 'assets/style.css', 'assets/game.js', 'assets/world3d.js',
            'assets/map.jpg', 'assets/logo.png',
            'META-INF/MANIFEST.MF', 'META-INF/CERT.SF', 'META-INF/CERT.RSA',
        }
        required.update('assets/sounds/' + name + '.mp3' for name in [
            'bad', 'cry', 'fight', 'good', 'hurray', 'lion', 'relief',
            'step', 'win', 'wolf', 'jungle_ambience',
            'knife_pickup', 'axe_pickup', 'hammer_pickup', 'knife_use',
            'axe_use', 'hammer_hit', 'lock_break',
        ])
        required.update(
            f'assets/art/avatar_{explorer}_{frame:02d}.png'
            for explorer in ['ruby', 'river', 'forest', 'violet']
            for frame in range(1, 9)
        )
        required.update({
            'assets/sounds/gate_open.wav', 'assets/sounds/gate_close.wav',
            'assets/art/jungle_board.jpg', 'assets/art/jungle_terrain.jpg',
            'assets/art/jungle_natural.jpg',
            'assets/art/manifest.json',
            'assets/art/lion_idle.png', 'assets/art/lion_walk.png',
            'assets/art/lion_roar.png', 'assets/art/lion_sleep.png',
            'assets/art/wolf_idle.png', 'assets/art/wolf_walk.png',
            'assets/art/wolf_howl.png', 'assets/art/wolf_sleep.png',
            'assets/art/key_normal.png', 'assets/art/key_glow.png',
            'assets/art/key_turn.png', 'assets/art/gate_closed.png',
            'assets/art/gate_unlocking.png', 'assets/art/gate_open.png',
            'assets/art/gate_half_closing.png',
            'assets/art/gate_broken.png', 'assets/art/hammer.png',
        })
        assert names == required, names
        renderer = archive.read('assets/world3d.js').decode('utf-8')
        interface = archive.read('assets/index.html').decode('utf-8')
        rules_page = archive.read('assets/rules.html').decode('utf-8')
        for marker in ["getContext('webgl'", 'createShader', 'drawArrays',
                       'uViewProjection', 'buildAnimal', 'buildHuman']:
            assert marker in renderer, 'Missing archived historical renderer source: ' + marker
        assert 'id="board"' in interface
        assert 'src="game.js"' in interface
        assert 'QUEST FOR HOME · JUNGLE ADVENTURE' in interface
        for marker in ['id="help-btn"', 'id="setup-guide-btn"',
                       'id="setup-tutorial-btn"', 'id="field-guide-btn"',
                       'id="guide-overlay"', 'id="rules-frame"',
                       'id="tutorial-overlay"', 'id="tutorial-next-btn"',
                       'id="victory-rankings"', 'Final explorer rankings']:
            assert marker in interface, 'Missing rules/tutorial navigation: ' + marker
        for marker in ['id="settings-ambience-btn"', 'id="settings-jungle-btn"',
                       'Jungle ambience', 'Living jungle']:
            assert marker in interface, 'Missing living-jungle control: ' + marker
        for marker in ['How to Play', '3 → 11', '12 → 18', '25 → 29',
                       'Lion · Space 17', 'Wolf · Space 27',
                       'spaces 13 and 26', 'space 15', 'space 31',
                       'space 33', 'space 35', 'space 30',
                       'hammer', '2–4 separate devices', '1st, 2nd, or 3rd place',
                       'last place', 'final ranks']:
            assert marker in rules_page, 'Missing approved rule on separate page: ' + marker
        assert 'src="world3d.js"' not in rules_page
        for unwanted in ['id="world-3d"', 'id="world-art"', 'id="world-labels"',
                         'id="world-toolbar"', 'id="camera-mode-btn"',
                         'id="fullscreen-board-btn"', 'id="zoom-out-btn"',
                         'id="zoom-in-btn"', 'src="world3d.js"',
                         'LIVE 3D WORLD', 'CAMERA: FOLLOW']:
            assert unwanted not in interface, 'Removed second board reappeared: ' + unwanted
        assert 'user-scalable=no' in interface
        gameplay = archive.read('assets/game.js').decode('utf-8')
        for marker in ["setAttribute('src', 'rules.html')", 'function openGuide()',
                       'function openTutorial(returnToGuide)',
                       'function advanceTutorial(direction)',
                       'var TUTORIAL_STEPS = [']:
            assert marker in gameplay, 'Missing offline tutorial behavior: ' + marker
        for marker in ['function drawLivingWater(board)',
                       'function drawJungleAtmosphere(board)',
                       'function syncAmbientSound()',
                       'function updateJungleParallax(event)',
                       'function setAmbientSoundEnabled(enabled)',
                       'function setLivingJungleEnabled(enabled)',
                       "new window.Audio('sounds/jungle_ambience.mp3')",
                       "document.addEventListener('visibilitychange', syncAmbientSound)"]:
            assert marker in gameplay, 'Missing living-jungle behavior: ' + marker
        for marker in ['function avatarArtwork(player, pose)',
                       'function collectTool(player, kind, position)',
                       'function animateHammerBreak(player, position)',
                       'function setAnimalFrame(position, frame)',
                       'function rankLabel(rank)', 'function renderRankings()',
                       'function drawEncounterOutcome(stage, player, animal, loser)',
                       'function animateEncounterDefeat(player, position, loser)',
                       'state.rankings.push(state.players.indexOf(player))',
                       'while (state.players[state.current].finished)',
                       "await showVisual('animal_falls', position,",
                       "await showVisual('explorer_falls', position,",
                       "33: { label: 'HAMMER'", "frame === 'broken'",
                       "playSound('hammer_hit')",
                       "await showVisual('lock_break', position,"]:
            assert marker in gameplay, 'Missing living-explorer adventure: ' + marker
        styles = archive.read('assets/style.css').decode('utf-8')
        for marker in ['@keyframes jungle-river-current',
                       '@keyframes jungle-waterfall-fall',
                       '@keyframes jungle-firefly-float',
                       '@keyframes jungle-animal-breathe',
                       '@keyframes hammer-final-strike',
                       '@keyframes lock-fragment-burst',
                       '@keyframes defeated-animal-topple',
                       '@keyframes defeated-explorer-topple',
                       '@keyframes board-animal-topple',
                       '@keyframes board-explorer-topple',
                       '@media (prefers-reduced-motion: reduce)']:
            assert marker in styles, 'Missing accessible live-jungle effect: ' + marker
        assert 'KeysClawsWorld3D' not in gameplay
        for unwanted in ['.world-canvas', '.world-art', '.world-labels',
                         '.world-toolbar', '.brand-3d', 'board-fullscreen']:
            assert unwanted not in styles, 'Removed board CSS reappeared: ' + unwanted
        assert 'var Y = [548, 421, 311, 208, 106]' in gameplay
        assert '[154, 252, 349, 447, 545, 643, 740]' in gameplay
        assert '[740, 623, 506, 388, 271, 154]' in gameplay
        assert "river: { from: 25, to: 29" in gameplay
        assert "await travelRoute(player, 'river')" in gameplay
        assert "'data-space': number" in gameplay
        assert 'String(number)' not in gameplay.split('function drawBoard()', 1)[1].split(
            'function tokenPoint(', 1)[0]
        manifest = json.loads(archive.read('assets/art/manifest.json').decode('utf-8'))
        assert manifest['shortcut_bridges'] == [[3, 11], [12, 18], [25, 29]]
        assert manifest['board_numbers_visible'] is False
        assert manifest['background_reference_upload'] == '1000254601.png'
        assert manifest['offline_jungle_ambience'] == 'sounds/jungle_ambience.mp3'
        assert '2.5D' in manifest['image_native_depth_illusion']
        assert 'animated waterfalls' in manifest['living_jungle_effects']
        assert [explorer['id'] for explorer in manifest['explorer_avatars']] == [
            'ruby', 'river', 'forest', 'violet',
        ]
        assert manifest['explorer_avatar_frame_size'] == 256
        assert manifest['hammer']['space'] == 33
        assert manifest['hammer']['requires_exact_landing'] is True
        assert manifest['hammer']['works_only_at_final_gate'] == 35
        assert manifest['hammer']['opens_first_gate'] is False
        assert manifest['hammer']['protects_against_animals'] is False
        assert manifest['ranked_multiplayer'] == {
            'continues_after_first_finisher': True,
            'skips_finished_explorers': True,
            'automatic_last_place': True,
            'maximum_explorers': 4,
        }
        assert manifest['encounter_outcomes'] == {
            'human_victory': 'animal_falls',
            'animal_victory': 'explorer_falls',
            'reuses_approved_transparent_artwork': True,
        }
        for effect in ['knife_pickup', 'axe_pickup', 'hammer_pickup',
                       'knife_use', 'axe_use', 'hammer_hit', 'lock_break']:
            assert manifest['sound_events'][effect] == f'sounds/{effect}.mp3'
            assert len(archive.read(f'assets/sounds/{effect}.mp3')) > 1000
        assert len(archive.read('assets/sounds/jungle_ambience.mp3')) > 100000
        assert hashlib.sha256(archive.read('assets/art/jungle_natural.jpg')).hexdigest() == (
            manifest['background_sha256'])
        assert "preserveAspectRatio: 'none', opacity: '1'" in gameplay
        assert "stroke: route.bridge ? '#e3bc75' : 'none'" in gameplay
        assert "position === 17" in gameplay
        assert "setGateFrame(position, 'half_closing')" in gameplay
        assert "playSound('gate_open')" in gameplay
        assert "playSound('gate_close')" in gameplay
        assert "href: 'art/jungle_natural.jpg'" in gameplay
        key_scene = gameplay.split('function drawKeyScene(stage)', 1)[1].split(
            'function drawUnlockScene(stage)', 1)[0]
        unlock_scene = gameplay.split('function drawUnlockScene(stage)', 1)[1].split(
            'function drawAnimalScene(stage, kind)', 1)[0]
        assert key_scene.count("svg('image'") == 1
        assert unlock_scene.count("svg('image'") == 1
        result = {
            'file': str(OUTPUT),
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'zip_entries': len(names),
            'manifest': parse_manifest(archive.read('AndroidManifest.xml')),
            'resources': parse_resource_table(archive.read('resources.arsc'), archive),
            'dex': parse_dex(archive.read('classes.dex')),
            'v1_signature': verify_v1(archive),
            'v2_signature': verify_v2(data),
            'rules_and_tutorial': {
                'separate_offline_rules_page': 'assets/rules.html',
                'rules_load_inside_popup': True,
                'guided_illustrated_tutorial': True,
                'tutorial_steps': 7,
                'setup_toolbar_settings_and_sidebar_navigation': True,
                'approved_bridges_animals_keys_gates_and_multiplayer_documented': True,
                'exact_hammer_collection_and_final_lock_rules_documented': True,
                'ranked_multiplayer_and_automatic_last_place_documented': True,
            },
            'board_presentation': {
                'technology': 'single SVG board on the owner-approved natural jungle image',
                'offline': True,
                'one_background_only': True,
                'objects_directly_anchored_to_jungle_paths': True,
                'tilted_webgl_board_removed': True,
                'camera_zoom_and_floating_labels_removed': True,
                'historical_renderer_source_archived_but_never_loaded': True,
                'approved_animal_key_and_gate_artwork_once': True,
                'detailed_natural_jungle_background_without_baked_objects': True,
                'exact_owner_uploaded_background_preserved': True,
                'all_printed_board_numbers_hidden': True,
                'spaces_21_and_22_on_existing_dry_path': True,
                'image_aligned_lane_centers': [548, 421, 311, 208, 106],
                'approved_lane_lengths': [7, 7, 7, 6, 8],
                'key_and_unlock_scenes_use_one_approved_image': True,
                'elevated_bridges': [[3, 11], [12, 18], [25, 29]],
                'river_crossings': {'ordinary_trail_turn': [27, 28],
                                    'approved_elevated_bridge': [25, 29]},
                'original_gate_opening_and_closing_sounds': True,
                'halfway_closing_gate_animation': True,
                'image_native_2_5d_depth_illusion': True,
                'animated_river_currents': 4,
                'animated_waterfalls': 3,
                'waterfall_foam_and_drifting_mist': True,
                'animated_fireflies_and_foreground_foliage': True,
                'breathing_animals_glowing_keys_and_ground_shadows': True,
                'subtle_pointer_parallax': True,
                'reduced_motion_preference_supported': True,
                'offline_looping_river_waterfall_bird_ambience': True,
                'independent_living_jungle_and_ambience_controls': True,
                'ambience_pauses_when_app_is_hidden_or_muted': True,
                'full_body_3d_style_explorer_avatars': 4,
                'normalized_transparent_explorer_animation_frames': 32,
                'walking_limbs_crying_recovery_and_weapon_poses': True,
                'lion_and_wolf_walk_roar_and_sleep_states': True,
                'hammer_exact_landing_space': 33,
                'hammer_opens_final_gate_only': 35,
                'animated_broken_final_gate_and_two_hammer_strikes': True,
                'distinct_offline_tool_pickup_and_use_sounds': 7,
                'race_continues_after_first_winner': True,
                'ranked_multiplayer_maximum_explorers': 4,
                'finished_explorer_turns_skipped': True,
                'automatic_last_place_and_final_rankings': True,
                'animal_loses_and_visibly_falls': True,
                'explorer_loses_and_visibly_falls': True,
            },
        }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
