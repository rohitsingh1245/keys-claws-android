(function () {
  'use strict';

  // A dependency-free WebGL 1 renderer. Every mesh is generated locally, so
  // the Android APK remains offline and does not require a game-engine runtime.
  var TAU = Math.PI * 2;
  var palette = {
    grass: '#638f54', grassLight: '#84a96a', earth: '#76533d', stone: '#a59b84',
    sand: '#e8c991', paper: '#f7e7c1', cream: '#fff4d7', gold: '#efbd54',
    darkGold: '#a87528', green: '#427c56', red: '#ba574b', blue: '#52909d',
    purple: '#8e698f', wood: '#72513d', leaf: '#507b4b', leafLight: '#77a164',
    skin: '#eec09b', hair: '#584035', lion: '#dda55f', mane: '#925332',
    wolf: '#778494', wolfDark: '#566170', white: '#fff9eb', ink: '#382d26',
    river: '#329fbb', riverLight: '#87e5dc', riverDeep: '#247995', trail: '#cba674'
  };

  var app = {
    canvas: null, labels: null, art: null, toolbar: null, badge: null, cameraButton: null,
    fullscreenButton: null, zoomOutButton: null, zoomInButton: null,
    gl: null, game: null, program: null, meshes: {}, markers: [], routeMarkers: [],
    ready: false, fallback: false, frames: 0, cameraMode: 'follow', yaw: .27,
    distance: 11.6, fullScreen: false, pitch: .7, focus: null, event: null, lastTime: 0,
    pixelWidth: 0, pixelHeight: 0, cssWidth: 0, cssHeight: 0,
    cameraTarget: { x: .1, y: .08, z: 0 }, pointer: null, pointers: {},
    pinch: null, raf: 0, spriteMarkers: [], gateStates: { 6: 'closed', 35: 'closed' },
    defeatedUntil: {},
    stats: { staticVertices: 0, dynamicMeshes: 0, events: [], frameDrawCalls: 0,
      riverBarrier: null, bridgeRoutes: [] }
  };

  function rgb(value) {
    var hex = String(value || '#ffffff').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(function (item) { return item + item; }).join('');
    return [parseInt(hex.slice(0, 2), 16) / 255,
      parseInt(hex.slice(2, 4), 16) / 255,
      parseInt(hex.slice(4, 6), 16) / 255];
  }

  function shade(color, factor) {
    var value = Array.isArray(color) ? color : rgb(color);
    return value.map(function (part) { return Math.max(0, Math.min(1, part * factor)); });
  }

  function meshBuilder() { return { values: [], count: 0 }; }

  function vertex(mesh, point, normal, color) {
    mesh.values.push(point[0], point[1], point[2], normal[0], normal[1], normal[2],
      color[0], color[1], color[2]);
    mesh.count++;
  }

  function triangle(mesh, a, b, c, normal, color) {
    vertex(mesh, a, normal, color);
    vertex(mesh, b, normal, color);
    vertex(mesh, c, normal, color);
  }

  function quad(mesh, a, b, c, d, normal, color) {
    triangle(mesh, a, b, c, normal, color);
    triangle(mesh, a, c, d, normal, color);
  }

  function box(mesh, x, y, z, width, height, depth, color) {
    var c = Array.isArray(color) ? color : rgb(color);
    var x0 = x - width / 2, x1 = x + width / 2;
    var y0 = y - height / 2, y1 = y + height / 2;
    var z0 = z - depth / 2, z1 = z + depth / 2;
    quad(mesh, [x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [0, 1, 0], shade(c, 1.08));
    quad(mesh, [x0, y0, z1], [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [0, -1, 0], shade(c, .76));
    quad(mesh, [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1], shade(c, .95));
    quad(mesh, [x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [0, 0, -1], shade(c, .83));
    quad(mesh, [x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0], shade(c, 1));
    quad(mesh, [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0], shade(c, .87));
    return mesh;
  }

  function cylinder(mesh, x, y, z, radius, height, color, sides) {
    var c = Array.isArray(color) ? color : rgb(color);
    var count = sides || 9;
    var low = y - height / 2, high = y + height / 2;
    for (var i = 0; i < count; i++) {
      var a = TAU * i / count;
      var b = TAU * (i + 1) / count;
      var ax = Math.cos(a) * radius, az = Math.sin(a) * radius;
      var bx = Math.cos(b) * radius, bz = Math.sin(b) * radius;
      var mid = (a + b) / 2;
      quad(mesh, [x + ax, low, z + az], [x + bx, low, z + bz],
        [x + bx, high, z + bz], [x + ax, high, z + az],
        [Math.cos(mid), 0, Math.sin(mid)], c);
      triangle(mesh, [x, high, z], [x + bx, high, z + bz], [x + ax, high, z + az],
        [0, 1, 0], shade(c, 1.08));
      triangle(mesh, [x, low, z], [x + ax, low, z + az], [x + bx, low, z + bz],
        [0, -1, 0], shade(c, .75));
    }
    return mesh;
  }

  function cone(mesh, x, y, z, radius, height, color, sides) {
    var c = Array.isArray(color) ? color : rgb(color);
    var count = sides || 7;
    var low = y - height / 2, high = y + height / 2;
    for (var i = 0; i < count; i++) {
      var a = TAU * i / count, b = TAU * (i + 1) / count;
      var mid = (a + b) / 2;
      var normal = normalize([Math.cos(mid), radius / height, Math.sin(mid)]);
      triangle(mesh, [x + Math.cos(a) * radius, low, z + Math.sin(a) * radius],
        [x + Math.cos(b) * radius, low, z + Math.sin(b) * radius],
        [x, high, z], normal, c);
      triangle(mesh, [x, low, z],
        [x + Math.cos(b) * radius, low, z + Math.sin(b) * radius],
        [x + Math.cos(a) * radius, low, z + Math.sin(a) * radius],
        [0, -1, 0], shade(c, .76));
    }
    return mesh;
  }

  function sphere(mesh, x, y, z, radius, color, rings, sides) {
    var c = Array.isArray(color) ? color : rgb(color);
    var lat = rings || 5, lon = sides || 8;
    for (var row = 0; row < lat; row++) {
      var phi0 = -Math.PI / 2 + Math.PI * row / lat;
      var phi1 = -Math.PI / 2 + Math.PI * (row + 1) / lat;
      for (var col = 0; col < lon; col++) {
        var theta0 = TAU * col / lon;
        var theta1 = TAU * (col + 1) / lon;
        var points = [
          spherePoint(phi0, theta0), spherePoint(phi0, theta1),
          spherePoint(phi1, theta1), spherePoint(phi1, theta0)
        ];
        var normal = spherePoint((phi0 + phi1) / 2, (theta0 + theta1) / 2);
        var absolute = points.map(function (p) {
          return [x + p[0] * radius, y + p[1] * radius, z + p[2] * radius];
        });
        quad(mesh, absolute[0], absolute[1], absolute[2], absolute[3], normal, c);
      }
    }
    return mesh;
  }

  function spherePoint(phi, theta) {
    return [Math.cos(phi) * Math.cos(theta), Math.sin(phi),
      Math.cos(phi) * Math.sin(theta)];
  }

  function torus(mesh, x, y, z, major, minor, color, segments, sides, start, end) {
    var c = Array.isArray(color) ? color : rgb(color);
    var parts = segments || 10, radial = sides || 5;
    var first = start === undefined ? 0 : start;
    var last = end === undefined ? TAU : end;
    function point(angle, around) {
      var radius = major + Math.cos(around) * minor;
      return [x + Math.cos(angle) * radius, y + Math.sin(angle) * radius,
        z + Math.sin(around) * minor];
    }
    for (var i = 0; i < parts; i++) {
      var a = first + (last - first) * i / parts;
      var b = first + (last - first) * (i + 1) / parts;
      for (var j = 0; j < radial; j++) {
        var p = TAU * j / radial;
        var q = TAU * (j + 1) / radial;
        var mid = (a + b) / 2, round = (p + q) / 2;
        var normal = [Math.cos(mid) * Math.cos(round),
          Math.sin(mid) * Math.cos(round), Math.sin(round)];
        quad(mesh, point(a, p), point(b, p), point(b, q), point(a, q), normal, c);
      }
    }
    return mesh;
  }

  function normalize(vector) {
    var length = Math.sqrt(vector[0] * vector[0] + vector[1] * vector[1] +
      vector[2] * vector[2]) || 1;
    return [vector[0] / length, vector[1] / length, vector[2] / length];
  }

  function identity() {
    return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0,
      0, 0, 1, 0, 0, 0, 0, 1]);
  }

  function multiply(a, b) {
    var out = new Float32Array(16);
    for (var column = 0; column < 4; column++) {
      for (var row = 0; row < 4; row++) {
        out[column * 4 + row] = a[row] * b[column * 4] +
          a[4 + row] * b[column * 4 + 1] +
          a[8 + row] * b[column * 4 + 2] +
          a[12 + row] * b[column * 4 + 3];
      }
    }
    return out;
  }

  function perspective(field, aspect, near, far) {
    var out = new Float32Array(16);
    var scale = 1 / Math.tan(field / 2);
    out[0] = scale / aspect;
    out[5] = scale;
    out[10] = (far + near) / (near - far);
    out[11] = -1;
    out[14] = 2 * far * near / (near - far);
    return out;
  }

  function cross(a, b) {
    return [a[1] * b[2] - a[2] * b[1],
      a[2] * b[0] - a[0] * b[2],
      a[0] * b[1] - a[1] * b[0]];
  }

  function lookAt(eye, target, up) {
    var z = normalize([eye[0] - target[0], eye[1] - target[1], eye[2] - target[2]]);
    var x = normalize(cross(up, z));
    var y = cross(z, x);
    var out = identity();
    out[0] = x[0]; out[1] = y[0]; out[2] = z[0];
    out[4] = x[1]; out[5] = y[1]; out[6] = z[1];
    out[8] = x[2]; out[9] = y[2]; out[10] = z[2];
    out[12] = -(x[0] * eye[0] + x[1] * eye[1] + x[2] * eye[2]);
    out[13] = -(y[0] * eye[0] + y[1] * eye[1] + y[2] * eye[2]);
    out[14] = -(z[0] * eye[0] + z[1] * eye[1] + z[2] * eye[2]);
    return out;
  }

  function model(x, y, z, yaw, scaleX, scaleY, scaleZ) {
    var out = identity();
    var angle = yaw || 0;
    var cosine = Math.cos(angle), sine = Math.sin(angle);
    var sx = scaleX === undefined ? 1 : scaleX;
    var sy = scaleY === undefined ? sx : scaleY;
    var sz = scaleZ === undefined ? sx : scaleZ;
    out[0] = cosine * sx; out[2] = -sine * sx;
    out[5] = sy;
    out[8] = sine * sz; out[10] = cosine * sz;
    out[12] = x || 0; out[13] = y || 0; out[14] = z || 0;
    return out;
  }

  function boardPoint(x, y) {
    return { x: (x - 518) / 108, z: (y - 324) / 105 };
  }

  function spacePoint(space) {
    if (!space || !app.game || !app.game.positions[space]) return boardPoint(72, 542);
    var point = app.game.positions[space];
    return boardPoint(point.x, point.y);
  }

  function project(matrix, x, y, z, width, height) {
    var clipX = matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12];
    var clipY = matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13];
    var clipW = matrix[3] * x + matrix[7] * y + matrix[11] * z + matrix[15];
    if (clipW <= 0.001) return null;
    return { x: (clipX / clipW * .5 + .5) * width,
      y: (1 - (clipY / clipW * .5 + .5)) * height, depth: clipW };
  }

  function shader(gl, type, source) {
    var result = gl.createShader(type);
    gl.shaderSource(result, source);
    gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) {
      throw new Error(gl.getShaderInfoLog(result) || '3D shader compilation failed');
    }
    return result;
  }

  function createProgram(gl) {
    var vertexSource = [
      'attribute vec3 aPosition;',
      'attribute vec3 aNormal;',
      'attribute vec3 aColor;',
      'uniform mat4 uViewProjection;',
      'uniform mat4 uModel;',
      'uniform float uGlow;',
      'varying vec3 vColor;',
      'varying vec3 vNormal;',
      'varying float vGlow;',
      'void main() {',
      '  vec4 world = uModel * vec4(aPosition, 1.0);',
      '  gl_Position = uViewProjection * world;',
      '  vNormal = normalize(mat3(uModel) * aNormal);',
      '  vColor = aColor;',
      '  vGlow = uGlow;',
      '}'
    ].join('\n');
    var fragmentSource = [
      'precision mediump float;',
      'varying vec3 vColor;',
      'varying vec3 vNormal;',
      'varying float vGlow;',
      'uniform float uOpacity;',
      'void main() {',
      '  vec3 light = normalize(vec3(-0.46, 0.84, 0.36));',
      '  float sun = max(dot(normalize(vNormal), light), 0.0);',
      '  float fill = max(dot(normalize(vNormal), vec3(0.0, 1.0, 0.0)), 0.0);',
      '  vec3 lit = vColor * (0.43 + sun * 0.47 + fill * 0.17);',
      '  lit = mix(lit, vec3(1.0, 0.86, 0.36), clamp(vGlow, 0.0, 0.65));',
      '  gl_FragColor = vec4(lit, uOpacity);',
      '}'
    ].join('\n');
    var result = gl.createProgram();
    gl.attachShader(result, shader(gl, gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(result, shader(gl, gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(result);
    if (!gl.getProgramParameter(result, gl.LINK_STATUS)) {
      throw new Error(gl.getProgramInfoLog(result) || '3D program linking failed');
    }
    gl.useProgram(result);
    return {
      handle: result,
      position: gl.getAttribLocation(result, 'aPosition'),
      normal: gl.getAttribLocation(result, 'aNormal'),
      color: gl.getAttribLocation(result, 'aColor'),
      viewProjection: gl.getUniformLocation(result, 'uViewProjection'),
      model: gl.getUniformLocation(result, 'uModel'),
      glow: gl.getUniformLocation(result, 'uGlow'),
      opacity: gl.getUniformLocation(result, 'uOpacity')
    };
  }

  function upload(name, mesh) {
    var gl = app.gl;
    var buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(mesh.values), gl.STATIC_DRAW);
    app.meshes[name] = { buffer: buffer, count: mesh.count };
    if (name === 'landscape') app.stats.staticVertices = mesh.count;
    else app.stats.dynamicMeshes++;
    return app.meshes[name];
  }

  function draw(name, transform, glow) {
    var item = app.meshes[name];
    if (!item) return;
    var gl = app.gl, p = app.program;
    gl.bindBuffer(gl.ARRAY_BUFFER, item.buffer);
    gl.vertexAttribPointer(p.position, 3, gl.FLOAT, false, 36, 0);
    gl.vertexAttribPointer(p.normal, 3, gl.FLOAT, false, 36, 12);
    gl.vertexAttribPointer(p.color, 3, gl.FLOAT, false, 36, 24);
    gl.enableVertexAttribArray(p.position);
    gl.enableVertexAttribArray(p.normal);
    gl.enableVertexAttribArray(p.color);
    gl.uniformMatrix4fv(p.model, false, transform || identity());
    gl.uniform1f(p.glow, glow || 0);
    // Let the owner's detailed natural jungle remain visible behind the
    // genuine 3D route; explorers, weapons, and particles remain fully opaque.
    gl.uniform1f(p.opacity, name === 'landscape' ? .47 : 1);
    gl.drawArrays(gl.TRIANGLES, 0, item.count);
    app.stats.frameDrawCalls++;
  }

  function ribbon(mesh, points, color, dashed) {
    var c = rgb(color);
    for (var index = 0; index < points.length - 1; index++) {
      var start = boardPoint(points[index][0], points[index][1]);
      var end = boardPoint(points[index + 1][0], points[index + 1][1]);
      var dx = end.x - start.x, dz = end.z - start.z;
      var length = Math.sqrt(dx * dx + dz * dz) || 1;
      var nx = -dz / length * .039, nz = dx / length * .039;
      var segments = dashed ? Math.max(2, Math.ceil(length / .2)) : 1;
      for (var step = 0; step < segments; step++) {
        if (dashed && step % 2) continue;
        var f = step / segments;
        var t = (step + 1) / segments;
        var ax = start.x + dx * f, az = start.z + dz * f;
        var bx = start.x + dx * t, bz = start.z + dz * t;
        quad(mesh, [ax - nx, .251, az - nz], [ax + nx, .251, az + nz],
          [bx + nx, .251, bz + nz], [bx - nx, .251, bz - nz], [0, 1, 0], c);
      }
      if (index === points.length - 2) {
        var tailX = end.x - dx / length * .2;
        var tailZ = end.z - dz / length * .2;
        triangle(mesh, [end.x, .256, end.z],
          [tailX + nx * 2.6, .256, tailZ + nz * 2.6],
          [tailX - nx * 2.6, .256, tailZ - nz * 2.6], [0, 1, 0], c);
      }
    }
  }

  function tree(mesh, x, z, height, variant) {
    cylinder(mesh, x, .22 + height * .18, z, .055, height * .37, palette.wood, 7);
    cone(mesh, x, .22 + height * .47, z, height * .25, height * .49,
      variant ? palette.leafLight : palette.leaf, 7);
    cone(mesh, x, .22 + height * .73, z, height * .19, height * .39,
      variant ? palette.leaf : palette.leafLight, 7);
  }

  function shrub(mesh, x, z, radius) {
    sphere(mesh, x, .23 + radius * .48, z, radius, palette.leafLight, 4, 7);
    sphere(mesh, x + radius * .55, .22 + radius * .34, z + radius * .23,
      radius * .65, palette.leaf, 4, 7);
  }

  function trail(mesh, points, width, color, height) {
    var shadeColor = rgb(color);
    var level = height === undefined ? .205 : height;
    for (var index = 0; index < points.length - 1; index++) {
      var start = boardPoint(points[index][0], points[index][1]);
      var end = boardPoint(points[index + 1][0], points[index + 1][1]);
      var dx = end.x - start.x, dz = end.z - start.z;
      var length = Math.sqrt(dx * dx + dz * dz) || 1;
      var nx = -dz / length * width / 2, nz = dx / length * width / 2;
      quad(mesh, [start.x - nx, level, start.z - nz],
        [start.x + nx, level, start.z + nz],
        [end.x + nx, level, end.z + nz],
        [end.x - nx, level, end.z - nz], [0, 1, 0], shadeColor);
      if (index < points.length - 2) {
        cylinder(mesh, end.x, level - .008, end.z, width / 2, .018, color, 10);
      }
    }
  }

  function elevatedBridge(mesh, from, to) {
    var source = spacePoint(from);
    var target = spacePoint(to);
    var dx = target.x - source.x, dz = target.z - source.z;
    var length = Math.sqrt(dx * dx + dz * dz) || 1;
    var nx = -dz / length, nz = dx / length;
    for (var index = 0; index < 11; index++) {
      var progress = index / 10;
      var centerX = source.x + dx * progress;
      var centerZ = source.z + dz * progress;
      var rise = .35 + Math.sin(progress * Math.PI) * .22;
      var halfStep = length / 24;
      var ax = centerX - dx / length * halfStep;
      var az = centerZ - dz / length * halfStep;
      var bx = centerX + dx / length * halfStep;
      var bz = centerZ + dz / length * halfStep;
      quad(mesh, [ax - nx * .21, rise, az - nz * .21],
        [ax + nx * .21, rise, az + nz * .21],
        [bx + nx * .21, rise, bz + nz * .21],
        [bx - nx * .21, rise, bz - nz * .21], [0, 1, 0],
      shade(index % 2 ? '#bd8b50' : '#dfb679', 1));
      if (index % 2 === 0) {
        [-1, 1].forEach(function (side) {
          cylinder(mesh, centerX + nx * side * .24, rise + .13,
            centerZ + nz * side * .24, .023, .27, palette.wood, 6);
          sphere(mesh, centerX + nx * side * .24, rise + .275,
            centerZ + nz * side * .24, .037, '#efcf88', 3, 5);
        });
      }
    }
    app.stats.bridgeRoutes.push([from, to]);
  }

  function buildLandscape() {
    var land = meshBuilder();
    box(land, -.1, -.25, -.02, 10.45, .52, 6.63, palette.earth);
    box(land, -.1, .045, -.02, 10.55, .16, 6.72, palette.grass);
    box(land, -.1, .135, -.02, 9.26, .12, 5.56, palette.grassLight);

    // Keep one natural connected route. The 7/7/7/6/8 lane lengths prevent
    // invented neighboring shortcuts and preserve all four approved turns.
    var trailPoints = [];
    for (var space = 1; space <= 35; space++) {
      var current = app.game.positions[space];
      if (space > 1) {
        var previous = app.game.positions[space - 1];
        if (current.row !== undefined && previous.row !== current.row) {
          var edge = previous.x + (previous.x > 500 ? 70 : -70);
          trailPoints.push([edge, previous.y + (current.y - previous.y) * .25]);
          trailPoints.push([edge, previous.y + (current.y - previous.y) * .75]);
        }
      }
      trailPoints.push([current.x, current.y]);
    }
    trail(land, trailPoints, .75, '#8d6848', .201);
    trail(land, trailPoints, .62, palette.trail, .208);

    // Water begins to the right of the left-hand 27 → 28 bend. All other
    // adjacency between the hospital/wolf lane and the HOME lane is blocked.
    var river = [[205, 154], [307, 141], [398, 163], [492, 151],
      [597, 145], [688, 159], [786, 147], [883, 164], [946, 149]];
    trail(land, river, .41, '#476d54', .211);
    trail(land, river, .34, palette.river, .219);
    trail(land, river, .055, palette.riverLight, .224);
    app.stats.riverBarrier = { betweenRows: [3, 4], startsAtX: 205,
      legalCrossing: [27, 28] };

    for (var number = 1; number <= 35; number++) {
      var p = spacePoint(number);
      var special = app.game.specials[number];
      var fill = special ? special.fill : number % 2 ? palette.cream : palette.sand;
      var tileWidth = number >= 28 ? .84 : .88;
      cylinder(land, p.x, .205, p.z, tileWidth / 2, .17, '#876e52', 10);
      cylinder(land, p.x, .302, p.z, tileWidth / 2 - .045, .037,
        special ? shade(fill, 1.04) : fill, 10);
      if (special) {
        box(land, p.x, .335, p.z - .325, .58, .037, .045, special.color);
      }
    }

    var routes = {
      bypass: { p: [[394, 517], [451, 478], [514, 438]], c: palette.green },
      lock: { p: [[754, 585], [671, 620], [210, 620], [154, 584]], c: palette.red, d: true },
      shortcut: { p: [[394, 404], [451, 365], [514, 326]], c: palette.green },
      lion: { p: [[409, 357], [517, 389], [581, 395], [634, 421]], c: palette.red, d: true },
      wolf: { p: [[163, 245], [254, 269], [531, 269], [586, 239]], c: palette.red, d: true },
      final: { p: [[859, 56], [768, 28], [414, 28], [360, 56]], c: palette.red, d: true }
    };
    Object.keys(routes).forEach(function (id) {
      ribbon(land, routes[id].p, routes[id].c, routes[id].d);
    });
    elevatedBridge(land, 3, 11);
    elevatedBridge(land, 12, 18);

    var trees = [
      [-4.89, -2.96, .92], [-4.58, -3.03, .67], [-3.98, -2.94, .71],
      [-2.7, -3.08, .56], [-1.2, -3.1, .65], [.25, -3.04, .64],
      [1.66, -3.07, .77], [3.27, -3.1, .65], [4.64, -2.91, .83],
      [-4.98, -1.75, .71], [-4.87, -.38, .66], [-4.9, .92, .86],
      [4.74, -1.39, .7], [4.76, -.13, .63], [4.78, 1.18, .83],
      [-4.74, 2.92, .72], [-3.6, 3.03, .61], [3.77, 3.02, .68], [4.66, 2.85, .74]
    ];
    trees.forEach(function (item, index) { tree(land, item[0], item[1], item[2], index % 2); });
    [[-4.58, -2.4, .16], [-4.74, 1.75, .18], [4.63, .45, .19],
      [4.37, 2.29, .17], [2.15, 2.88, .14]].forEach(function (item) {
      shrub(land, item[0], item[1], item[2]);
    });

    var start = boardPoint(71, 548);
    box(land, start.x, .2, start.z, .67, .2, .7, '#d8e5b2');
    cylinder(land, start.x - .18, .78, start.z - .11, .024, 1, palette.wood, 6);
    box(land, start.x + .02, 1.12, start.z - .11, .43, .26, .04, palette.green);

    var home = boardPoint(1005, 108);
    box(land, home.x, .43, home.z, .79, .53, .78, palette.paper);
    box(land, home.x, .87, home.z, .93, .18, .91, palette.green);
    cone(land, home.x, 1.13, home.z, .69, .5, palette.green, 4);
    box(land, home.x, .36, home.z + .404, .21, .31, .045, palette.wood);
    box(land, home.x - .25, .53, home.z + .406, .15, .13, .05, '#9ed3d9');
    box(land, home.x + .25, .53, home.z + .406, .15, .13, .05, '#9ed3d9');
    upload('landscape', land);
  }

  function buildKey() {
    var mesh = meshBuilder();
    torus(mesh, 0, .67, 0, .135, .04, palette.gold, 10, 5);
    box(mesh, 0, .39, 0, .066, .34, .075, palette.gold);
    box(mesh, .095, .25, 0, .17, .052, .075, palette.gold);
    box(mesh, .13, .32, 0, .105, .052, .075, palette.gold);
    cylinder(mesh, 0, .08, 0, .19, .07, '#a18a56', 10);
    return mesh;
  }

  function buildLockBase() {
    var mesh = meshBuilder();
    box(mesh, 0, .37, 0, .43, .37, .27, '#695645');
    box(mesh, 0, .38, .15, .22, .22, .03, palette.darkGold);
    sphere(mesh, 0, .41, .176, .047, palette.gold, 4, 6);
    box(mesh, 0, .34, .176, .032, .09, .022, palette.gold);
    return mesh;
  }

  function buildShackle() {
    var mesh = meshBuilder();
    torus(mesh, 0, .61, 0, .15, .041, '#d1b783', 8, 5, 0, Math.PI);
    box(mesh, -.15, .56, 0, .072, .19, .073, '#d1b783');
    box(mesh, .15, .56, 0, .072, .19, .073, '#d1b783');
    return mesh;
  }

  function buildKnife() {
    var mesh = meshBuilder();
    box(mesh, 0, .52, 0, .12, .48, .08, '#c9d4dc');
    box(mesh, 0, .24, 0, .105, .18, .095, palette.wood);
    box(mesh, 0, .335, 0, .28, .05, .09, palette.gold);
    cone(mesh, 0, .82, 0, .084, .18, '#dce8eb', 4);
    cylinder(mesh, 0, .08, 0, .18, .055, palette.purple, 9);
    return mesh;
  }

  function buildAxe() {
    var mesh = meshBuilder();
    box(mesh, 0, .48, 0, .075, .71, .077, palette.wood);
    box(mesh, -.125, .7, 0, .29, .16, .1, '#cbd4d8');
    box(mesh, -.25, .69, 0, .08, .26, .12, '#dfe6e8');
    cylinder(mesh, 0, .08, 0, .18, .055, palette.purple, 9);
    return mesh;
  }

  function buildMedical(hospital) {
    var mesh = meshBuilder();
    if (hospital) {
      box(mesh, 0, .37, 0, .63, .49, .46, '#e8e2cf');
      cone(mesh, 0, .78, 0, .48, .3, '#537c72', 4);
      box(mesh, 0, .3, .25, .15, .25, .05, palette.wood);
      box(mesh, 0, .55, .25, .055, .22, .047, palette.red);
      box(mesh, 0, .55, .25, .2, .055, .047, palette.red);
    } else {
      box(mesh, 0, .39, 0, .19, .55, .13, palette.red);
      box(mesh, 0, .42, 0, .5, .19, .13, palette.red);
      cylinder(mesh, 0, .09, 0, .23, .07, palette.white, 10);
    }
    return mesh;
  }

  function buildShortcut() {
    var mesh = meshBuilder();
    torus(mesh, 0, .43, 0, .26, .053, '#65a16c', 11, 5, 0, Math.PI);
    box(mesh, -.26, .27, 0, .09, .32, .09, palette.green);
    box(mesh, .26, .27, 0, .09, .32, .09, palette.green);
    box(mesh, 0, .095, 0, .62, .06, .28, '#a8cc86');
    return mesh;
  }

  function buildAnimal(kind) {
    var lion = kind === 'lion';
    var bodyColor = lion ? palette.lion : palette.wolf;
    var dark = lion ? palette.mane : palette.wolfDark;
    var mesh = meshBuilder();
    if (lion) {
      // A warm, friendly seated lion: upright chest, large resting haunches,
      // straight front paws, rounded mane, soft ears, and a smiling mouth.
      sphere(mesh, 0, .46, -.08, .28, bodyColor, 6, 10);
      sphere(mesh, 0, .59, .06, .23, bodyColor, 6, 10);
      sphere(mesh, -.21, .235, -.10, .17, bodyColor, 5, 9);
      sphere(mesh, .21, .235, -.10, .17, bodyColor, 5, 9);
      [-.13, .13].forEach(function (x) {
        box(mesh, x, .285, .17, .09, .37, .11, bodyColor);
        sphere(mesh, x, .105, .205, .075, '#edbd79', 4, 7);
      });
      sphere(mesh, 0, .79, .17, .31, dark, 6, 11);
      sphere(mesh, -.17, .96, .17, .09, dark, 4, 7);
      sphere(mesh, .17, .96, .17, .09, dark, 4, 7);
      sphere(mesh, 0, .80, .285, .205, bodyColor, 6, 10);
      sphere(mesh, -.074, .835, .462, .025, palette.ink, 4, 6);
      sphere(mesh, .074, .835, .462, .025, palette.ink, 4, 6);
      sphere(mesh, 0, .745, .47, .087, '#f3d09a', 4, 8);
      sphere(mesh, 0, .77, .535, .037, palette.ink, 4, 6);
      torus(mesh, 0, .722, .525, .067, .012, '#6f3c2e', 8, 4,
        Math.PI, TAU);
      torus(mesh, .24, .46, -.24, .17, .035, dark, 10, 5, -.2, Math.PI);
      sphere(mesh, .07, .44, -.24, .065, dark, 4, 7);
      return mesh;
    }
    sphere(mesh, 0, .42, -.075, .235, bodyColor, 5, 9);
    box(mesh, 0, .405, -.13, .37, .27, .43, bodyColor);
    [-.13, .13].forEach(function (x) {
      [-.22, .07].forEach(function (z) {
        box(mesh, x, .17, z, .075, .3, .085, bodyColor);
      });
    });
    cone(mesh, -.15, .83, .14, .083, .19, dark, 4);
    cone(mesh, .15, .83, .14, .083, .19, dark, 4);
    sphere(mesh, 0, .63, .225, .19, bodyColor, 5, 8);
    sphere(mesh, -.064, .665, .365, .025, palette.ink, 4, 6);
    sphere(mesh, .064, .665, .365, .025, palette.ink, 4, 6);
    sphere(mesh, 0, .56, .39, .095, '#c8ccd0', 4, 7);
    sphere(mesh, 0, .57, .461, .036, palette.ink, 4, 6);
    box(mesh, .22, .41, -.34, .05, .08, .24, dark);
    return mesh;
  }

  function buildHuman(color) {
    var mesh = meshBuilder();
    var coat = rgb(color);
    sphere(mesh, 0, .64, 0, .135, palette.skin, 5, 8);
    sphere(mesh, 0, .72, -.034, .119, palette.hair, 4, 7);
    box(mesh, 0, .405, 0, .225, .29, .16, coat);
    box(mesh, -.162, .405, .005, .068, .22, .079, coat);
    box(mesh, .162, .405, .005, .068, .22, .079, coat);
    sphere(mesh, -.162, .284, .005, .045, palette.skin, 4, 6);
    sphere(mesh, .162, .284, .005, .045, palette.skin, 4, 6);
    box(mesh, -.07, .18, 0, .078, .18, .095, '#57647a');
    box(mesh, .07, .18, 0, .078, .18, .095, '#57647a');
    box(mesh, -.07, .085, .04, .098, .055, .145, palette.wood);
    box(mesh, .07, .085, .04, .098, .055, .145, palette.wood);
    sphere(mesh, -.045, .65, .124, .014, palette.ink, 4, 5);
    sphere(mesh, .045, .65, .124, .014, palette.ink, 4, 5);
    return mesh;
  }

  function buildMeshes() {
    buildLandscape();
    upload('key', buildKey());
    upload('lock', buildLockBase());
    upload('shackle', buildShackle());
    upload('knife', buildKnife());
    upload('axe', buildAxe());
    upload('medical', buildMedical(false));
    upload('hospital', buildMedical(true));
    upload('shortcut', buildShortcut());
    upload('lion', buildAnimal('lion'));
    upload('wolf', buildAnimal('wolf'));
    upload('particle', sphere(meshBuilder(), 0, 0, 0, .035, palette.gold, 3, 5));
    upload('water_glint', box(meshBuilder(), 0, 0, 0, .16, .014, .034, '#d1fff5'));
    upload('tear', sphere(meshBuilder(), 0, 0, 0, .045, '#74c4ee', 3, 5));
    app.game.state.players.forEach(function (player, index) {
      upload('player_' + index, buildHuman(player.color));
    });
  }

  function createLabels() {
    app.labels.innerHTML = '';
    app.markers = [];
    for (var number = 1; number <= 35; number++) {
      var label = document.createElement('span');
      var special = app.game.specials[number];
      label.className = special ? 'space-label space-label-special' : 'space-label';
      label.setAttribute('data-space', String(number));
      if (special) {
        label.innerHTML = '<strong>' + number + '</strong><small>' + special.label + '</small>';
      } else {
        label.textContent = String(number);
      }
      app.labels.appendChild(label);
      app.markers.push({ node: label, space: number, special: Boolean(special) });
    }
    var routeNames = [
      { text: '3 → 11', x: 452, y: 478, good: true },
      { text: '6 → 1', x: 459, y: 620, good: false },
      { text: '12 → 18', x: 355, y: 374, good: true },
      { text: '17 → 10', x: 654, y: 384, good: false },
      { text: '27 → 24', x: 374, y: 269, good: false },
      { text: '35 → 30', x: 610, y: 28, good: false },
      { text: 'START', x: 72, y: 568, good: true },
      { text: 'HOME', x: 1005, y: 131, good: true }
    ];
    app.routeMarkers = routeNames.map(function (entry) {
      var label = document.createElement('span');
      label.className = 'route-label ' + (entry.good ? 'route-label-good' : 'route-label-danger');
      label.textContent = entry.text;
      app.labels.appendChild(label);
      return { node: label, point: boardPoint(entry.x, entry.y), height: .38 };
    });
  }

  function createArtwork() {
    app.spriteMarkers = [];
    if (!app.art || typeof document.createElement !== 'function') return;
    app.art.innerHTML = '';
    var entries = [
      { kind: 'key', space: 2, source: 'key_normal', height: .85, ratio: 1.5 },
      { kind: 'gate', space: 6, source: 'gate_closed', height: 1.22, ratio: 1.5 },
      { kind: 'lion', space: 17, source: 'lion_idle', height: 1.46, ratio: .96 },
      { kind: 'wolf', space: 27, source: 'wolf_idle', height: 1.38, ratio: .96 },
      { kind: 'key', space: 31, source: 'key_normal', height: .85, ratio: 1.5 },
      { kind: 'gate', space: 35, source: 'gate_closed', height: 1.28, ratio: 1.5 }
    ];
    entries.forEach(function (entry) {
      var node = document.createElement('img');
      node.className = 'world-art-sprite world-art-' +
        (entry.kind === 'lion' || entry.kind === 'wolf' ? 'animal' : entry.kind);
      node.setAttribute('alt', '');
      node.setAttribute('aria-hidden', 'true');
      node.setAttribute('data-art-kind', entry.kind);
      node.setAttribute('data-space', String(entry.space));
      node.addEventListener('error', function () {
        entry.failed = true;
        node.style.display = 'none';
      });
      node.addEventListener('load', function () {
        entry.failed = false;
      });
      node.setAttribute('src', 'art/' + entry.source + '.png');
      app.art.appendChild(node);
      entry.node = node;
      app.spriteMarkers.push(entry);
    });
  }

  function artworkState(entry, now) {
    if (entry.kind === 'gate') {
      var frame = app.gateStates[entry.space] || 'closed';
      if (frame === 'unlocking') return 'gate_unlocking';
      if (frame === 'open' || frame === 'passing') return 'gate_open';
      if (frame === 'opening' || frame === 'half_closing') return 'gate_half_closing';
      return 'gate_closed';
    }
    if (entry.kind === 'key') {
      return isActive('key', entry.space, now) ? 'key_glow' : 'key_normal';
    }
    if ((app.defeatedUntil[entry.space] || 0) > now) return entry.kind + '_sleep';
    if (isActive(entry.kind, entry.space, now)) {
      return entry.kind + (entry.kind === 'lion' ? '_roar' : '_howl');
    }
    return entry.kind + (Math.floor(now / 1750 + entry.space) % 7 === 2 ? '_walk' : '_idle');
  }

  function updateArtwork(matrix, now) {
    app.spriteMarkers.forEach(function (entry) {
      if (entry.failed) { entry.node.style.display = 'none'; return; }
      var point = spacePoint(entry.space);
      var foot = project(matrix, point.x + .08, .33, point.z - .03,
        app.cssWidth, app.cssHeight);
      var head = project(matrix, point.x + .08, .33 + entry.height, point.z - .03,
        app.cssWidth, app.cssHeight);
      if (!foot || !head) { entry.node.style.display = 'none'; return; }
      var height = Math.max(entry.kind === 'key' ? 40 : 56,
        Math.min(entry.kind === 'gate' ? 122 : 145, Math.abs(head.y - foot.y) * 1.14));
      var source = artworkState(entry, now);
      if (entry.currentSource !== source) {
        entry.node.setAttribute('src', 'art/' + source + '.png');
        entry.node.setAttribute('data-art-state', source);
        entry.currentSource = source;
      }
      var active = isActive(entry.kind, entry.space, now) ||
        (entry.kind === 'gate' && app.gateStates[entry.space] !== 'closed');
      var defeated = source.indexOf('_sleep') >= 0;
      entry.node.className = 'world-art-sprite world-art-' +
        (entry.kind === 'lion' || entry.kind === 'wolf' ? 'animal' : entry.kind) +
        (active ? ' world-art-active' : '') + (defeated ? ' world-art-defeated' : '');
      entry.node.style.display = '';
      entry.node.style.left = foot.x.toFixed(1) + 'px';
      entry.node.style.top = foot.y.toFixed(1) + 'px';
      entry.node.style.height = height.toFixed(1) + 'px';
      entry.node.style.width = (height * entry.ratio).toFixed(1) + 'px';
    });
  }

  function updateLabels(matrix) {
    app.markers.forEach(function (entry) {
      var point = spacePoint(entry.space);
      var screen = project(matrix, point.x - (entry.special ? .29 : 0),
        .345, point.z + (entry.special ? .27 : .05), app.cssWidth, app.cssHeight);
      if (!screen) { entry.node.style.display = 'none'; return; }
      entry.node.style.display = '';
      entry.node.style.left = screen.x.toFixed(1) + 'px';
      entry.node.style.top = screen.y.toFixed(1) + 'px';
    });
    app.routeMarkers.forEach(function (entry) {
      var screen = project(matrix, entry.point.x, entry.height,
        entry.point.z, app.cssWidth, app.cssHeight);
      if (!screen) { entry.node.style.display = 'none'; return; }
      entry.node.style.display = '';
      entry.node.style.left = screen.x.toFixed(1) + 'px';
      entry.node.style.top = screen.y.toFixed(1) + 'px';
    });
  }

  function currentPlayerPoint(player, index) {
    if (player.animatedPoint) {
      return boardPoint(player.animatedPoint.x, player.animatedPoint.y);
    }
    if (!player.position) return boardPoint(79 + index * 18, 539 + index * 5);
    var base = spacePoint(player.position);
    var offsets = [[.21, -.17], [.21, .17], [-.18, .17], [-.18, -.17]];
    return { x: base.x + offsets[index][0], z: base.z + offsets[index][1] };
  }

  function ensurePlayers() {
    app.game.state.players.forEach(function (player, index) {
      if (!app.meshes['player_' + index]) upload('player_' + index, buildHuman(player.color));
    });
  }

  function resize() {
    var width = Math.max(1, app.canvas.clientWidth ||
      app.canvas.offsetWidth || app.canvas.width || 900);
    var height = Math.max(1, app.canvas.clientHeight ||
      app.canvas.offsetHeight || app.canvas.height || 580);
    var ratio = Math.min(window.devicePixelRatio || 1, 1.6);
    var pixelWidth = Math.round(width * ratio);
    var pixelHeight = Math.round(height * ratio);
    app.cssWidth = width;
    app.cssHeight = height;
    if (pixelWidth !== app.pixelWidth || pixelHeight !== app.pixelHeight) {
      app.pixelWidth = pixelWidth;
      app.pixelHeight = pixelHeight;
      app.canvas.width = pixelWidth;
      app.canvas.height = pixelHeight;
      app.gl.viewport(0, 0, pixelWidth, pixelHeight);
    }
  }

  function isActive(kind, space, now) {
    return app.event && app.event.kind === kind && app.event.space === space &&
      app.event.until > now;
  }

  function hasApprovedSprite(kind, space) {
    if (!app.art) return false;
    return app.spriteMarkers.some(function (entry) {
      return entry.kind === kind && entry.space === space && !entry.failed;
    });
  }

  function drawIcons(now) {
    Object.keys(app.game.specials).forEach(function (value) {
      var number = Number(value);
      var special = app.game.specials[number];
      var point = spacePoint(number);
      var baseX = point.x + .13;
      var baseZ = point.z - .045;
      var icon = special.icon;
      if (icon === 'key') {
        var keyActive = isActive('key', number, now);
        if (!hasApprovedSprite('key', number)) {
          draw('key', model(baseX, .32 + Math.sin(now / 470 + number) * .035,
            baseZ, now / (keyActive ? 270 : 970), keyActive ? 1.23 : .84),
          keyActive ? .46 : .09);
        }
        if (keyActive) drawSparkles(baseX, .85, baseZ, now, .29);
      } else if (icon === 'lock') {
        var unlocking = isActive('unlock', number, now) ||
          (number === 35 && app.game.state.won);
        if (!hasApprovedSprite('gate', number)) {
          draw('lock', model(baseX, .32, baseZ, 0, .88), unlocking ? .27 : 0);
          draw('shackle', model(baseX, .32 + (unlocking ? .17 : 0), baseZ,
            unlocking ? -.23 : 0, .88), unlocking ? .34 : 0);
          if (unlocking) draw('key', model(baseX + .23, .42, baseZ + .16,
            now / 260, .38), .44);
        }
        if (unlocking) drawSparkles(baseX, .92, baseZ, now, .26);
      } else if (icon === 'lion' || icon === 'wolf') {
        var angry = isActive(icon, number, now);
        var lion = icon === 'lion';
        var bounce = Math.sin(now / (angry ? 95 : 620) + number) *
          (angry ? .075 : .018);
        var idleScale = lion ? 1.31 + Math.sin(now / 720) * .025 : 1.17;
        var scale = angry ? (lion ? 1.62 : 1.43) + Math.sin(now / 110) * .08 : idleScale;
        if (!hasApprovedSprite(icon, number)) {
          draw(icon, model(point.x + .06, .31 + bounce, baseZ,
            Math.sin(now / (lion ? 1100 : 850)) * (lion ? .045 : .075),
            scale), angry ? .16 : 0);
        }
        if (angry) drawSparkles(point.x + .06, lion ? 1.05 : .82,
          baseZ + .31, now, .3);
      } else {
        var kind = icon === 'hospital' ? 'hospital' : icon;
        draw(kind, model(baseX, .315, baseZ,
          icon === 'knife' || icon === 'axe' ? Math.sin(now / 740) * .11 : 0,
          icon === 'hospital' ? .78 : .8));
      }
    });
  }

  function drawSparkles(x, y, z, now, radius) {
    for (var i = 0; i < 5; i++) {
      var angle = now / 390 + TAU * i / 5;
      var height = Math.sin(now / 280 + i) * .11;
      draw('particle', model(x + Math.cos(angle) * radius,
        y + height, z + Math.sin(angle) * radius, 0,
        .75 + Math.sin(now / 180 + i) * .24), .35);
    }
  }

  function drawAmbient(now) {
    // Separate animated highlights keep the otherwise static jungle terrain alive.
    for (var index = 0; index < 7; index++) {
      var phase = now / 1350 + index * .94;
      var x = -3.62 + index * 1.02 + Math.sin(phase) * .11;
      var z = index % 2 ? 2.58 : -2.58;
      draw('particle', model(x, .56 + Math.sin(phase * 1.7) * .12, z,
        phase, .72 + (Math.sin(phase * 2.1) + 1) * .4), .31);
    }
    for (var wave = 0; wave < 6; wave++) {
      var riverX = 255 + ((wave * 131 + now * .028) % 680);
      var riverY = 151 + Math.sin(riverX / 72) * 9;
      var point = boardPoint(riverX, riverY);
      draw('water_glint', model(point.x, .232, point.z, Math.sin(now / 950 + wave) * .19,
        .83 + Math.sin(now / 520 + wave) * .17), .18);
    }
  }

  function drawPlayers(now) {
    ensurePlayers();
    app.game.state.players.forEach(function (player, index) {
      var p = currentPlayerPoint(player, index);
      var walking = Boolean(player.animatedPoint);
      var bob = walking ? Math.abs(Math.sin(now / 78 + index)) * .075 :
        Math.sin(now / 610 + index * .9) * .014;
      var crying = player.expression === 'cry';
      var tilt = crying ? Math.sin(now / 95) * .12 : 0;
      var active = index === app.game.state.current && app.game.state.started;
      draw('player_' + index, model(p.x, .327 + bob, p.z,
        tilt + (walking ? Math.sin(now / 150) * .1 : 0), active ? .94 : .83),
      active && !crying ? .065 : 0);
      if (crying) {
        var drop = (now / 490 + index) % 1;
        draw('tear', model(p.x - .072, .88 - drop * .21, p.z + .14));
        draw('tear', model(p.x + .072, .88 - ((drop + .48) % 1) * .21, p.z + .14));
      }
      if (app.game.state.won && active) drawSparkles(p.x, 1.04, p.z, now, .28);
    });
  }

  function camera(now) {
    var desired = { x: .08, y: .08, z: 0 };
    var zoom = app.distance;
    if (app.event && app.event.until > now && app.event.space) {
      var eventPoint = spacePoint(app.event.space);
      desired.x = eventPoint.x * .44;
      desired.z = eventPoint.z * .42;
      desired.y = .19;
      zoom = 7.35;
    } else if (app.cameraMode === 'follow' && app.game.state.started &&
               app.game.state.players[app.game.state.current]) {
      var player = currentPlayerPoint(app.game.state.players[app.game.state.current],
        app.game.state.current);
      desired.x = player.x * .15;
      desired.z = player.z * .14;
      desired.y = .1;
    }
    app.cameraTarget.x += (desired.x - app.cameraTarget.x) * .07;
    app.cameraTarget.y += (desired.y - app.cameraTarget.y) * .07;
    app.cameraTarget.z += (desired.z - app.cameraTarget.z) * .07;
    var horizontal = zoom * Math.cos(app.pitch);
    var eye = [app.cameraTarget.x + Math.sin(app.yaw) * horizontal,
      app.cameraTarget.y + Math.sin(app.pitch) * zoom,
      app.cameraTarget.z + Math.cos(app.yaw) * horizontal];
    var view = lookAt(eye, [app.cameraTarget.x, app.cameraTarget.y,
      app.cameraTarget.z], [0, 1, 0]);
    var projection = perspective(.73, app.pixelWidth / app.pixelHeight, .12, 80);
    return multiply(projection, view);
  }

  function renderFrame(now) {
    if (!app.ready) return;
    resize();
    var time = Number(now) || Date.now();
    app.lastTime = time;
    var gl = app.gl;
    app.stats.frameDrawCalls = 0;
    gl.clearColor(.77, .86, .82, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);
    var matrix = camera(time);
    gl.uniformMatrix4fv(app.program.viewProjection, false, matrix);
    draw('landscape', identity());
    drawAmbient(time);
    drawIcons(time);
    drawPlayers(time);
    updateArtwork(matrix, time);
    updateLabels(matrix);
    app.frames++;
    if (typeof window.requestAnimationFrame === 'function') {
      app.raf = window.requestAnimationFrame(renderFrame);
    }
  }

  function setCameraMode(mode) {
    app.cameraMode = mode === 'overview' ? 'overview' : 'follow';
    if (app.cameraButton) {
      app.cameraButton.textContent = 'CAMERA: ' + app.cameraMode.toUpperCase();
    }
    return app.cameraMode;
  }

  function setYaw(angle) {
    if (!Number.isFinite(angle)) return app.yaw;
    app.yaw = Math.max(-.8, Math.min(.82, angle));
    return app.yaw;
  }

  function setDistance(value) {
    if (!Number.isFinite(value)) return app.distance;
    app.distance = Math.max(7.8, Math.min(16.8, value));
    return app.distance;
  }

  function setFullScreen(enabled) {
    app.fullScreen = Boolean(enabled);
    if (document.body && document.body.classList) {
      if (app.fullScreen) document.body.classList.add('board-fullscreen');
      else document.body.classList.remove('board-fullscreen');
    }
    if (app.fullscreenButton) {
      app.fullscreenButton.textContent = app.fullScreen ? 'EXIT FULL SCREEN' : 'FULL SCREEN';
      app.fullscreenButton.setAttribute('aria-pressed', app.fullScreen ? 'true' : 'false');
    }
    return app.fullScreen;
  }

  function bindControls() {
    if (app.cameraButton) {
      app.cameraButton.addEventListener('click', function () {
        setCameraMode(app.cameraMode === 'follow' ? 'overview' : 'follow');
      });
    }
    if (app.fullscreenButton) {
      app.fullscreenButton.addEventListener('click', function () {
        setFullScreen(!app.fullScreen);
      });
    }
    if (app.zoomOutButton) {
      app.zoomOutButton.addEventListener('click', function () {
        setDistance(app.distance + .9);
      });
    }
    if (app.zoomInButton) {
      app.zoomInButton.addEventListener('click', function () {
        setDistance(app.distance - .9);
      });
    }
    app.canvas.addEventListener('pointerdown', function (event) {
      var pointerId = event.pointerId === undefined ? 0 : event.pointerId;
      app.pointers[pointerId] = { x: event.clientX, y: event.clientY || 0 };
      var points = Object.keys(app.pointers).map(function (key) { return app.pointers[key]; });
      if (points.length === 2) {
        app.pinch = { gap: Math.hypot(points[0].x - points[1].x,
          points[0].y - points[1].y), distance: app.distance };
        app.pointer = null;
      } else {
      app.pointer = { x: event.clientX, yaw: app.yaw };
      }
      if (app.canvas.setPointerCapture && event.pointerId !== undefined) {
        app.canvas.setPointerCapture(event.pointerId);
      }
    });
    app.canvas.addEventListener('pointermove', function (event) {
      var pointerId = event.pointerId === undefined ? 0 : event.pointerId;
      if (app.pointers[pointerId]) {
        app.pointers[pointerId] = { x: event.clientX, y: event.clientY || 0 };
      }
      var points = Object.keys(app.pointers).map(function (key) { return app.pointers[key]; });
      if (app.pinch && points.length >= 2) {
        var gap = Math.hypot(points[0].x - points[1].x,
          points[0].y - points[1].y);
        setDistance(app.pinch.distance + (app.pinch.gap - gap) * .018);
        return;
      }
      if (!app.pointer) return;
      setYaw(app.pointer.yaw + (event.clientX - app.pointer.x) * .004);
    });
    function release(event) {
      if (!event) app.pointers = {};
      else {
        var pointerId = event.pointerId === undefined ? 0 : event.pointerId;
        delete app.pointers[pointerId];
      }
      app.pointer = null;
      app.pinch = null;
    }
    app.canvas.addEventListener('pointerup', release);
    app.canvas.addEventListener('pointercancel', release);
    app.canvas.addEventListener('wheel', function (event) {
      if (event.preventDefault) event.preventDefault();
      setDistance(app.distance + (event.deltaY > 0 ? .7 : -.7));
    }, { passive: false });
  }

  function fallback(reason) {
    app.fallback = true;
    app.ready = false;
    if (app.canvas) app.canvas.style.display = 'none';
    if (app.labels) app.labels.style.display = 'none';
    var shell = document.getElementById('board-shell');
    if (shell && shell.classList) shell.classList.remove('board-3d-active');
    if (app.badge) app.badge.textContent = 'ADVENTURE MAP';
    if (app.cameraButton) app.cameraButton.style.display = 'none';
    app.failure = reason || 'WebGL is unavailable';
    return false;
  }

  function init(options) {
    if (!options || !options.canvas || !options.game || !options.labels) return false;
    app.canvas = options.canvas;
    app.labels = options.labels;
    app.art = options.art || null;
    app.game = options.game;
    app.toolbar = options.toolbar || null;
    app.badge = options.badge || null;
    app.cameraButton = options.cameraButton || null;
    app.fullscreenButton = options.fullscreenButton || null;
    app.zoomOutButton = options.zoomOutButton || null;
    app.zoomInButton = options.zoomInButton || null;
    try {
      app.gl = app.canvas.getContext &&
        (app.canvas.getContext('webgl', { antialias: true, alpha: true,
          premultipliedAlpha: false, powerPreference: 'high-performance' }) ||
         app.canvas.getContext('experimental-webgl', { antialias: true, alpha: true }));
      if (!app.gl) return fallback('This device does not provide WebGL 3D graphics.');
      app.program = createProgram(app.gl);
      buildMeshes();
      createLabels();
      createArtwork();
      bindControls();
      app.ready = true;
      app.fallback = false;
      var shell = document.getElementById('board-shell');
      if (shell && shell.classList) shell.classList.add('board-3d-active');
      if (app.badge) app.badge.textContent = 'LIVE 3D WORLD';
      setCameraMode('follow');
      setFullScreen(false);
      renderFrame(typeof performance !== 'undefined' ? performance.now() : Date.now());
      return true;
    } catch (error) {
      return fallback('3D graphics could not start: ' + String(error.message || error));
    }
  }

  function playEvent(kind, space, player) {
    if (!app.ready) return false;
    var start = typeof performance !== 'undefined' ? performance.now() : Date.now();
    var duration = kind === 'victory' ? 4500 : kind === 'cry' ? 1650 : 1900;
    app.event = { kind: kind, space: Number(space) || 0,
      player: Number(player) || 0, until: start + duration };
    app.stats.events.push({ kind: kind, space: Number(space) || 0 });
    if (app.stats.events.length > 80) app.stats.events.shift();
    return true;
  }

  function setGateState(space, frame) {
    app.gateStates[Number(space)] = String(frame || 'closed');
    app.stats.events.push({ kind: 'gate_' + frame, space: Number(space) });
    if (app.stats.events.length > 80) app.stats.events.shift();
    return app.ready;
  }

  function showDefeated(space) {
    var now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    app.defeatedUntil[Number(space)] = now + 2600;
    return app.ready;
  }

  function invalidate() { return app.ready; }

  function destroy() {
    if (app.raf && typeof window.cancelAnimationFrame === 'function') {
      window.cancelAnimationFrame(app.raf);
    }
    app.ready = false;
    app.raf = 0;
  }

  window.KeysClawsWorld3D = {
    init: init,
    playEvent: playEvent,
    setGateState: setGateState,
    showDefeated: showDefeated,
    invalidate: invalidate,
    renderFrame: renderFrame,
    setCameraMode: setCameraMode,
    setYaw: setYaw,
    setDistance: setDistance,
    setFullScreen: setFullScreen,
    destroy: destroy,
    state: app,
    math: { rgb: rgb, shade: shade, normalize: normalize, identity: identity,
      multiply: multiply, perspective: perspective, lookAt: lookAt,
      model: model, boardPoint: boardPoint, project: project },
    geometry: { create: meshBuilder, box: box, cylinder: cylinder, cone: cone,
      sphere: sphere, torus: torus }
  };
}());
